var e={"magnet-select":{tsx:`import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";

/* MARKS was Bencho's own pictures, which are not licensed
   to travel. Point this at yours. */
const MARKS: string[] = [];

/* ══ Magnetic select ═══════════════════════════════════════
   A cluster of options set close enough together to be in
   each other's way, and a selection that behaves like a
   magnet rather than a highlight: the one you press swells
   and takes the ink, and the rest are shoved radially out of
   its way — hardest next to it, barely at all at the edges.

   THE POINT IS THE FIELD, NOT THE ITEM. A normal segmented
   control moves an indicator and leaves the layout alone,
   which is why selecting in one feels like bookkeeping. Here
   the choice deforms its neighbourhood, so the answer to
   "which one is selected" is legible from three feet away
   with the shapes unreadable — it is the one everything else
   is leaning away from.

   ── AND IT IS A GROUP, NOT A ROW ─────────────────────────
   It was a row first, and a row wastes the idea. In a line
   there are two directions to be pushed and both of them are
   the same direction, so the field can only ever read as
   spacing; the falloff has to be inferred from how far along
   the row you are. In a cluster the shove is a VECTOR — each
   chip goes the way it actually lies from the magnet — and
   the same arithmetic suddenly reads as a field, because you
   can see it acting on every bearing at once.

   Every number still falls out of ONE decision: how far the
   selected chip grows. The room it needs is arithmetic from
   that, the shove is that room plus an aura, the aura decays
   with real distance, and the tilt is the aura's leftovers. */

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

/* ── the options ───────────────────────────────────────────
   Pictures, and deliberately not icons. They were nine lucide
   shapes — a circle, a square, a triangle — chosen because a
   set of tools or weather states invites you to read the row
   instead of watching it, and this block has exactly one thing
   to show.

   Colour fields do that job better than outlines did. A shape
   at 19px is a thin mark in the middle of a 44px disc and most
   of the chip is empty; a picture IS the chip, so the cluster
   reads as seven objects rather than as seven containers with
   marks in them — and the field pushing them about has
   something to push.

   Inlined by scripts/marks.sh for the reason every picture on
   this bench is: the artifact bundle is one file and a linked
   image is a dead square the moment it leaves this machine.
   The FILE ORDER is the cluster order, so renaming them
   rearranges the component and nothing else has to know. */
const NAMES = MARKS.map((_, i) => \`Option \${i + 1}\`);

const CHIP = 44;
const H_PAD = 26;

/* ── the packing ───────────────────────────────────────────
   A hex lattice at a pitch of 48 against a 44 chip, so every
   neighbour sits 4px off touching and the cluster is as tight
   as it can be without the field having nowhere to push.

   THE REGULARITY IS THE POINT, and it is a reversal. These
   were hand-jittered before, on the reasoning that a lattice
   reads as a grid — true when the arrangement is the thing you
   are looking at, and wrong here, because the arrangement is
   the thing being DEFORMED. A field distorting an irregular
   scatter is hard to read as anything but a different
   scatter; the same field opening a hole in a honeycomb is
   unmistakable. You need the regular ground to see the
   disturbance against.

   ── AND THERE ARE TWO OF THEM, not a slider from four to
   nine. Every count between them was a worse version of one of
   these: five and six are a flower with a bite out of it,
   eight and nine are a flower with something stuck to the
   side. Three is a triangle and seven is the closed hexagon —
   the only two arrangements at this pitch where every chip has
   the same relationship to its neighbours, and the only two
   worth offering. A slider across six stops invited a drag to
   find the good one; there are two, so they are named.

   Points are taken from the lattice in rings outward, so each
   is the roundest blob available at that size, and the first
   is the centre — pressing a chip with neighbours on
   every side is the single best frame this component has, and
   the one the card should be caught in. Six is the default
   because it is a centre with a ring that is one short of
   closing: the notch keeps it from reading as a logo. */
const CLUSTER: Record<number, [number, number][]> = {
  3: [[0, -26], [22.5, 13], [-22.5, 13]],
  7: [[0, 0], [45, 0], [22.5, -39], [-22.5, -39], [-45, 0], [-22.5, 39], [22.5, 39]],
};

/* the spacing the falloff is measured in. Distances divided by
   this — the lattice pitch, so a chip one step away sits at
   far = 1 and
   the exponent below is reading a neighbourhood rather than a
   pixel count that would mean something different at every
   count. */
const PITCH = 45;

/* the two answers, and what the knob calls them */
const SIZES: Record<string, number> = { Small: 3, Large: 7 };

/* ── how fast the aura falls off, in those steps ───────────
   1.4 for as long as the chips were far enough apart not to
   care, and the tight packing is what set the real number.

   THE TIGHTEST PAIR IS NEVER BESIDE THE MAGNET. It is two
   chips on the same ray out of it — the near one shoved
   harder than the one behind it, so the pair closes by the
   difference between their pushes, and with 4px of slack
   there is nothing to absorb that. Measured at full Pull with
   1.4: every other pair in the cluster sat above 11px and
   that one was at 0.8, which is not overlapping and is well
   inside the margin where rounding could make it so.

   1.8 fixed it at a pitch of 48. At 46 — chips two pixels off
   touching — the same pair came back to exactly zero, because
   there is now almost no rest gap for the closing to eat.
   2.8 with a deeper cower is the answer: the field reaches a
   little further, which if anything reads as more of a field,
   and the chip the magnet is nearest gives up more of its own
   size. Both leave the PACKING alone, which is the point —
   the tightness is the resting picture and the clearance has
   to come from somewhere else. At a pitch of 45 the same pair
   came to 0.57px; these two take it to about two. */
const SPREAD = 2.8;

/* ── inlined from ./spring ──────────────────────── */
/* ── one spring, for everything that settles ───────────────
   The maths was already on this bench twice, copied by hand:
   Humidity's wheel and Brightness's column both accumulate
   velocity toward a target, damp it, and snap when both the
   delta and the velocity fall under 0.02. Two copies is a
   coincidence; five would be a policy, so it comes out here
   before the elastic blocks are written against it.

   The two shipped copies are deliberately NOT refactored onto
   this. They work, they are tuned, and rewriting the innards
   of two live components to prove a point about duplication
   is how a good afternoon becomes a bad one. This is the one
   new code uses.

   Frames, not milliseconds. \`dt\` is expressed in sixtieths of
   a second and the damping is RAISED to it rather than
   multiplied by it, so a dropped frame decays the same amount
   of energy as the two frames it replaced. Multiplying is the
   version that makes a spring behave differently on a busy
   page, which is the hardest kind of bug to see.

   The loop parks itself the moment the value has settled.
   CLAUDE.md is not complimentary about the one permanent
   requestAnimationFrame already on this bench and there is no
   case for five more. */

/* 0..100 into the two numbers a spring actually has.

   50 is what Humidity and Brightness were tuned at, which is
   the rule every elastic knob on this bench follows — see
   lab/motion. Turn the panel to the middle and nothing has
   changed.

   Both ends have to be usable, which is what fixes the range:
   at 0 it is slow and heavy and still arrives, at 100 it is
   quick with a visible overshoot, and nowhere in between does
   it ring for longer than it takes to read. */
/* The pair is chosen by DAMPING RATIO and then written back
   as stiffness and decay, because the ratio is the thing a
   person is actually setting and the two numbers on their own
   do not say what they add up to.

     zeta = -ln(d) / (2 * sqrt(k))

   The first version of this ran 0.06..0.26 stiffness against
   0.93..0.74 decay, which reads as a sensible spread and is
   not one: it puts zeta between 0.15 and 0.16 across the
   WHOLE range, so every setting overshot by about sixty per
   cent and the knob only changed how fast it did it. Pull's
   return went 130px past its own resting position and lifted
   the content off the top of the card.

     0   → zeta ~0.85, heavy, arrives without a ring
     50  → zeta ~0.41, near where Humidity and Brightness sit
     100 → zeta ~0.20, lively, two visible rebounds

   Both ends shippable, which is the constraint that fixed the
   numbers rather than taste. */
const springOf = (tune: number) => ({
  /* stiffness: how hard it is pulled toward the target */
  k: 0.08 + (tune / 100) * 0.16,
  /* decay, per frame: how much of the velocity survives */
  d: 0.62 + (tune / 100) * 0.2,
});

/* Units matter. The snap threshold is absolute, so a caller
   works in pixels or in 0..100 — a spring driven over 0..1
   would be "settled" before it had visibly moved. */
function useSpring(target: number, tune = 50, instant = false) {
  const [at, setAt] = useState(target);
  const cur = useRef(target);
  const vel = useRef(0);
  const raf = useRef(0);

  useEffect(() => {
    if (instant) {
      cur.current = target;
      vel.current = 0;
      setAt(target);
      return;
    }
    const { k, d } = springOf(tune);
    let prev = 0;
    const tick = (t: number) => {
      const dt = prev ? clamp((t - prev) / 16.67, 0, 2.5) : 1;
      prev = t;
      vel.current += (target - cur.current) * k * dt;
      vel.current *= Math.pow(d, dt);
      cur.current += vel.current * dt;
      if (Math.abs(target - cur.current) < 0.02 && Math.abs(vel.current) < 0.02) {
        cur.current = target;
        vel.current = 0;
        setAt(target);
        raf.current = 0;
        return;
      }
      setAt(cur.current);
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf.current);
      raf.current = 0;
    };
    /* \`tune\` sits here beside \`target\` for the reason
       Brightness spells out: the loop closes over it, so
       without it a knob turned mid-flight would do nothing
       until something else restarted the effect. Restarting
       picks up from the refs, so it continues rather than
       snapping. */
  }, [target, tune, instant]);

  return at;
}

/* Read once, the way the wheel and the pill nav do. A
   preference, not a live input. */
const stillness = () =>
  typeof window !== "undefined" &&
  !!window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

export function MagneticSelect({
  /* how many options, 4 to 9 */
  /* "small" is three, "large" is seven — see SIZES */
  size = "Large",
  /* the strength of the whole field, 0-100 */
  pull = 55,
  /* how much it overshoots on the way to rest */
  bounce = 55,
  /* how far a chip leans toward the cursor near it, 0-100 */
  give = 50,
}: {
  size?: string;
  pull?: number;
  bounce?: number;
  give?: number;
} = {}) {
  const n = Math.min(SIZES[size] ?? 7, MARKS.length);
  const p = clamp(pull, 0, 100) / 100;
  const pts = CLUSTER[n];

  /* ── it lands SELECTED, on the one in the middle ─────────
     A magnetic select drawn with nothing chosen is a cluster
     of chips: true of the component and a picture of the one
     state where it has nothing to say. */
  /* ── IT OPENS ON THE MIDDLE ONE ─────────────────────────
     Index 0 is the centre of the cluster by construction — the
     lattice points are taken in rings outward, so the first is
     always the hub. On Small there is no hub and it is simply
     the first of the three.

     The centre is also the only selection whose field is even:
     every other chip is the same distance from it, so they all
     move by the same amount and the spacing stays uniform all
     round. That makes it the honest still image of what this
     block does — and the one frame the card on the wall is
     caught in.

     null is still the type, because "nothing chosen" is a
     state this can reach and an index that happens to be
     invalid is not the same thing. */
  const [sel, setSel] = useState<number | null>(0);
  const at = sel === null || sel >= n ? null : sel;

  /* ── ONE decision, and the rest is arithmetic ────────────
     GROW is the knob. ROOM is the space the swell physically
     takes on every side — half the extra width, exactly — so
     the neighbours are never merely *near* clear of it. AURA
     is the part that is not arithmetic: the push beyond what
     the geometry demands, which is the difference between a
     cluster making room and a cluster being repelled. */
  const grow = 1.16 + 0.22 * p;
  const room = (CHIP * (grow - 1)) / 2;
  const aura = 3 + 9 * p;
  const tilt = 5 * p;
  /* the neighbours give up a little size as well as ground —
     the magnet takes the mass as well as the space, and the
     size it gives up is also the clearance that keeps the
     tightest pair from touching */
  const cower = 0.04 + 0.09 * p;

  /* ── AND EACH ONE LEANS TOWARD THE CURSOR ───────────────
     The field is what a chip does about the SELECTION. This is
     what it does about your hand: come within reach of one and
     it tips a few pixels your way, and lets go as you leave.

     A few pixels is the whole specification. Past about seven
     a chip stops acknowledging you and starts being something
     you are dragging, which is a different component. Same
     ceiling and the same curve the search field uses, because
     it is the same gesture and they should feel identical.

     AND IT IS THE GROUP THAT LEANS, not the chip. Tipping one
     disc on its own opens a gap on the side it came from and
     closes one on the side it went to — so a cluster packed a
     pixel off touching came apart wherever your cursor was.
     The spacing here is the whole picture; it has to survive
     being touched. Every chip moves by one shared vector: the
     group tips toward you as one body and the gaps are exactly
     what they were.

     ── AND THE VECTOR IS MEASURED FROM ONE POINT ───────────
     It was measured from whichever chip the cursor was nearest,
     which gave a group with seven possible origins. Crossing
     from one chip's territory to the next swapped the origin
     and the direction snapped with it, so moving over the
     cluster made it jerk about — worst in the middle, where
     the nearest chip changes every few pixels.

     One origin, the cluster's own centre, and the whole thing
     goes away: there is nothing to hand over to. It also means
     nothing here knows where the individual chips ARE, which
     is the honest shape for a behaviour that belongs to the
     group — the spaces between them stop being a thing the
     lean can notice.

     The magnitude RAMPS UP from the centre rather than peaking
     there, which is the other half of the same problem. Toward
     a point, the direction is whatever it is; AT the point it
     is nothing at all — so a lean that is strongest where its
     own direction is undefined spins on the spot. Zero at the
     centre, full at the cluster's edge, easing out past it.

     Measured from the chips' own resting geometry rather than
     from their rects. Reading a position off a thing this
     displaces is a feedback loop — it settles, but it settles
     by ringing, and on a 44px disc the ring is visible. The
     numbers below are the layout, which never moves. */
  /* how far past the cluster's own edge the lean survives */
  const FADE = 44;
  const wrap = useRef<HTMLDivElement | null>(null);
  /* the centre it leans about, and how far its edge is */
  const hub = useRef({ x: 0, y: 0, r: 1 });
  const [lean, setLean] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const still = stillness();

    /* the box is the cluster's own bounds plus room for the
     field to spend itself in. Derived, so moving a point in
     the table above cannot push a chip off the block. */
  const xs = pts.map((q) => q[0]);
  const ys = pts.map((q) => q[1]);
  const minX = Math.min(...xs);
  const minY = Math.min(...ys);
  const W = Math.max(...xs) - minX + CHIP + H_PAD * 2;
  const H = Math.max(...ys) - minY + CHIP + H_PAD * 2;

  /* ── the springs ─────────────────────────────────────────
     Bounce is a DAMPING RATIO, not a damping value: tie it to
     a raw number and the same setting is bouncy on one chip
     and dead on another, because each chip here springs at a
     different stiffness. As a ratio it means the same thing
     everywhere — 0.9 arrives and stops, 0.42 arrives and
     rings — and stiffness is then free to vary. */
  const zeta = 0.9 - 0.48 * (clamp(bounce, 0, 100) / 100);
  const swing = (k: number, mass: number) => ({
    type: "spring" as const,
    stiffness: k,
    damping: 2 * Math.sqrt(k * mass) * zeta,
    mass,
  });

  /* ── the field, worked out once ──────────────────────────
     The chips need it to know where to go and the lean needs
     it to know where they went. Computed here rather than
     inside the map, because a copy of this arithmetic in two
     places is two things to keep in agreement. */
  const field = pts.map(([px, py], i) => {
    /* with no magnet there is no field: every chip sits on its
       own lattice point and the pushes are all zero */
    if (at === null) {
      return { far: 0, fall: 0, push: 0, ux: 0, uy: 0,
        cx: px - minX + H_PAD + CHIP / 2,
        cy: py - minY + H_PAD + CHIP / 2 };
    }
    const [ax, ay] = pts[at];
    const dx = px - ax;
    const dy = py - ay;
    const gap = Math.hypot(dx, dy);
    const far = gap / PITCH;
    /* the aura, spent. exp() rather than 1/d because an
       inverse law is violent at the first neighbour and flat
       everywhere after, so the cluster reads as one chip
       barged aside and four standing still. */
    const fall = i === at ? 0 : Math.exp(-(far - 1) / SPREAD);
    /* ── THE PUSH DOES NOT DECAY, and that is the fix ──────
       It was \`room + aura * fall\`, so a chip near the magnet
       moved further than the one behind it — and two chips on
       the same ray out of the magnet therefore CLOSED by the
       difference, while every other pair opened. That was the
       one pair in the cluster tighter than the rest, and it
       was the only pair anywhere that got tighter at all.

       Constant, it cannot happen: two chips on the same
       bearing move by the same amount and their spacing is
       exactly what it was. Nothing in the cluster ever
       compresses now; gaps only open.

       \`fall\` is still computed and still used — it drives the
       stagger and the tilt below, which is where a sense of
       the field reaching further at the front belongs. It was
       doing two jobs and only one of them was safe. */
    const push = i === at ? 0 : room + aura;
    /* ── AND THE DIRECTION IS THE BEARING ──────────────────
       Straight out along the line from the magnet, which is
       the whole reason for abandoning the row: in a line this
       reduces to a sign, and every chip is pushed along the
       same axis whatever its actual relationship to the one
       you pressed. */
    const ux = gap ? dx / gap : 0;
    const uy = gap ? dy / gap : 0;
    return { far, fall, push, ux, uy,
      /* where the chip comes to rest, in the block's own px */
      cx: px - minX + H_PAD + CHIP / 2 + ux * push,
      cy: py - minY + H_PAD + CHIP / 2 + uy * push };
  });
  /* the cluster's middle, and the distance to the furthest
     chip's outer edge — the radius the ramp is measured in */
  hub.current = {
    x: W / 2,
    y: H / 2,
    r: Math.max(1, ...field.map((f) =>
      Math.hypot(f.cx - W / 2, f.cy - H / 2) + CHIP / 2)),
  };

  /* ── the lean, read off the pointer ─────────────────────
     One listener for the whole cluster and one rect per move,
     because the chips' positions come from \`spots\` rather than
     from the DOM. Throttled to a frame: a pointermove can
     arrive several times between paints and only the last one
     is worth anything.

     The block is drawn at a fraction on the wall and at a zoom
     on the canvas, so client pixels are divided back into the
     component's own before any distance is compared to REACH —
     otherwise the reach is a different size in every place the
     block appears. */
  useEffect(() => {
    const el = wrap.current;
    if (!el || !give || still) return;
    let raf = 0;
    let next = { x: 0, y: 0 };
    const publish = () => { raf = 0; setLean(next); };
    const read = (e: PointerEvent) => {
      const b = el.getBoundingClientRect();
      const k = b.width / (el.offsetWidth || b.width) || 1;
      const mx = (e.clientX - b.left) / k;
      const my = (e.clientY - b.top) / k;
      const { x: hx, y: hy, r } = hub.current;
      const dx = mx - hx;
      const dy = my - hy;
      const d = Math.hypot(dx, dy);
      /* nothing at the centre, full at the edge, and gone by
         FADE past it — see the note above */
      const rise = Math.min(1, d / r);
      const away = d <= r ? 1 : Math.max(0, 1 - (d - r) / FADE);
      /* the search field's ceiling, because it is the same
         gesture even though the curve into it is not */
      const drawn = rise * away * (2 + (clamp(give, 0, 100) / 100) * 5);
      next = drawn > 0
        ? { x: (dx / (d || 1)) * drawn, y: (dy / (d || 1)) * drawn }
        : { x: 0, y: 0 };
      if (!raf) raf = requestAnimationFrame(publish);
    };
    const gone = () => { next = { x: 0, y: 0 }; if (!raf) raf = requestAnimationFrame(publish); };
    document.addEventListener("pointermove", read, { passive: true });
    document.addEventListener("pointerleave", gone);
    return () => {
      document.removeEventListener("pointermove", read);
      document.removeEventListener("pointerleave", gone);
      cancelAnimationFrame(raf);
    };
  }, [give, still, n]);

  const choose = (i: number) => {
    if (i === at) return;
    setSel(i);
  };

  return (
    <div className="mag" ref={wrap} style={{ width: W, height: H }} role="radiogroup" aria-label="Shape">
      {pts.map(([px, py], i) => {
        const on = i === at;
        const { far, fall, push, ux, uy } = field[i];

        const k = 300 + 280 * (1 - Math.min(far, 3) / 4);
        const wait = far * 0.022;

        return (
          <motion.button
            key={i}
            className="mag-chip"
            role="radio"
            aria-checked={on}
            aria-label={NAMES[i]}
            data-on={on || undefined}
            style={{
              left: px - minX + H_PAD,
              top: py - minY + H_PAD,
              width: CHIP,
              height: CHIP,
            }}
            onClick={() => choose(i)}
            /* nothing animates on mount — the block is drawn
               with a selection already made, and a field that
               assembles itself on page load reads as a loading
               state rather than as a choice */
            initial={false}
            animate={{
              x: ux * push,
              y: uy * push,
              /* ── wide before it goes tall ────────────────
                 Two springs at different stiffnesses rather
                 than one scale, so the transient is
                 anisotropic and the rest state is not: X
                 leads, Y follows a beat behind, and the chip
                 flattens out and rounds up on its way to size.
                 This is the whole of the "jelly", and it is
                 four numbers rather than a keyframe track —
                 which matters, because a keyframed squash is
                 the same squash at every Bounce setting and
                 this one is not there at all when the spring
                 is critically damped. */
              scaleX: on ? grow : 1 - cower * fall,
              scaleY: on ? grow : 1 - cower * fall,
              /* shoved things tip, and only the sideways part
                 of the shove tips them — a chip driven straight
                 up has nothing to lean into. The shapes carry
                 it even when the chip is a circle and the
                 rotation is otherwise invisible. */
              rotate: ux * tilt * fall,
            }}
            transition={{
              /* ── and the far ones are LATE ────────────────
                 22ms a step. Fire them together and the
                 cluster moves as a slab; stagger them and the
                 shove travels outward, which is the difference
                 between a layout change and a force. */
              x: { ...swing(k, 0.9), delay: wait },
              y: { ...swing(k, 0.9), delay: wait },
              scaleX: { ...swing(k * 1.24, 0.8), delay: wait },
              scaleY: { ...swing(k * 0.86, 0.95), delay: wait },
              rotate: { ...swing(k * 0.8, 1), delay: wait },
            }}
          >
            {/* ── the hover lives on its OWN element ────────
                The button carries a Framer transform and this
                carries a CSS one, because they cannot share:
                CSS \`scale\` and \`transform\` are applied in
                sequence rather than folded together, so a rule
                here and a spring there fight every frame. Two
                elements, two transforms, no argument — and it
                buys the hover its own curve, which it needs,
                since the spring that moves the field would
                make a bouncy hover out of a lift that is meant
                to be felt rather than seen. */}
            {/* ── the lean lives HERE, not on the button ────
                The button's transform is Framer's — the field's
                shove, the swell and the tilt, all on one spring
                with a delay on it. A cursor-follow on that
                spring would arrive late and keep arriving after
                you had gone. The skin is the other element and
                carries its own transform, which is also where
                the hover swell already lives. */}
            <span
              className="mag-skin"
              style={{
                "--lx": \`\${lean.x.toFixed(2)}px\`,
                "--ly": \`\${lean.y.toFixed(2)}px\`,
              } as React.CSSProperties}
            >
              <img className="mag-mark" src={MARKS[i]} alt="" draggable={false} />
            </span>
          </motion.button>
        );
      })}
    </div>
  );
}
`,css:`/* ══ Magnetic select ════════════════════════════════════════
   A cluster of chips that get out of the selected one's way.

   TWO ELEMENTS, TWO TRANSFORMS. The chip is placed by left/top
   and moved by Framer's transform; the skin inside it carries
   the CSS hover. They cannot share an element: CSS \`scale\` and
   \`translate\` are applied BEFORE \`transform\` rather than
   folded into it, so a rule here and a spring there do not
   average out, they fight every frame. So nothing in this file
   may set or transition a transform on .mag-chip, and the
   transitions below name their properties one at a time —
   a \`transition: all\` would sweep the transform up with the
   colours. */
.mag {
  position: relative;
  box-sizing: border-box;
  font-family: var(--font-ui);}

/* the chip is a POSITION and nothing else: no surface, no
   corner, no colour. Everything you can see is the skin */
.mag-chip {
  position: absolute;
  padding: 0;
  border: 0;
  background: none;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;}

.mag-skin {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  /* always round, and it is not a knob. A Corner control was
     here and it earned its removal: at 0 the chips are squares
     packed 4px apart on a hex lattice, which is a honeycomb
     made of the one shape that does not tile it — every pair
     that is not side by side meets corner to flat and the
     even spacing stops looking even. The tilt gives it away
     too: a rotated square sweeps a wider box than it occupies
     and eats the clearance, where a rotated circle is a
     circle and costs nothing. */
  border-radius: 50%;
  /* ── plain, until it is the one ─────────────────────────
     An unchosen chip is a blank disc: the slab, which is white
     on the light theme and the dark theme's own equivalent, so
     it reads as an empty circle either way rather than as a
     colour somebody chose. The picture belongs to the answer,
     not to the options. */
  background: var(--fill-slab, var(--card));
  /* the pictures fill the chip, so they are what the corner
     cuts — the skin is the only thing that knows it is round */
  overflow: hidden;
  /* ── the hover, borrowed from the search block ───────────
     Its own note puts it best: it comes up a hair, and it is
     small enough to be felt rather than seen, because a hover
     state you NOTICE is a hover state that has said too much.
     Same 1.045 and the same curve, so the two blocks answer a
     cursor identically — and the surface answers with it,
     which is the part that stops 4.5% reading as a twitch.

     Deliberately not a spring. The field springs; this does
     not. A hover that bounces is the cursor being celebrated,
     and the cursor has not done anything yet. */
  /* ── the lean, and nothing else ──────────────────────────
     One transform, doing one thing. It carried a hover swell
     as well until that was removed — see the note below.

     The 260ms is what makes a value changing every frame read
     as damping rather than as tracking. Same curve and same
     duration as the search field, because it is the same
     gesture. */
  transform: translate(var(--lx, 0px), var(--ly, 0px));
  transition:
    transform 260ms cubic-bezier(0.22, 0.9, 0.28, 1),
    background-color 0.24s ease,
    color 0.24s ease;}

/* ── NOTHING ANSWERS A CURSOR ON ITS OWN ──────────────────
   There was a swell here: hover a chip and that chip grew
   4.5%. It is the ordinary thing to do and it is wrong for
   this component twice over.

   It is the only per-item response left, and it was the one
   you could see — a 4.5% swell on a 44px disc reads louder
   than the whole group leaning two to seven pixels, so the
   cluster looked like it was answering one chip at a time
   when the lean had already been made the group's.

   And it cannot be made group-wide, which is the deeper
   reason. A lean is a translation: apply it to every chip and
   the spacing is untouched. A swell is a scale, and scaling a
   cluster about its centre moves every chip away from every
   other — 4.5% across a 45px pitch is two pixels of gap
   opening on a cluster packed one pixel off touching. The
   gaps have to stay equal, so the only honest answer is that
   the hover does not resize anything at all.

   What the cursor still gets is the tone: the chip under it
   comes up a little, which is a change of ink rather than of
   geometry and costs the packing nothing. */
.mag-chip:hover .mag-skin {
  background: rgba(var(--ink-rgb), 0.11);}

/* ── the chosen one is the only one with a PICTURE ─────────
   The others were drained to almost no saturation, which is a
   photograph you can still see and therefore still read as
   content — seven pictures, one of them brighter. Off
   entirely, the cluster is a set of blank discs and one
   answer, which is what a chooser is.

   240ms either way, so a selection crossing the cluster is one
   picture arriving as another leaves rather than a cut. */
.mag-skin .mag-mark {
  opacity: 0;
  transition: opacity 0.24s ease;}

.mag-chip[data-on] .mag-skin .mag-mark { opacity: 1; }

/* the selected one lifts too — it is a circle you can point
   at like any other — but its surface is already the ink and
   has nowhere to go, so only the scale answers */
.mag-chip[data-on]:hover .mag-skin {
  background: var(--ink);
  color: var(--card);}

[data-stroke="on"] .mag-skin {
  box-shadow: inset 0 0 0 1px var(--pane-edge);}

/* the picture IS the chip: it fills the skin and the skin's
   own corner cuts it, so there is no second radius to keep in
   agreement with the first */
.mag-mark {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;}

@media (prefers-reduced-motion: reduce) {
  .mag-skin { transition-duration: 1ms; }
}`,tokens:[`--card`,`--fill-slab`,`--font-ui`,`--ink`,`--ink-rgb`,`--pane-edge`],deps:[`framer-motion`],stubs:[`MARKS`]},"slide-confirm":{tsx:`import { useEffect, useRef, useState } from "react";
import { animate, motion, useMotionValue, useTransform } from "framer-motion";
import { ArrowRight, Check } from "lucide-react";

/* ══ Slide to confirm ═════════════════════════════════════
   A handle you push across a track. It follows the finger
   exactly, and past the mark it takes over and finishes the
   journey itself.

   THE HANDLE BECOMES THE ANSWER. On commit it does not hand
   over to a tick somewhere else — it unfurls leftward and
   fills the track it was crossing, and the arrow it was
   carrying becomes a check. One object changing shape, which
   is the case a morph is actually for, and the reason this
   needs no second element to say "done".

   The right edge does not move while that happens: the width
   grows by exactly what the offset loses. So the handle
   arrives, plants itself, and opens out behind it. */

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

const SPAN = 280;
const H = 56;
/* the inset the handle keeps from the track, all four sides */
const PAD = 4;
/* the handle is a circle in a 56 track, so it is sized by the
   HEIGHT and the width knob does not touch it. Widening the
   track buys travel, not a longer handle — the thing you push
   stays the thing you push. */
const GRIP = H - PAD * 2;
/* the shortest track worth drawing. Below this the centred
   label starts to sit under the resting handle, which is the
   one collision this layout has. */
const MIN = 220;
const MAX = 380;

/* a pill, and the top of the Corner knob */
const CORNER = H / 2;
const SPEED = 50;

/* ── how far the swell is, and it is TINY ──────────────────
   The dot sits four pixels inside the track, so the ring round
   it is the whole budget for a hover. 3% of 48 is 1.4, which
   is 0.7 a side and leaves 3.3 — the liquid toggle's note is
   the long version of this arithmetic. */
const SWELL = 1.03;

/* how long the finished state stands before it resets. It has
   to reset: the wall keeps one instance of a block for the
   session, so a slide that stayed confirmed would show every
   later visitor a component with nothing to do — the fault the
   Notify demo had. */
const HOLD = 1500;

export function SlideConfirm({
  /* the track's corner, px. The handle's is this less the
     inset, which is the concentric rule every nested pair on
     this bench follows. */
  corner = CORNER,
  /* how quickly it takes over once you let go, 0..100 */
  speed = SPEED,
  /* the track's length, px. Everything that reads as distance
     in this component — the mark, the label's fade, the
     arrow's — is a fraction of the travel rather than a fixed
     number of pixels, so all of it follows this. */
  width = SPAN,
}: {
  corner?: number;
  speed?: number;
  width?: number;
} = {}) {
  const [done, setDone] = useState(false);
  const [held, setHeld] = useState(false);
  const [hot, setHot] = useState(false);
  const track = useRef<HTMLDivElement | null>(null);
  /* the live grab. A ref rather than state for the reason every
     drag on this bench uses one: it changes on every frame of a
     gesture, which is exactly the value that must not render. */
  const grip = useRef<{ id: number; grab: number | null; moved: boolean } | null>(null);
  const beat = useRef(0);

  const x = useMotionValue(0);
  /* ── where the handle planted itself ─────────────────────
     Zero except while it is unfurling, and then it is the
     offset the handle had when it committed. The width is
     \`GRIP + (anchor - x)\`, so PAD + x + width comes to
     PAD + GRIP + anchor — a number with no x in it. The right
     edge is therefore stationary BY ARITHMETIC rather than by
     two animations agreeing.

     It was two: \`x\` on one spring and \`width\` on another with
     the same numbers, which is not the same thing at all. They
     start a frame apart and drift, and the right edge measured
     6.8px of wobble across the morph. One value read twice
     cannot do that. */
  const anchor = useMotionValue(0);
  /* ── the settle ──────────────────────────────────────────
     The unfurl ends with the handle exactly filling the track
     and nothing else happening, which reads as the animation
     stopping rather than as the thing landing. A dip of about
     three per cent and back gives it somewhere to arrive.

     On the TRACK, so the whole block gives at once — the
     handle is the track by then, and scaling the two
     separately would be two objects where there is one. It is
     the palette's beat, and the same trade: a scale drags the
     corner radius with it, which at 2.6% is under a pixel on a
     28px corner and nobody reads a pulse as a change of shape.

     Its own clock rather than the spring's. The spring is
     nearly there for most of its run, so a dip read off it
     would spike in the first two frames and be flat for the
     rest — the note the player's bounce carries. And the peak
     sits late, at 0.62, so the block gathers as it lands
     instead of pulsing before it. */
  const pulse = useMotionValue(1);
  /* the arrow's own fade, so it can leave on the COMMIT rather
     than on x — see where it is read */
  const shown = useMotionValue(1);

  /* ── the width is READ EVERY RENDER, not captured ────────
     Every derived value below is built with an inline closure,
     and useTransform re-runs those during the render that
     changes them — so moving this knob re-derives the mark,
     the fade and the wash on the same frame the number
     changes. Nothing here has to be told the width moved. */
  const span = clamp(Math.round(width), MIN, MAX);
  const TRAVEL = span - PAD * 2 - GRIP;

  const r = clamp(corner, 0, CORNER);
  /* ── the handle's corner is DERIVED ──────────────────────
     \`r - PAD\`, floored at zero: the radius of a thing inside
     another, less the gap between them, is what keeps the two
     curves parallel. At r = 0 both are square together rather
     than a square track holding a rounded handle. */
  const gripR = Math.max(0, r - PAD);
  /* ── the end IS the commit, and there is no knob ─────────
     There was a Commit dial, 40..100, and it had no meaning to
     set: a slide-to-confirm that fires at 60% is one you can
     trigger by knocking the handle, which is the single thing
     the gesture exists to prevent. The only honest answer is
     the end of the track, so the end is what it is. */
  const mark = TRAVEL;

  /* ── SPEED, and deliberately not Bounce ──────────────────
     There was a Bounce knob and it had to go, for the reason
     the liquid toggle's did: this shape has a hard wall at
     both ends. On commit the handle exactly fills the track,
     so there is nowhere for an overshoot to go — and because
     the right edge is pinned by the arithmetic above, the
     overshoot came out of the LEFT edge instead. Measured at
     Bounce 50: the handle shot 42px out of its own track.

     A dial whose every setting above zero breaks the component
     is not a dial. Speed is the real question here — how fast
     it takes over once you let go — and the damping is derived
     to sit exactly on critical, so nothing overshoots at any
     setting of it.

     zeta = c / (2 * sqrt(k * m)), so c at zeta 1 is
     2 * sqrt(k * m). Written that way the knob can move the
     stiffness freely and the spring stays honest. */
  const stiff = 260 + (clamp(speed, 0, 100) / 100) * 640;
  /* the COMMIT stays exactly on critical. It has a wall at the
     far end and the settle is what gives it a landing. */
  const spring = {
    type: "spring" as const,
    stiffness: stiff,
    damping: 2 * Math.sqrt(stiff * 0.9),
    mass: 0.9,
  };
  /* ── the RETURN is not ───────────────────────────────────
     0.62 of critical, so it arrives with something left over
     rather than stopping dead. The overshoot never shows as
     movement — \`seen\` clamps the position at the wall — it
     shows as the squash above, which is the same energy
     spent somewhere it fits. */
  const home = { ...spring, damping: 2 * Math.sqrt(stiff * 0.9) * 0.62 };

  useEffect(() => () => {
    window.clearTimeout(beat.current);
    loose.current?.();
  }, []);

  /* ── THE DRAG IS FOLLOWED ON THE WINDOW ──────────────────
     It used to be followed on the track, with pointer capture
     to keep the events coming once the cursor left it. That is
     the textbook arrangement and it has one failure the
     textbook does not mention: capture is best-effort. The call
     is wrapped in a try/catch here — it throws on a synthetic
     pointer id — and a browser can also drop it mid-gesture, on
     its own, when a touch turns into a system gesture or the
     pointer leaves the window. When that happened the release
     landed on some other element, the track never heard it, and
     the handle sat held at the far end forever: reported as "I
     slide all the way to the end with my cursor outside the
     slider and it stays in a constant drag state".

     Listening on the window removes the dependency. The events
     reach it whatever they are retargeted to and whether or not
     the capture survived, so a release ANYWHERE ends the drag —
     which is what a slider promises: your finger owns the
     handle until you lift it, not until you wander off the
     track. Capture stays on because it still suppresses text
     selection and the grip's own hover, but nothing depends on
     it any more.

     ── AND IT IS BOUND AT THE PRESS, NOT IN AN EFFECT ───────
     The first version of this bound them from a \`useEffect\` on
     \`held\`, which is the tidier-looking arrangement and drops
     moves: an effect does not run until React has committed the
     render, and a fast flick can put its first pointermove in
     that gap. That first move is the one that sets the grab
     offset, so losing it means the whole drag does nothing —
     measured, with the handle sitting at home after a full
     sweep. Bound inside \`down\`, they are live on the same tick
     as the press. */
  const loose = useRef<(() => void) | null>(null);
  /* the handlers are rebuilt every render and the listeners are
     not, so they are reached through a ref rather than captured
     — live rather than one render stale */
  const live = useRef<{
    move: (e: PointerEvent) => void;
    up: (e: PointerEvent) => void;
  }>({ move: () => {}, up: () => {} });

  const watch = () => {
    loose.current?.();
    const onMove = (e: PointerEvent) => live.current.move(e);
    const onUp = (e: PointerEvent) => { live.current.up(e); loose.current?.(); };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    window.addEventListener("pointercancel", onUp);
    loose.current = () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onUp);
      loose.current = null;
    };
  };

  /* ── everything else is read off x ───────────────────────
     The wash behind the handle, the label giving up its ink,
     and the arrow fading as the end approaches are three
     readings of one number rather than three things animated
     toward the same moment. Same rule the checklist follows. */
  /* ── and both readings clamp ─────────────────────────────
     The spring is critically damped so x should never go below
     zero, but a handle that can paint outside its own groove is
     one line away from doing it again the next time somebody
     touches these numbers. \`seen\` is what the transform uses;
     \`x\` stays the honest value the drag wrote. */
  const seen = useTransform(x, (v) => clamp(v, 0, TRAVEL));
  const wide = useTransform([seen, anchor], ([v, a]: number[]) =>
    GRIP + clamp(a - v, 0, TRAVEL));

  /* ── the overshoot becomes a SQUASH ──────────────────────
     The return spring is under-damped now, so it wants to
     carry past zero — and it cannot: at zero the handle is
     already against the end of its track, and four pixels of
     inset is not room to bounce in. Letting it through was
     measured at 42px outside the block when the commit spring
     was under-damped.

     So the position clamps and the energy that would have
     carried it past turns into compression instead. That is
     what a bounce off a wall IS, and it reads as a soft
     landing rather than a stop. \`over\` is the part of the
     spring that went past; the two scales are read off it, and
     they multiply so area is kept — the ball's rule.

     Origin at the LEFT edge, because that is the wall it hit.
     The BounceDot puts its origin at the foot for the same
     reason. */
  const over = useTransform(x, (v) => Math.max(0, -v));
  /* 8%, and the cap is the number that matters rather than the
     divisor: the return overshoots by about 18 units, so any
     real landing reaches the ceiling and the ceiling IS the
     squash. 14 was measured first and reads as a squish; 8 is
     a give. */
  const squash = useTransform(over, (o) => 1 - Math.min(0.08, o / 110));
  const wash = useTransform(seen, (v) => v + GRIP);
  const say = useTransform(seen, [0, TRAVEL * 0.55], [1, 0]);
  /* ── AND IT ANSWERS THE COMMIT, not just x ───────────────
     Read off x alone this faded back IN during the unfurl:
     committing sends x home to zero, so the arrow reappeared
     underneath the word it had just been replaced by. \`shown\`
     is switched by the commit itself, which is the event that
     actually means the arrow is finished. */
  const arrow = useTransform([seen, shown], ([v, on]: number[]) =>
    on * clamp(1 - (v - TRAVEL * 0.55) / (TRAVEL * 0.4), 0, 1));

  /* both scales ride the same product — the swell has to be
     multiplied INTO the transform rather than set as its own
     \`scale\` property, which applies first and would move the
     handle along the track it is sitting on. That bug is
     written up on the liquid toggle. */
  const sx = useTransform(squash, (q) => q * (hot && !held && !done ? SWELL : 1));
  const sy = useTransform(squash, (q) => (1 / q) * (hot && !held && !done ? SWELL : 1));

  const local = (clientX: number) => {
    const box = track.current?.getBoundingClientRect();
    if (!box) return 0;
    /* the block is drawn at a fraction of its own size on the
       wall and larger in the overlay, so a pointer delta in
       screen pixels is not a delta in the component's own. The
       rect's width against the width it is laid out at IS that
       scale, and dividing by it puts the finger back into the
       coordinates the geometry above is written in. */
    const k = box.width / span;
    return (clientX - box.left) / (k || 1);
  };

  const finish = () => {
    setDone(true);
    /* ── x goes to ZERO, and that is the whole morph ────────
       The handle is placed by \`x\` and sized by \`width\`, and on
       commit they move by the same amount in opposite
       directions: x loses TRAVEL, width gains it. Their sum is
       the right edge, so the right edge does not move — the
       handle plants itself where it arrived and opens out
       behind it.

       Sending x to TRAVEL instead was the first version and it
       is worth recording, because it looked plausible in the
       comment and was measurably wrong: the handle stayed at
       the end AND grew to the full width, so its right edge
       came out at 675 against a 375px track and the block
       spilled over its own frame. Both values ride the same
       spring, which is what keeps them in step frame by frame
       rather than merely landing together. */
    anchor.set(x.get());
    animate(shown, 0, { duration: 0.12 });
    animate(x, 0, spring);
    animate(pulse, [1, 0.974, 1], {
      duration: 0.46,
      times: [0, 0.62, 1],
      ease: [0.33, 0.55, 0.2, 1],
      /* a beat behind the unfurl, so it is the landing that
         dips rather than the take-off */
      delay: 0.1,
    });
    beat.current = window.setTimeout(() => {
      setDone(false);
      animate(shown, 1, { duration: 0.2, delay: 0.12 });
      /* and the reset is the anchor coming home with x already
         at zero: the width shrinks from the full track back to
         the handle, so the RIGHT edge sweeps left to the start.
         The unfurl played backwards, which is what it should
         look like. */
      animate(anchor, 0, { type: "spring", stiffness: 380, damping: 34, mass: 0.9 });
    }, HOLD);
  };

  const down = (e: React.PointerEvent) => {
    if (done) return;
    e.stopPropagation();
    /* ── NO OFFSET YET, it is taken at the first MOVE ───────
       Deciding it here is what made the toggle teleport: a
       press away from the handle would set the offset to the
       handle's own middle, and the first move then jumped it
       the whole way in one frame. Taken at the first move, that
       move asks for exactly the position the handle already
       has, and every one after it is a delta. */
    grip.current = { id: e.pointerId, grab: null, moved: false };
    setHeld(true);
    /* it throws if the id is not a live pointer — a synthetic
       event from a test or a rehearsal is exactly that — and
       the drag works without it, so it must not take the grab
       down with it */
    try { track.current?.setPointerCapture(e.pointerId); } catch { /* not live */ }
    watch();
  };

  /* both handlers take the NATIVE event as well as React's,
     because the ones that matter now arrive from \`window\`.
     The two shapes agree on the only two fields read here. */
  const move = (e: PointerEvent | React.PointerEvent) => {
    const g = grip.current;
    if (!g || g.id !== e.pointerId) return;
    const at = local(e.clientX);
    if (g.grab === null) { g.grab = at - x.get(); return; }
    const next = clamp(at - g.grab, 0, TRAVEL);
    if (Math.abs(next - x.get()) > 0.5) g.moved = true;
    x.set(next);
  };

  const up = (e: PointerEvent | React.PointerEvent) => {
    const g = grip.current;
    if (!g) return;
    grip.current = null;
    /* ── AND THE RELEASE IS GUARDED TOO ────────────────────
       It throws when the pointer was never captured, which the
       guard above makes possible — and unguarded it threw
       before setHeld(false), leaving the handle stuck wherever
       the drag ended. Three blocks on this bench have had that
       exact bug; both halves of the pair throw. */
    try { track.current?.releasePointerCapture?.(e.pointerId); } catch { /* never captured */ }
    setHeld(false);
    if (x.get() >= mark) finish();
    else {
      if (g.moved) animate(x, 0, home);
    }
  };

  live.current = { move, up };

  return (
    <div className="sld" style={{ width: span, height: H }}>
      <motion.div
        className="sld-track"
        ref={track}
        style={{ borderRadius: r, scale: pulse }}
        data-held={held || undefined}
        data-done={done || undefined}
        onPointerDown={down}
      >
        {/* the part already crossed. It is not a progress bar —
            it is the ground the handle has covered, which is why
            it ends AT the handle rather than under it */}
        <motion.i
          className="sld-wash"
          aria-hidden="true"
          style={{ width: wash, borderRadius: gripR }}
        />

        <motion.span className="sld-say" style={{ opacity: say }}>
          Slide to confirm
        </motion.span>

        <motion.button
          type="button"
          className="sld-grip"
          onPointerEnter={() => setHot(true)}
          onPointerLeave={() => setHot(false)}
          style={{
            x: seen,
            scaleX: sx,
            scaleY: sy,
            /* ── the morph, and it is ONE number ───────────
                \`wide\` is read off x and the anchor, so the
                width is not being animated at all — it is
                arithmetic on the value the spring is already
                moving. A scale would have dragged the corner
                radius with it, which is the one thing this
                shape cannot afford. */
            width: wide,
            borderRadius: gripR,
          }}
          transition={{ type: "spring", stiffness: 400, damping: 30, mass: 0.7 }}
          aria-label={done ? "Confirmed" : "Slide to confirm"}
        >
          <motion.span className="sld-arrow" style={{ opacity: arrow }} aria-hidden="true">
            <ArrowRight size={20} strokeWidth={2.4} />
          </motion.span>

          {/* the word only exists once there is room for it, and
              it arrives with the width rather than after it */}
          <motion.span
            className="sld-done"
            aria-hidden="true"
            initial={false}
            animate={{ opacity: done ? 1 : 0, scale: done ? 1 : 0.7 }}
            transition={{ duration: 0.18, ease: [0.33, 0.55, 0.2, 1] }}
          >
            <Check size={19} strokeWidth={2.8} />
            Confirmed
          </motion.span>
        </motion.button>
      </motion.div>
    </div>
  );
}
`,css:`/* ══ Slide to confirm ══════════════════════════════════════
   A handle crossing a track, and on commit the handle IS the
   confirmation — it unfurls leftward and fills what it crossed.
   See SlideConfirm.tsx for why the right edge stays put. */
.sld {
  box-sizing: border-box;
  font-family: var(--font-ui);
  color: var(--fill-on, var(--ink));}

.sld-track {
  position: relative;
  width: 100%;
  height: 100%;
  box-sizing: border-box;
  /* ── the track is the SLAB, the handle is the INK ─────────
     It was the other way round — a translucent wash for the
     track on the reasoning that a groove is darker than what
     it is cut into. True, and it has nothing to be cut into:
     this track IS the whole block, so there is no surrounding
     surface and a 7% wash had no opaque ground under it. On a
     dark fill that left a near-invisible track with a dark
     circle sitting on it. Measured: track
     rgba(244,243,241,0.07) over a light stage.

     Slab and ink is the pair the liquid toggle uses and it
     inverts from one rule: white track with a near-black
     handle in light, near-black track with a light handle in
     dark. And on commit the handle fills the track, so the
     confirmed state is a solid ink pill in both. */
  background: var(--fill-slab, var(--card));
  /* the drag is the component; the browser may not take the
     gesture for panning */
  touch-action: none;
  -webkit-user-select: none;
  user-select: none;}

[data-stroke="on"] .sld-track {
  box-shadow: inset 0 0 0 1px var(--pane-edge);}

/* ── the ground already covered ─────────────────────────────
   THE SAME INK AS THE HANDLE, which turns this from a trail
   into the handle's own body. It was an 8% tint, and a tint is
   read as a progress bar: a track filling up behind a knob that
   slides along it. Two objects.

   The geometry was already right for one. This runs from the
   left pad to \`x + GRIP\` — the handle's RIGHT edge, not its
   left — with the handle's own corner radius, so the pair
   describes a single capsule with a rounded cap at each end and
   the handle's cap doing the work at the leading edge. Only the
   colour said otherwise. Matched, there is no seam to find: the
   dot stretches out of the corner it started in and the far end
   is still the dot.

   It cannot be the ink at 100% and also sit UNDER the words. */
.sld-wash {
  position: absolute;
  left: 4px;
  top: 4px;
  bottom: 4px;
  background: var(--fill-on, var(--ink));
  /* ── above the label, so it WIPES it ─────────────────────
     Beneath it, the label's remaining ink sat on a surface its
     own colour and went muddy rather than away — the fade
     reaches zero at 55% of the travel and the capsule's edge
     arrives at the first letter around 30%, so there is a
     stretch where the two overlap. Painted over, the words are
     covered by the advancing cap instead: they leave under a
     rounded edge that is the handle's own shape, which reads as
     the thing eating them rather than as a wipe.
     The handle is \`auto\` and later in the DOM, and \`auto\` loses
     to any z-index at all, so it needs one of its own. */
  z-index: 1;
  pointer-events: none;}

.sld-say {
  position: absolute;
  inset: 0;
  display: grid;
  place-items: center;
  /* ── CENTRED IN THE PILL, not in the room beside it ──────
     It was inset by the handle's width, on the reasoning that
     the words should be centred in the space actually left to
     them. That is the right rule for a label sharing a row with
     a control, and the wrong one here: the track IS the object,
     and a label pushed 24px right of its middle reads as
     off-centre rather than as considerate — there is nothing
     for it to be centred against except the pill.

     It costs nothing at rest — the words start well clear of
     the handle — and the overlap it was avoiding is now the
     point, since the capsule wipes them as it comes. */
  font-size: 14px;
  font-weight: 500;
  letter-spacing: -0.006em;
  color: rgba(var(--fill-on-rgb, var(--ink-rgb)), 0.45);
  pointer-events: none;
  white-space: nowrap;}

.sld-grip {
  position: absolute;
  left: 4px;
  top: 4px;
  height: 48px;
  padding: 0;
  border: 0;
  background: var(--fill-on, var(--ink));
  color: var(--fill-slab, var(--card));
  cursor: grab;
  /* ── it takes the pointer now, and the track still wins ───
     It was \`none\`, so the track owned the gesture outright.
     The handle has to know when a cursor is ON it to swell,
     and a press still reaches the track by BUBBLING — the
     handle is inside it — so nothing about the drag changed.
     Once the track captures the pointer every later event is
     retargeted there anyway, which is why a drag that wanders
     off the handle keeps reporting. */
  pointer-events: auto;
  /* the wall it lands against, so the squash compresses
     toward the end of the track rather than about its middle */
  transform-origin: 0% 50%;
  /* it is placed by a motion value, so nothing here may
     transition \`transform\` or the two fight every frame */
  transition: none;
  /* over the wash, which had to claim a layer to cover the
     label — see .sld-wash */
  z-index: 2;}

.sld-track[data-held] .sld-grip { cursor: grabbing; }

/* ── two contents, both ABSOLUTE ────────────────────────────
   Stacked so neither has to make room for the other and the
   handle's width is free to be whatever the morph says it is.

   They were one grid cell, and that put the arrow 21.3px right
   of the handle's centre. "Confirmed" is 59px wide and the
   resting handle is 42, so the shared track was wider than the
   box holding it — and an overflowing grid item resolves
   \`center\` to \`start\`, which shoved both to one side. The same
   rule caught the carousel inside the Pro sheet.

   Absolute with \`inset: 0\` has no such rule: each fills the
   handle and centres its own content, at every width the morph
   passes through, and neither can size the handle. */
.sld-arrow,
.sld-done {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  font-size: 14px;
  font-weight: 500;
  letter-spacing: -0.006em;
  white-space: nowrap;
  pointer-events: none;}

@media (prefers-reduced-motion: reduce) {
  .sld-done { transition-duration: 1ms; }
}`,tokens:[`--card`,`--fill-on`,`--fill-on-rgb`,`--fill-slab`,`--font-ui`,`--ink`,`--ink-rgb`,`--pane-edge`],deps:[`framer-motion`,`lucide-react`],stubs:[]},picker:{tsx:`import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, ChevronDown } from "lucide-react";

/* AVATARS was Bencho's own pictures, which are not licensed
   to travel. Point this at yours. */
const AVATARS: Record<string, string> = {};

/* ══ Assignees ════════════════════════════════════════════
   A pill that opens a list, and fills up with faces as you
   assign them. One, two, four — the pill grows to hold them
   and they overlap into a stack rather than a row.

   It was called "People picker", which named the widget
   rather than the job. What this is FOR is putting names
   against a thing — assigning a task, adding contributors —
   and the pill is the answer to "who is on this".

   THE PILL IS THE READOUT. There is no count badge and no
   "3 selected" caption: the faces themselves say who, which
   is the thing a person actually wants back. A number tells
   you how many you picked; a stack of faces tells you whether
   you picked the right ones. */

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

/* ── the cast ──────────────────────────────────────────────
   The same four pictures the rest of the bench uses — there
   are only four in avatars.ts and every block that needs
   people draws from them — under names of their own, which is
   what the selection list and the reorder list both do. Four
   blocks sharing one set of names would read as one dataset
   being shown four ways rather than four components. */
/* The names follow the PICTURES. avatars.ts keys are \`kai\`,
   \`mara\`, \`sofia\`, \`ines\` and none of them describes who is in
   the photograph — the reorder list and the selection list use
   the same four faces under different names, so the key is a
   slot rather than a person. Checked against the images at
   size rather than off the thumbnails: two men, two women. */
const CAST = [
  { id: "kai", name: "Adam Marsh", role: "Design" },
  { id: "mara", name: "Priya Raman", role: "Research" },
  { id: "sofia", name: "Nora Wilder", role: "Engineering" },
  { id: "ines", name: "Marco Bellini", role: "Product" },
];

/* the block's own box. Reserved for the list OPEN, so closing
   it does not resize the card underneath — the same bargain
   the selection list makes, and for the same reason: a block
   that changes height when you press it makes the wall jump. */
const W = 264;
const H = 268;

/* the faces in the pill */
const FACE = 28;
const CORNER = 22;
/* how much of each face the next one covers, px */
const LAP = 10;

/* ── the other way to stack ────────────────────────────────
   A row of overlapping faces is the honest default: it says
   who, in order, and it grows sideways as you add people. But
   it grows sideways, and a pill in a dense toolbar cannot
   always afford that.

   So the second arrangement packs the same four into the
   footprint of ONE. Nothing overlaps — that is the whole point
   of it, and the reason it is not simply "a tighter row". A
   row hides parts of faces behind other faces; the quad shows
   all of every face and pays for it in size.

   The box is FACE across whatever the count, so the pill in
   this mode does not grow at all. That is the trade the mode
   exists to make, and drawing one face big and four faces
   small is what makes it visible: the box does not fill up,
   it SUBDIVIDES.

   Three is the awkward count. It fills reading order and
   leaves the last cell empty, which looks like a gap and is
   actually the point: the quad is a fixed set of four slots,
   and three people occupy three of them. Centring the odd one
   balances the picture but breaks the grid — the face lands
   where no cell is, and adding the fourth person then shunts
   it sideways for no reason the eye can name. */
const quad = (n: number, gut: number) => {
  const cell = (FACE - gut) / 2;
  const s = cell / FACE;
  const a = cell / 2;          /* centre of the near cell */
  const b = FACE - cell / 2;   /* centre of the far one */
  const m = FACE / 2;
  if (n <= 1) return [{ cx: m, cy: m, s: 1 }];
  if (n === 2) return [{ cx: a, cy: m, s }, { cx: b, cy: m, s }];
  if (n === 3) return [{ cx: a, cy: a, s }, { cx: b, cy: a, s }, { cx: a, cy: b, s }];
  return [
    { cx: a, cy: a, s }, { cx: b, cy: a, s },
    { cx: a, cy: b, s }, { cx: b, cy: b, s },
  ];
};

export function Picker({
  /* the pill's corner and the card's, px */
  corner = CORNER,
  /* how far the faces overlap, px — 0 is a row of separate
     circles, which is a real answer and not a broken one */
  overlap = LAP,
  /* "Row" or "Grid" — see quad() above */
  stack = "Row",
}: {
  corner?: number;
  overlap?: number;
  stack?: string;
} = {}) {
  /* open, and with two already chosen. A picker drawn shut is
     a pill with a word in it: true of the component and
     useless as a picture of it. This is the state worth
     landing on — the pill doing its job and the list showing
     why. */
  const [open, setOpen] = useState(true);
  const [picked, setPicked] = useState<string[]>(["kai", "mara"]);

  const r = clamp(corner, 0, 26);
  const lap = clamp(overlap, 0, 22);
  const grid = stack === "Grid";

  /* Overlap still means something in the quad, because a knob
     that goes dead in half the modes is a knob you have to
     explain. It reads as PACKING there rather than as covering:
     4px of air at nought, 2px at full. It never reaches zero —
     "they never touch" is the arrangement's one promise, and a
     slider is not allowed to break it. */
  const spots = quad(picked.length, 4 - (lap / 22) * 2);

  /* ── the width is COMPUTED, not measured ─────────────────
     Framer's \`layout\` would animate this by measuring screen
     rectangles, and every block on this bench is drawn at a
     fraction of its own size — see Gooey.tsx. A width worked
     out from the count is the same number at any zoom, and CSS
     can transition it without knowing where the block is. */
  const rail = !picked.length
    ? 0
    : grid
      /* one face wide at every count — the quad's whole bargain */
      ? FACE
      : FACE + (picked.length - 1) * (FACE - lap);

  /* ── IT DOES NOT CLOSE ON AN OUTSIDE PRESS ───────────────
     It did, and that is the right behaviour for a dropdown in
     an application — the note that used to be here called it
     the one thing every dropdown has to do. It is the wrong
     behaviour for a block on this wall.

     Measured: one real click anywhere on the page collapsed
     the list, and nothing brought it back — so the card spent
     the rest of the session showing a pill and nothing else,
     which is a demonstration of a third of the component. The
     same class of fault as a demo that leaves a toggle on.

     The pill is still the toggle, so it is still dismissible
     by the person actually using it. What is gone is the case
     where something you did to a DIFFERENT block put this one
     away.

     Anyone lifting this into a real interface wants the
     listener back; it is four lines and the reason it is not
     here is the wall, not the pattern. */

  const toggle = (id: string) => {
    setPicked((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));
  };

  return (
    <div
      className="pik"
      style={{
        width: W,
        height: H,
        /* ── concentric, and it follows the knob ───────────
           The row's hover pad was a flat 12 against a card cut
           at 22, which reads squarer than the box holding it.
           The rule the rest of this bench uses is the radius
           of a thing inside another, LESS the gap between them
           — the card's 6px padding here — so 22 gives 16.

           Published from here rather than written in the
           stylesheet because the card's corner is a knob: at 0
           the pair is square together and at 26 both are as
           round as they go, instead of the pad being right at
           one setting and wrong at the rest. */
        "--pik-row-r": \`\${Math.max(0, r - 6)}px\`,
      } as React.CSSProperties}
    >
      <button
        className="pik-pill"
        style={{ borderRadius: r }}
        onClick={() => { setOpen((v) => !v); }}
        aria-expanded={open}
        aria-haspopup="listbox"
      >
        {/* ── the faces ─────────────────────────────────────
            Absolutely placed inside a rail whose width is the
            arithmetic above, so the pill grows and shrinks by
            one CSS transition rather than by anything watching
            the DOM.

            Reversed z-order: the first face sits on top of the
            second, so the stack reads left to right the way the
            list does. Painted the other way the newest arrival
            covers everyone before it, and adding a fourth
            person looks like losing the first three. */}
        <span className="pik-rail" style={{ width: rail }}>
          <AnimatePresence initial={false}>
            {picked.map((id, i) => {
              /* ── EVERY face is placed by its transform ─────
                 It used to ride on \`left\`, which cannot carry
                 the quad: that one needs a size and two axes,
                 and a face swapping arrangements has to travel
                 rather than teleport. One vector and one scale
                 describe both layouts, so switching modes is
                 the same animation as arriving. */
              const spot = grid ? spots[Math.min(i, spots.length - 1)] : null;
              const tx = spot ? spot.cx - FACE / 2 : i * (FACE - lap);
              const ty = spot ? spot.cy - FACE / 2 : 0;
              const sc = spot ? spot.s : 1;
              return (
              <motion.span
                key={id}
                className="pik-face"
                style={{ zIndex: CAST.length - i }}
                /* ── a face lands, it does not fade in ──────
                   It drops from slightly above with a turn on
                   it and overshoots on the way to rest, so
                   adding somebody reads as a token being put
                   down. Leaving is the same move backwards and
                   quicker — you are removing a name, not
                   watching an animation.

                   The rotation is small and it is the reason
                   this feels different from a scale: a circle
                   scaling is a circle, and a circle scaling
                   while it turns is an object.

                   The drop lands at \`ty\`, not at nought, and
                   the pop lands at \`sc\`, not at one: in the
                   quad a face's rest is wherever its cell is
                   and however big its cell is. */
                initial={{ scale: 0.2 * sc, opacity: 0, x: tx, y: ty - 10, rotate: -22 }}
                animate={{ scale: sc, opacity: 1, x: tx, y: ty, rotate: 0 }}
                exit={{ scale: 0.2 * sc, opacity: 0, x: tx, y: ty - 6, rotate: 14 }}
                /* ── two springs, and the reason is the knob ──
                   Position and size are also what the Overlap
                   slider moves, and a slider wants a follower,
                   not a bouncer: dragged to an end, a 0.48-zeta
                   spring wobbles for a third of a second after
                   the thumb has stopped. So x, y and scale get
                   a tight one that tracks.

                   Rotate keeps the loose spring, and it is the
                   half that was carrying the character anyway —
                   the face still rocks past level as it sets
                   down. Nothing drags the rotation, so nothing
                   is waiting on it. */
                transition={{
                  type: "spring", stiffness: 600, damping: 21, mass: 0.8,
                  x: { type: "spring", stiffness: 660, damping: 34, mass: 0.7 },
                  y: { type: "spring", stiffness: 660, damping: 34, mass: 0.7 },
                  scale: { type: "spring", stiffness: 660, damping: 34, mass: 0.7 },
                  opacity: { duration: 0.12 },
                }}
              >
                <img src={AVATARS[id]} alt="" draggable={false} />
              </motion.span>
              );
            })}
          </AnimatePresence>
        </span>

        {/* ── what the pill says with nothing in it ────────
            It said "Assign", which is an instruction — and the
            pill is a READOUT: with faces in it, it reports who
            is on this, so with none in it, it should report
            that nobody is. One word, the state rather than the
            verb, and it goes the moment there is a face,
            because a label beside three pictures is the control
            describing itself instead of answering. */}
        {picked.length === 0 && <span className="pik-say">Unassigned</span>}

        <ChevronDown className="pik-chev" size={16} strokeWidth={2.2} aria-hidden="true" />
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            className="pik-card"
            style={{ borderRadius: r }}
            role="listbox"
            aria-multiselectable="true"
            /* ── it unfolds OUT OF the pill ──────────────────
               The origin is the card's top-left, which is the
               pill's own left edge, so it opens down and out
               from the corner it belongs to rather than growing
               from its middle like a box appearing.

               NOT a goo morph, and that was considered first:
               the reorder list took the metaball out from
               between its card and its button for the reason
               that applies here too — two separate objects
               joined by a bridge read as welded, not as one
               opening. A metaball is for a single body changing
               shape, which is also why the faces do not get one:
               they are photographs, and the filter thresholds
               alpha.

               The scale starts high — 0.86 across, 0.72 down —
               because a card is a rounded rectangle and a scale
               drags its corner radius with it. From a third of
               its height the corners arrive visibly squashed;
               from three quarters, with the spring doing the
               work, they do not. The BOUNCE is where the
               character is, not the distance. */
            initial={{ opacity: 0, y: -10, scaleX: 0.86, scaleY: 0.72 }}
            animate={{ opacity: 1, y: 0, scaleX: 1, scaleY: 1 }}
            exit={{ opacity: 0, y: -8, scaleX: 0.92, scaleY: 0.86 }}
            transition={{
              /* zeta about 0.63 — it goes past and comes back,
                 which is the whole of "bubbly" */
              type: "spring", stiffness: 460, damping: 23, mass: 0.9,
              opacity: { duration: 0.12 },
            }}
          >
            {CAST.map((p) => {
              const on = picked.includes(p.id);
              return (
                <motion.button
                  key={p.id}
                  className="pik-row"
                  role="option"
                  aria-selected={on}
                  data-on={on || undefined}
                  onClick={() => toggle(p.id)}
                  /* they deal out under the card rather than
                     arriving with it — four rows appearing at
                     once is a panel, four arriving in order is
                     a list being handed to you. Fast and close
                     together: 40ms apart is a stagger you feel
                     rather than one you wait through. */
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{
                    type: "spring", stiffness: 620, damping: 34, mass: 0.7,
                    delay: 0.04 * CAST.indexOf(p) + 0.03,
                  }}
                >
                  <img className="pik-av" src={AVATARS[p.id]} alt="" draggable={false} />
                  <span className="pik-who">
                    <span className="pik-name">{p.name}</span>
                    <span className="pik-role">{p.role}</span>
                  </span>
                  {/* the box is always drawn; only the tick
                      arrives. A mark that appears WITH its own
                      container reads as the row growing a
                      control, rather than as the control being
                      answered */}
                  <span className="pik-mark">
                    <AnimatePresence initial={false}>
                      {on && (
                        <motion.span
                          className="pik-tick"
                          initial={{ scale: 0.4, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          exit={{ scale: 0.4, opacity: 0 }}
                          transition={{ type: "spring", stiffness: 600, damping: 28, mass: 0.6 }}
                        >
                          <Check size={12} strokeWidth={3} />
                        </motion.span>
                      )}
                    </AnimatePresence>
                  </span>
                </motion.button>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
`,css:`/* Inter, not the mono class it carried. A handle is a name,
   not a code — nothing here needs a fixed advance. */
/* 11.5, which is .pik-role's. The names in these two lists
   were matched at 13 already; the second lines were a pixel
   apart, and one point of difference between two lists of
   people reads as one of them being set slightly wrong rather
   than as a distinction anybody meant. */
/* and the same INK as .pik-role, by the same route: the fill's
   own on-colour at 45%, falling back to the page's when no
   fill is set. --ink-5 is a fixed grey off the light ramp, so
   under a dark Fill — which this block takes — the handle
   stayed a mid grey on a near-black row while the name above
   it inverted properly. An alpha of the row's own ink cannot
   come apart from it. */
.rst-at {
  font-size: 11.5px;
  letter-spacing: 0;
  color: rgba(var(--fill-on-rgb, var(--ink-rgb)), 0.45);}

/* ══ People picker ══════════════════════════════════════════
   A pill that fills with faces, and the list it fills from.
   See Picker.tsx — in particular why the rail's width is an
   inline number rather than anything measured. */
.pik {
  position: relative;
  box-sizing: border-box;
  font-family: var(--font-ui);
  color: var(--fill-on, var(--ink));}

.pik-pill {
  position: relative;
  z-index: 2;
  display: inline-flex;
  align-items: center;
  gap: 10px;
  height: 44px;
  /* tighter on the left, because a face is a filled circle and
     a word is not: 16 of air beside "Add people" is the same
     amount of air as 8 beside a picture */
  padding: 0 12px 0 8px;
  border: 0;
  background: var(--fill-slab, var(--card));
  /* ── NO SHADOW, AND NO HAIRLINE EITHER ────────────────────
     Both are gone. The ring came back only when Stroke asks
     for it — it carried a permanent one, which made that
     switch a control reporting a state it was not producing,
     the fault the tilt card and the wheel both had.

     The drop shadow went with it. Nothing here needs lifting:
     the pill and the card are the fill's own slab and they sit
     on the block's grey ground, which separates them on its
     own. A shadow under a shape that already reads is the
     component insisting it is floating. */
  color: inherit;
  font: inherit;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;}

[data-stroke="on"] .pik-pill { box-shadow: 0 0 0 1px var(--pane-edge); }

.pik-pill:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px rgba(var(--fill-on-rgb, var(--ink-rgb)), 0.45);}

/* ── the rail the faces sit in ──────────────────────────────
   Its width is the whole animation. The faces are absolute
   inside it, so none of them moves when another arrives — the
   rail simply has more room, and the pill is sized by it.
   Nothing here measures anything. */
.pik-rail {
  position: relative;
  flex: none;
  height: 28px;
  transition: width 300ms cubic-bezier(0.33, 0.55, 0.2, 1);}

.pik-face {
  position: absolute;
  /* both corners pinned: the face is placed by its transform,
     in the row and in the quad alike, so \`left\` is an origin
     rather than a position */
  top: 0;
  left: 0;
  width: 28px;
  height: 28px;
  border-radius: 999px;
  overflow: hidden;
  /* the ring is the CARD's colour, not white: it is the gap
     between two overlapping faces, so it has to be whatever is
     behind them or the stack grows a halo in dark mode */
  box-shadow: 0 0 0 2px var(--fill-slab, var(--card));}

.pik-face img { width: 100%; height: 100%; object-fit: cover; display: block; }

/* with no faces the rail collapses to nothing but the pill's gap
   still sits in front of the word; pull it back so the text is
   inset 12 from the edge, matching the pill's own right padding */
.pik-say { margin-left: -6px; color: var(--fill-on, var(--ink)); }

/* ── the chevron IS the hover state ─────────────────────────
   With the shadow gone the pill had nothing left to answer the
   cursor with, and a fill appearing behind it would be a second
   shape arriving on a control whose whole subject is shapes —
   the palette's refresh button makes the same call. The glyph
   goes to a stronger ink instead: same thing said, nothing new
   on screen. */
.pik-chev {
  flex: none;
  margin-left: -2px;
  color: rgba(var(--fill-on-rgb, var(--ink-rgb)), 0.4);
  transition: rotate 240ms cubic-bezier(0.33, 0.55, 0.2, 1), color 150ms ease;}

.pik-pill:hover .pik-chev { color: rgba(var(--fill-on-rgb, var(--ink-rgb)), 0.75); }

.pik-pill[aria-expanded="true"] .pik-chev { rotate: 180deg; }

/* ── the list ───────────────────────────────────────────────
   Absolute, so opening it moves nothing. The block reserves
   the room for it either way — see the note in Picker.tsx. */
.pik-card {
  position: absolute;
  top: 54px;
  left: 0;
  right: 0;
  z-index: 1;
  box-sizing: border-box;
  padding: 6px;
  background: var(--fill-slab, var(--card));
  /* ── it unfolds from the PILL'S corner ────────────────────
     Top left, not the middle: the pill starts at this same
     left edge, so the card opens down and out from under it
     rather than growing symmetrically out of its own centre,
     which is what a box appearing does. */
  transform-origin: 0 0;}

[data-stroke="on"] .pik-card { box-shadow: 0 0 0 1px var(--pane-edge); }

.pik-row {
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
  height: 48px;
  padding: 0 8px;
  border: 0;
  /* the card's corner less its 6px padding — set in Picker.tsx
     so it tracks the Corner knob; 16 is the value at the
     default 22 */
  border-radius: var(--pik-row-r, 16px);
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
  transition: background 140ms ease;}

.pik-row:hover { background: rgba(var(--fill-on-rgb, var(--ink-rgb)), 0.05); }

.pik-row:focus-visible {
  outline: none;
  background: rgba(var(--fill-on-rgb, var(--ink-rgb)), 0.07);}

.pik-av {
  flex: none;
  width: 32px; height: 32px;
  border-radius: 999px;
  object-fit: cover;
  display: block;}

.pik-who { display: flex; flex-direction: column; gap: 1px; min-width: 0; flex: 1; }

/* ── the same type as the other two lists ────────────────
   It was 13.5 at 500 with a touch of negative tracking, which
   is a LABEL's setting — right for a word that names a control
   and wrong for a row of people. The selection list and the
   reorder list both set their names at the regular weight, and
   they are the same object: a face, a name, a thing to press.
   Three lists on one bench reading as three different type
   systems is the fault; matching \`.rst-name\` is the fix. */
.pik-name {
  font-size: 13px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;}

.pik-role {
  font-size: 11.5px;
  color: rgba(var(--fill-on-rgb, var(--ink-rgb)), 0.45);}

/* ── the mark ───────────────────────────────────────────────
   Drawn at rest as an empty ring and filled when it is on, so
   the row always shows that it CAN be chosen. A control that
   only appears once used is one you have to guess at first. */
.pik-mark {
  flex: none;
  display: grid;
  place-items: center;
  width: 18px; height: 18px;
  /* ── a rounded square, not a disc ────────────────────────
     One radius for both states, because it is one box: the
     empty mark and the ticked one are the same square with the
     fill switched, so the shape cannot disagree with itself
     between rows. The radius is 0.3 of the side — round enough
     to belong to the pill and the card above it, square enough
     that a row of four reads as a column of checkboxes rather
     than as a second set of avatars beside the real ones.

     18, down from 20. The mark answers the row; it is not the
     subject of it, and at 20 against a 28px face it was close
     enough in size to read as the second circle in a pair. Two
     pixels is enough to put it back behind the name. */
  border-radius: 5.5px;
  box-shadow: inset 0 0 0 1.5px rgba(var(--fill-on-rgb, var(--ink-rgb)), 0.22);
  transition: background 160ms ease, box-shadow 160ms ease;}

.pik-row[data-on] .pik-mark {
  background: var(--fill-on, var(--ink));
  box-shadow: inset 0 0 0 1.5px var(--fill-on, var(--ink));}

.pik-tick {
  display: grid;
  place-items: center;
  color: var(--fill-slab, var(--card));}

@media (prefers-reduced-motion: reduce) {
  .pik-rail, .pik-chev { transition-duration: 1ms; }
}`,tokens:[`--card`,`--fill-on`,`--fill-on-rgb`,`--fill-slab`,`--font-ui`,`--ink`,`--ink-rgb`,`--pane-edge`],deps:[`framer-motion`,`lucide-react`],stubs:[`AVATARS`]},checklist:{tsx:`import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

/* ══ Checklist ════════════════════════════════════════════
   Three tasks, and the only thing this block does is cross
   one out.

   ONE SPRING PER ROW, AND EVERYTHING IS READ OFF IT. The box
   filling, the tick drawing, the rule crossing the words and
   the words giving up their ink are four readings of a single
   number, not four things animated toward the same moment.
   With four transitions there are four chances for one to
   arrive early and break the illusion that this is one event;
   with one number there are none — the same rule the player
   follows, and the reason nothing in this component's
   stylesheet carries a transition of its own.

   WHERE THE OVERSHOOT IS ALLOWED, AND WHERE IT IS NOT. A
   spring goes past its target and comes back, which is what
   makes a check feel like a press rather than a state change
   — but only some of these can survive that. The fill takes
   the raw value, so the box swells past full and settles. The
   TICK and the RULE take it clamped: a tick that overshoots
   draws itself past its own end and pulls back, which is a
   glitch rather than a bounce, and a rule that overshoots
   runs off the end of the word it is crossing out.

   One spring, two readings of it, and the difference is one
   \`clamp\`. */

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));
const mix = (a: number, b: number, t: number) => a + (b - a) * t;

const W = 300;
/* the inset, and it is the SAME on all four sides — which is
   not what \`padding: 14px\` gives you here. See the note where
   it is used. */
const PAD = 14;
/* 40, down from 52. The gap between two tasks is whatever the
   row has left over after the box, twice — so 52 put 30px
   between them and read as a list of three separate things.
   40 leaves 18, which is a list. */
const ROW = 40;
/* 18, against 14px text. 22 was the first number and it had
   no reasoning behind it beyond looking balanced on its own —
   which is the trap with a control next to type: a checkbox is
   sized against the LINE it sits beside, and at 22 it was
   half again the cap height of the words it belonged to and
   read as the subject of the row rather than as its switch. */
const BOX = 18;
const CORNER = 18;
const BOUNCE = 50;

/* ── the rule follows the tick, it does not race it ────────
   Both are read off the same spring, but the rule starts a
   tenth of the way in and finishes a little early — so the
   box answers first and the words are crossed out after,
   which is the order the two things actually happen in when a
   person ticks something off a list. Started together they
   read as one wipe across the whole row; started apart they
   read as cause and effect.

   It is a window on the same number rather than a second
   timer, so there is nothing to keep in step. */
const LAG = 0.12;
const RUN = 0.72;

/* ══ the finish ═══════════════════════════════════════════
   Tick the last open task and the list FALLS DOWN.

   What was here was a celebration: a box that bounced, three
   marks that redrew, the rows gathering in, a squish, and a
   four-point glint out of the middle of the card. All of it
   ran off one clock, which was the right way to build the
   wrong idea — five flourishes agreeing with each other is
   still five flourishes, and the glint in particular was a
   sparkle sitting on top of a list, which is what every
   "well done" animation on the internet already is.

   This is one idea instead. Finishing the list takes the
   floor out from under it: the three rows stop being held up,
   fall, and land in a heap on the bottom edge of the card.
   Nothing congratulates you. The list is simply over, and it
   behaves like something that is over.

   And the card is the size it always was. See the note on the
   collapse below: the distance comes out of the list closing
   up, not out of empty floor added under it. */

/* ── THE FALL IS A COLLAPSE, not a drop ───────────────────
   The card is exactly as tall as its three rows again, which
   is where it started and where it belongs — a checklist with
   a hundred pixels of empty floor under it is a checklist that
   looks unfinished. So there is nowhere to fall TO, and the
   distance has to come from somewhere else.

   It comes from the rows closing up. A row is 40px tall and
   the thing you can see in it — the box and the words — is
   barely twenty: the rest is the reason the whole row is a
   target rather than the checkbox alone. Standing in a list
   those gaps are what makes it a list. Lying in a heap they
   are nothing, and the slips settle against each other.

   So the heap is tighter than the list by twice that slack per
   row, and THAT is the fall. The bottom row barely moves, the
   top one travels the whole compaction, and each lands where
   the one below it stopped. */

/* ── what a row actually looks like ───────────────────────
   The taller of its checkbox and its line of type, and NOTHING
   added on top of that — both MEASURED, because the line box
   of 14px type is not 14px and a guess at it is a guess at how
   close two slips can lie. Derived from the Box knob, so the heap
   stays tight at every setting of it rather than at the
   default one.

   It carried four pixels of air at first, on the reasoning
   that a slip wants a margin. It does not: the slip is the
   card's own colour, so its edge is invisible and the margin
   is not protecting anything — the only thing that must not
   happen is a neighbour's slip covering this row's words, and
   the derived gap already guarantees with room to spare. What the
   four pixels DID do was eat the fall, because every pixel of
   slack a slip keeps is a pixel the heap cannot close up.
   Measured at the largest Box: 10px of collapse with the
   padding, 18 without it. */
const BODY = (side: number, line: number) => Math.max(side, line);

/* how long the FURTHEST fall takes; the others are shorter in
   proportion, because they are all under one gravity */
const DROP_MS = 0.46;
/* how far it comes back up off the floor, at most. A landing
   with no bounce at all reads as a card being placed — but a
   9px rebound on an 8px fall reads as a trampoline, so it is
   capped against the distance actually travelled. */
const REBOUND = 8;
/* Framer wants an array it can own, and \`as const\` alone hands
   it a readonly one — spread at the call site */
const FALL_EASE = ["easeIn", "easeOut", "easeIn"] as const;

/* how long the heap lies there before the list comes back */
const HOLD = 3000;

/* ── the heap ──────────────────────────────────────────────
   Three slips landing on each other do not land square, and
   the tilt is what stops this reading as the list closing up.
   Small — three degrees is a shrug, not a mess — and different
   per row so the eye cannot find a pattern in it. */
/* ── THE TILT IS THE OVERHANG ──────────────────────────────
   It was a hand-written fan: five numbers, the same lean every
   time, whatever was written on the slips. Which is fine until
   you notice what it is pretending to be. A slip lying on
   another slip is held up by exactly as much of it as there is
   underneath; the rest hangs, and what hangs, tips.

   So the lean comes out of the WORDS now. Each row is measured
   — the box, the gap and the line of type, to the end of the
   text — and a slip that is longer than the one it lands on
   overhangs to the right by the difference and leans that way.
   A shorter one is fully carried and adds nothing of its own.

   It ACCUMULATES from the floor up, because a slip resting on
   a tilted slip starts tilted: the bottom one lies flat on the
   card, and every one above inherits the lean of what it is
   lying on plus whatever its own overhang adds. That is what
   makes a heap of long-then-short read differently from
   short-then-long, which is the whole point of measuring.

   The response SATURATES rather than being a rate. Straight
   degrees-per-pixel put the default list at 0.9 degrees, which
   is a heap you have to be told is leaning, and then needed a
   clamp anyway the moment somebody typed a long task. This
   curve is at two degrees for the sixteen pixels those three
   tasks differ by, four and a half by sixty, and never reaches
   six — which is the angle where a slip stops looking like it
   is resting on something and starts looking dropped. */
const MAX_LEAN = 6;
const REACH = 40;
const leanOf = (over: number) => MAX_LEAN * (1 - Math.exp(-over / REACH));
/* the sideways untidiness, which the words have no opinion
   about — this is the one thing left that is just chosen */
const DRIFT = [-5, 4, -2, 5, -3];

/* ── the daylight between two slips ───────────────────────
   Tilting a slip moves its ends: two of them leaning by
   different amounts converge on one side, and if they converge
   by more than the gap the upper one's edge covers the lower
   one's words. So the spacing is computed from the leans
   rather than picked — and since the leans now come from the
   text, per render.

   MEASURED WHERE THE INK IS, not across the row. This used to
   ask what the slips do at x = 272, which is the end of the
   ROW — and the row is invisible. A slip is the card's own
   colour; the only place it can hide anything is where there
   is something under it to hide, and the words stop at 131 to
   147px. Asking the question at the end of the row inflated
   the gap to 5.7px for a two degree lean when the real answer
   at the end of the WORDS is 0.4, and pushed every slip five
   pixels apart for a collision that could not happen.

   Rotation is about the row's middle, so a point at x is
   displaced by (x - middle) * sin. The worst case between two
   slips is at the far end of the longer one's ink. */
const SPAN = W - PAD * 2;
const MID = SPAN / 2;
const sin = (deg: number) => Math.sin((deg * Math.PI) / 180);
const gapFor = (leans: number[], runs: number[]) =>
  1 +
  Math.max(
    0,
    ...leans.slice(1).map((below, i) => {
      const ink = Math.max(runs[i] ?? MID, runs[i + 1] ?? MID);
      return Math.max(0, (ink - MID) * (sin(leans[i]) - sin(below)));
    }),
  );

/* ── what is on the list ───────────────────────────────────
   Three real lines, short enough that the rule crosses each
   one in a single visible stroke and different enough in
   length that you can see it is measuring the WORDS rather
   than the row. Placeholder text would have made them the
   same length and lost that. */
const TASKS = ["Book the studio", "Send the estimate", "Pick a typeface"];

/* ── and it can be added to ────────────────────────────────
   Five, which is three that come with it and two of your own.
   A cap rather than an open list because the card is a fixed
   box on a wall of fixed boxes: something has to say when it
   is full, and a number you can see the end of is kinder than
   a scrollbar appearing inside a block.

   The spare row goes when the list is full — an "add" that
   cannot add is a control lying about itself. */
const MAX = 5;

/* ── inlined from ./spring ──────────────────────── */
/* ── one spring, for everything that settles ───────────────
   The maths was already on this bench twice, copied by hand:
   Humidity's wheel and Brightness's column both accumulate
   velocity toward a target, damp it, and snap when both the
   delta and the velocity fall under 0.02. Two copies is a
   coincidence; five would be a policy, so it comes out here
   before the elastic blocks are written against it.

   The two shipped copies are deliberately NOT refactored onto
   this. They work, they are tuned, and rewriting the innards
   of two live components to prove a point about duplication
   is how a good afternoon becomes a bad one. This is the one
   new code uses.

   Frames, not milliseconds. \`dt\` is expressed in sixtieths of
   a second and the damping is RAISED to it rather than
   multiplied by it, so a dropped frame decays the same amount
   of energy as the two frames it replaced. Multiplying is the
   version that makes a spring behave differently on a busy
   page, which is the hardest kind of bug to see.

   The loop parks itself the moment the value has settled.
   CLAUDE.md is not complimentary about the one permanent
   requestAnimationFrame already on this bench and there is no
   case for five more. */

/* 0..100 into the two numbers a spring actually has.

   50 is what Humidity and Brightness were tuned at, which is
   the rule every elastic knob on this bench follows — see
   lab/motion. Turn the panel to the middle and nothing has
   changed.

   Both ends have to be usable, which is what fixes the range:
   at 0 it is slow and heavy and still arrives, at 100 it is
   quick with a visible overshoot, and nowhere in between does
   it ring for longer than it takes to read. */
/* The pair is chosen by DAMPING RATIO and then written back
   as stiffness and decay, because the ratio is the thing a
   person is actually setting and the two numbers on their own
   do not say what they add up to.

     zeta = -ln(d) / (2 * sqrt(k))

   The first version of this ran 0.06..0.26 stiffness against
   0.93..0.74 decay, which reads as a sensible spread and is
   not one: it puts zeta between 0.15 and 0.16 across the
   WHOLE range, so every setting overshot by about sixty per
   cent and the knob only changed how fast it did it. Pull's
   return went 130px past its own resting position and lifted
   the content off the top of the card.

     0   → zeta ~0.85, heavy, arrives without a ring
     50  → zeta ~0.41, near where Humidity and Brightness sit
     100 → zeta ~0.20, lively, two visible rebounds

   Both ends shippable, which is the constraint that fixed the
   numbers rather than taste. */
const springOf = (tune: number) => ({
  /* stiffness: how hard it is pulled toward the target */
  k: 0.08 + (tune / 100) * 0.16,
  /* decay, per frame: how much of the velocity survives */
  d: 0.62 + (tune / 100) * 0.2,
});

/* Units matter. The snap threshold is absolute, so a caller
   works in pixels or in 0..100 — a spring driven over 0..1
   would be "settled" before it had visibly moved. */
function useSpring(target: number, tune = 50, instant = false) {
  const [at, setAt] = useState(target);
  const cur = useRef(target);
  const vel = useRef(0);
  const raf = useRef(0);

  useEffect(() => {
    if (instant) {
      cur.current = target;
      vel.current = 0;
      setAt(target);
      return;
    }
    const { k, d } = springOf(tune);
    let prev = 0;
    const tick = (t: number) => {
      const dt = prev ? clamp((t - prev) / 16.67, 0, 2.5) : 1;
      prev = t;
      vel.current += (target - cur.current) * k * dt;
      vel.current *= Math.pow(d, dt);
      cur.current += vel.current * dt;
      if (Math.abs(target - cur.current) < 0.02 && Math.abs(vel.current) < 0.02) {
        cur.current = target;
        vel.current = 0;
        setAt(target);
        raf.current = 0;
        return;
      }
      setAt(cur.current);
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf.current);
      raf.current = 0;
    };
    /* \`tune\` sits here beside \`target\` for the reason
       Brightness spells out: the loop closes over it, so
       without it a knob turned mid-flight would do nothing
       until something else restarted the effect. Restarting
       picks up from the refs, so it continues rather than
       snapping. */
  }, [target, tune, instant]);

  return at;
}

/* Read once, the way the wheel and the pill nav do. A
   preference, not a live input. */
const stillness = () =>
  typeof window !== "undefined" &&
  !!window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

export function Checklist({
  corner = CORNER,
  /* how far the box swells past full before it settles,
     0..100 — 0 is a spring that arrives dead, which is a
     perfectly good checkbox and is what most of them do */
  bounce = BOUNCE,
  /* the box, px */
  box = BOX,
}: {
  corner?: number;
  bounce?: number;
  box?: number;
} = {}) {
  /* ── one array, not two ─────────────────────────────────
     The list used to be a constant and the ticks a parallel
     array of booleans, which was fine while the list could not
     change. It can now, and two arrays that have to stay the
     same length are two arrays that will not. */
  const [items, setItems] = useState(() =>
    TASKS.map((text) => ({ text, done: false })));
  /* the row being typed into, or null. The draft is separate
     from the list so an abandoned one leaves nothing behind. */
  const [adding, setAdding] = useState(false);
  const [draft, setDraft] = useState("");
  /* ── how long each row actually is ───────────────────────
     Reported UP from the rows, because only they can see it:
     the width of a line of type is a question for the font,
     not for the character count, and "Send the estimate" is
     seventeen characters that set narrower than fifteen of
     somebody else's. offsetWidth rather than a rect, since the
     block is drawn under a scale on the wall and a rect would
     come back already multiplied. */
  const [runs, setRuns] = useState<number[]>([]);
  /* and how tall a line of it sets, which is the other half of
     how close two slips can lie */
  const [line, setLine] = useState(20);
  const measure = useCallback((i: number, px: number, tall: number) => {
    setRuns((v) => (v[i] === px ? v : Object.assign([...v], { [i]: px })));
    setLine((v) => (v === tall ? v : tall));
  }, []);

  const still = stillness();

  const r = clamp(corner, 0, 40);
  const side = clamp(Math.round(box), 14, 28);

  /* ── the whole finish, as one derived boolean ────────────
     Not a state. Every task ticked IS the finish, so there is
     nothing to keep in step: unticking one during the three
     seconds makes this false on the same render and the rows
     start climbing back without anything having to remember
     that they had fallen. That is the entire "you can undo
     it while it is on the floor" behaviour, and it is free. */
  const fell = items.length > 0 && items.every((t) => t.done);
  /* the spare row, and it holds its space even while the heap
     is down — fading it is a paint, removing it would change
     the card's height in the middle of a fall */
  const spare = items.length < MAX;

  /* ── and it puts itself away ─────────────────────────────
     Three seconds on the floor, then the list is new again.
     Cleared if \`fell\` goes false first, so unticking a task
     cancels the reset rather than having it fire later and
     wipe the box you just reopened. */
  useEffect(() => {
    if (!fell) return;
    /* ── ALL THE WAY BACK, tasks included ────────────────
       It used to only take the ticks off and leave anything
       you had added, on the reasoning that deleting your work
       is the block presuming. Which is true of an app and not
       of this: it is a demonstration on a wall, the three
       tasks are part of what it demonstrates, and a visitor
       who adds two and walks away leaves the next person a
       block in a state its author never chose.

       Going back to three also gives the card its closing
       animation for free — the same height transition that
       opened it runs in reverse. */
    const id = window.setTimeout(
      () => setItems(TASKS.map((text) => ({ text, done: false }))),
      HOLD,
    );
    return () => window.clearTimeout(id);
  }, [fell]);

  /* ── the vertical padding is DERIVED, not declared ───────
     A row is taller than the box in it, for the same reason
     every row on this bench is: the words beside the checkbox
     are the part anybody actually points at, so the target is
     the row. That slack sits between the first box and the
     card's own edge, so a uniform \`padding: 14px\` reads as 14
     at the sides and 23 at the top — the two insets are the
     same number and visibly different amounts of air.

     Taking the slack off the vertical padding makes the four
     look equal, and doing it from the box's CURRENT size means
     it stays equal as the Box knob moves rather than at one
     setting of it. */
  const slack = (ROW - side) / 2;
  const padV = Math.max(0, PAD - slack);

  /* ── where the heap goes ─────────────────────────────────
     Worked out from the bottom up, because that is the order
     it happens in: the last row's slip comes to rest on the
     card's inner edge, and every row above lands on the one
     below. \`inset\` is the air inside a row that the heap gives
     up — the whole of the fall is three of those. */
  const body = BODY(side, line);
  const inset = (ROW - body) / 2;
  /* every row the card holds, the spare one included */
  const slots = items.length + (spare ? 1 : 0);
  const floor = padV + ROW * slots;
  /* ── and a tilted slip stands on ONE CORNER ─────────────
     The floor is where the LOWEST point of the bottom slip
     comes to rest, not where its middle does. Tilting it drops
     one end below its own centre line, so seating it by the
     centre pushes that corner through the card's edge — 2.9px
     of it, measured. Backing the seat off by the same amount
     puts the corner on the floor, which is what resting on
     something means. */
  /* ── the lean of each slip, from the floor up ───────────
     The bottom one lies flat on the card. Everything above
     inherits what it is lying on and adds its own overhang —
     see LEAN. Zero until the rows have reported their widths,
     which is one frame, and a flat heap for one frame is not
     something anybody sees. */
  const leans = items.map(() => 0);
  for (let i = items.length - 2; i >= 0; i--) {
    const over = Math.max(0, (runs[i] ?? 0) - (runs[i + 1] ?? 0));
    leans[i] = clamp(leans[i + 1] + leanOf(over), 0, MAX_LEAN);
  }
  const touch = gapFor(leans, runs);
  /* the bottom slip is flat, so its lowest point is its own
     edge and the seat needs no correction for a tilt */
  const seat = floor - inset - body;
  const restTop = (i: number) => padV + i * ROW;
  const pileTop = (i: number) => seat - (items.length - 1 - i) * (body + touch);
  const drops = items.map((_, i) => Math.max(0, pileTop(i) - restTop(i)));
  /* the top row travels furthest, so it sets the clock and the
     others are shorter in proportion to it — ONE gravity, and
     t goes as the square root of the distance. That is where
     the cascade comes from now: nothing is delayed, the bottom
     row simply has less far to go and arrives first. */
  const longest = Math.max(...drops, 1);

  const add = () => {
    const text = draft.trim();
    setAdding(false);
    setDraft("");
    if (!text || items.length >= MAX) return;
    setItems((v) => [...v, { text, done: false }]);
  };

  return (
    <div
      className="chk"
      style={{
        width: W,
        /* ── STATED, so it can be animated ─────────────────
           It was whatever the rows added up to. The same
           number, written down, is a number CSS can move
           between — see the transition on .chk. Adding a task
           used to snap the card 40px taller in one frame. */
        height: padV * 2 + ROW * slots,
        padding: \`\${padV}px \${PAD}px\`,
        borderRadius: r,
      }}
    >
      {/* ── AnimatePresence, for the two that leave ─────────
          A reset from five back to three removes two rows, and
          removing them is a blink at the bottom of a card that
          is already closing. Held for a moment and faded
          instead, so the card shuts over them rather than
          them vanishing out from under it. */}
      <AnimatePresence initial={false}>
      {items.map((task, i) => (
        <Row
          /* the TEXT is the key, and two tasks with the same
             words would collide — so it is the text and the
             position it was added at, which nothing reorders */
          key={\`\${i}-\${task.text}\`}
          label={task.text}
          on={task.done}
          side={side}
          bounce={bounce}
          still={still}
          fell={fell}
          drop={drops[i]}
          secs={DROP_MS * Math.sqrt(drops[i] / longest)}
          /* the slip is the part of the row you can see, and
             the part that comes to rest on the one below */
          inset={inset}
          drift={DRIFT[i]}
          tilt={leans[i]}
          index={i}
          onRun={measure}
          /* the last thing to land is the top of the heap, and
             it has to be painted like it. DOM order would put
             the bottom row over everything. */
          layer={fell ? items.length - i : undefined}
          onToggle={() => {
            setItems((v) =>
              v.map((t, k) => (k === i ? { ...t, done: !t.done } : t)));
          }}
        />
      ))}
      </AnimatePresence>

      {/* ── the spare row ─────────────────────────────────
          Quiet on purpose: it is the only thing here that is
          not a task, and at full strength a fourth row of ink
          reads as a fourth task you have not ticked. It comes
          up on hover and again while you are typing in it.

          Its own click is stopped, because the card behind
          this block opens the detail overlay on one and the
          field is not a button for the card to recognise. */}
      {spare && (
        <div
          className="chk-add"
          data-hide={fell || undefined}
          style={{ height: ROW }}
          onClick={(e) => e.stopPropagation()}
        >
          <span
            className="chk-ghost"
            aria-hidden="true"
            style={{ width: side, height: side, borderRadius: side * 0.32 }}
          />
          {adding ? (
            <input
              className="chk-field"
              autoFocus
              value={draft}
              placeholder="New task"
              maxLength={40}
              onChange={(e) => setDraft(e.target.value)}
              /* Enter commits, Escape abandons — and neither is
                 allowed past this block: Escape closes the
                 detail overlay, which is not what somebody
                 backing out of a text field is asking for */
              onKeyDown={(e) => {
                if (e.key === "Enter") { e.stopPropagation(); add(); }
                if (e.key === "Escape") {
                  e.stopPropagation();
                  setAdding(false);
                  setDraft("");
                }
              }}
              onBlur={add}
            />
          ) : (
            <button
              type="button"
              className="chk-new"
              onClick={() => { setAdding(true); }}
            >
              Add new task
            </button>
          )}
        </div>
      )}
    </div>
  );
}

function Row({
  label,
  on,
  side,
  bounce,
  still,
  fell,
  drop,
  secs,
  inset,
  drift,
  tilt,
  layer,
  index,
  onRun,
  onToggle,
}: {
  label: string;
  on: boolean;
  side: number;
  bounce: number;
  still: boolean;
  /* the list is finished and the floor has gone */
  fell: boolean;
  drop: number;
  secs: number;
  inset: number;
  drift: number;
  tilt: number;
  layer?: number;
  index: number;
  onRun: (i: number, px: number, tall: number) => void;
  onToggle: () => void;
}) {
  /* ── the one number ──────────────────────────────────────
     A component per row rather than a loop, because this is a
     hook and a hook cannot be called three times from the
     parent. It costs nothing at rest: a spring sitting on its
     target runs no loop at all. */
  /* ── it measures its own line and says how long it is ────
     The span is sized to the WORDS rather than the row (see
     .chk-say), so its right edge is where this slip actually
     ends — box, gap and type. Layout effect rather than an
     effect: the parent leans the heap on this number, and a
     frame of the wrong answer is a frame of the wrong heap.
     Re-run on the label and the box size, which are the only
     two things that can change it. */
  const say = useRef<HTMLSpanElement | null>(null);
  useLayoutEffect(() => {
    const el = say.current;
    if (el) onRun(index, el.offsetLeft + el.offsetWidth, el.offsetHeight);
  }, [label, side, index, onRun]);

  const t = useSpring(on ? 1 : 0, clamp(bounce, 0, 100), still);
  const held = clamp(t, 0, 1);
  /* the rule's own window on the same number */
  const cut = clamp((held - LAG) / RUN, 0, 1);

  /* ── falling and climbing are not the same motion ────────
     Down is a duration with gravity's shape in it: it starts
     at nothing and gains, which is what \`easeIn\` is, and the
     small rebound at the end is the difference between landing
     and being placed. Up is a spring, because coming back is
     the list reasserting itself rather than anything being
     dropped — and a spring interrupts cleanly, so unticking a
     task halfway through the fall picks the row up from
     wherever it had got to.

     With motion turned down there is no quieter version of a
     thing falling over, so it does not happen — the same
     answer the celebration this replaced gave. The three
     second reset still runs, so the block still resets. */
  const run = still ? 0 : secs;
  /* a rebound in proportion to the fall — see the constant */
  const up = Math.min(REBOUND, drop * 0.22);
  /* the fall itself, with the rebound as the third keyframe */
  const land = {
    duration: run,
    times: [0, 0.66, 0.84, 1],
    ease: [...FALL_EASE],
  };
  /* the tilt and the sideways drift arrive with the landing
     and do not bounce */
  const lean = { duration: run, ease: "easeIn" as const };

  return (
    <motion.button
      type="button"
      className="chk-row"
      role="checkbox"
      aria-checked={on}
      data-fell={fell || undefined}
      onClick={onToggle}
      style={{ height: ROW, zIndex: layer, "--slip": \`\${inset}px\` } as React.CSSProperties}
      /* the row is drawn where it has always been drawn and
         MOVED from there, so the card's layout never changes
         and the wall's observer never hears about any of this */
      initial={false}
      exit={{ opacity: 0, transition: { duration: 0.18 } }}
      animate={
        fell
          ? { y: [0, drop, drop - up, drop], x: drift, rotate: tilt }
          : { y: 0, x: 0, rotate: 0 }
      }
      transition={
        fell
          ? { y: land, x: lean, rotate: lean }
          : { type: "spring", stiffness: 420, damping: 26, mass: 0.9 }
      }
    >
      {/* ── the box ───────────────────────────────────────
          Two layers and neither is a border being recoloured:
          the ring is always there and the FILL grows inside
          it. A checkbox that swaps its background is a
          different colour arriving; one whose fill opens from
          the middle is the box being filled in, which is what
          the word means. */}
      <span
        className="chk-box"
        style={{
          width: side,
          height: side,
          borderRadius: side * 0.32,
        }}
      >
        <span
          className="chk-fill"
          style={{
            borderRadius: side * 0.32,
            /* RAW, so it goes past full and settles — this is
               the one place the overshoot belongs */
            transform: \`scale(\${t.toFixed(4)})\`,
          }}
        />
        {/* ── the tick DRAWS ─────────────────────────────
            \`pathLength="1"\` normalises the dash to the
            stroke's own length, so the offset is a fraction
            rather than a number somebody measured off this
            particular path — change the checkmark and nothing
            here needs to know.

            Clamped, because a tick that overshoots draws
            itself past its own end and pulls back. */}
        <svg className="chk-tick" viewBox="0 0 24 24" aria-hidden="true">
          <path
            d="M6 12.4 L10.3 16.7 L18 7.6"
            pathLength={1}
            strokeDasharray={1}
            strokeDashoffset={1 - held}
          />
        </svg>
      </span>

      <span className="chk-say" ref={say}>
        {/* the words give up their ink as the rule crosses
            them — read off the same number, so a half-crossed
            line is half-faded and the two can never disagree */}
        <span className="chk-word" style={{ opacity: mix(1, 0.42, held) }}>
          {label}
        </span>
        {/* ── the rule is scaled, not grown ───────────────
            A width in pixels would need the word measured;
            \`scaleX\` from the left edge needs nothing, and a
            1.5px line has no corner for a scale to distort.
            The span is sized to the WORD rather than the row,
            so the rule stops where the text does. */}
        <span
          className="chk-rule"
          aria-hidden="true"
          style={{ transform: \`scaleX(\${cut.toFixed(4)})\` }}
        />
      </span>
    </motion.button>
  );
}
`,css:`/* ══ Checklist ══════════════════════════════════════════════
   Three tasks and a tick. Everything that moves is written
   from one spring per row in Checklist.tsx — so there is no
   transition anywhere in here, or the easing and the spring
   would re-interpolate against each other and what you would
   see is the transition rather than the press. */
.chk {
  box-sizing: border-box;
  /* ── it opens, it does not jump ──────────────────────────
     One row taller when you add a task, over a third of a
     second. The component states its height rather than
     letting the rows add up to it, which is what gives this
     something to interpolate.

     WITH THE OVERFLOW CLIPPED, which is what makes it read as
     the card opening rather than as a box being resized around
     things already sitting outside it: the new task takes the
     empty slot the spare row was in, and the spare row is
     revealed as the card grows to make it a new one. */
  overflow: hidden;
  transition: height 360ms cubic-bezier(0.22, 0.9, 0.28, 1);
  /* the rows are in flow and stay in flow — the fall is a
     transform on each of them, so nothing here is positioned.
     What this is for now is the stacking context the heap's
     z-order needs. */
  position: relative;
  background: var(--fill-slab, var(--card));
  font-family: var(--font-ui);
  color: var(--fill-on, var(--ink));}

/* the hairline is the Stroke control's to give, the way it is
   for every other block — a spread shadow rather than a
   border, so it costs the card no layout */
[data-stroke="on"] .chk {
  box-shadow: 0 0 0 1px var(--pane-edge);}

.chk-row {
  display: flex;
  align-items: center;
  gap: 12px;
  width: 100%;
  /* so the heap can be ordered. Rows land on each other and
     the one that lands LAST is the top of the pile, which is
     the opposite of the DOM order they are written in. */
  position: relative;
  /* NOTHING at the sides: the card's own padding is the inset,
     and a second one here would put the box further in than
     the card's edge says it is */
  padding: 0;
  border: 0;
  border-radius: 12px;
  background: none;
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
  /* the ROW is the target, not the box. A 22px checkbox is a
     22px hit area, and the words beside it are the part
     anybody actually points at */
  -webkit-tap-highlight-color: transparent;}

/* ── the spare row ─────────────────────────────────────────
   The one thing in this card that is not a task, and it has
   to read that way at a glance or it is a fourth item you
   have not ticked yet. So: the same geometry as a row, and a
   third of the ink. It comes up on hover, and the field it
   turns into sits at full strength — you are writing in it by
   then, and a placeholder that stays faint while you type
   reads as broken. */
.chk-add {
  display: flex;
  align-items: center;
  gap: 12px;
  width: 100%;
  /* ── the same type as a task, set ONCE on the row ────────
     Both the label and the field it turns into say \`font:
     inherit\`, which was inheriting the card's — 16px at 400
     with no tracking, against a task's 14 at 450. Next to
     three lines of the smaller face the placeholder read as a
     heading rather than as the next line of the list.

     It goes on the row rather than on each of them because a
     button and an input are the same line of text at two
     moments, and a size stated twice is a size that will
     disagree with itself later. See .chk-say, which is where
     these three numbers come from. */
  font-size: 14px;
  font-weight: 450;
  letter-spacing: -0.01em;
  transition: opacity 200ms ease;}

/* it keeps its space while the heap is down — removing it
   would change the card's height in the middle of a fall */
.chk-add[data-hide] {
  opacity: 0;
  pointer-events: none;}

/* the box that is not a checkbox: the ring at a fraction of
   its strength and nothing inside it. No dashes — a dashed
   outline is a second idea about what "empty" looks like, and
   this card already has one that works. */
.chk-ghost {
  flex: none;
  box-shadow: inset 0 0 0 1.5px rgba(var(--fill-on-rgb, var(--ink-rgb)), 0.16);}

.chk-new {
  padding: 0;
  border: 0;
  background: none;
  color: inherit;
  font: inherit;
  /* \`font: inherit\` does not carry this: a button and an
     input take letter-spacing from the UA sheet, not from
     their parent, so the row's tracking stopped at them. */
  letter-spacing: inherit;
  text-align: left;
  cursor: pointer;
  opacity: 0.34;
  transition: opacity 160ms ease;}

.chk-new:hover { opacity: 0.62; }

.chk-field {
  flex: 1;
  min-width: 0;
  padding: 0;
  border: 0;
  background: none;
  color: inherit;
  font: inherit;
  /* \`font: inherit\` does not carry this: a button and an
     input take letter-spacing from the UA sheet, not from
     their parent, so the row's tracking stopped at them. */
  letter-spacing: inherit;
  outline: none;}

.chk-field::placeholder {
  color: rgba(var(--fill-on-rgb, var(--ink-rgb)), 0.34);}

/* ── on the floor ──────────────────────────────────────────
   Opaque, and only once it has fallen. A row is a transparent
   button for its whole life until the three of them are lying
   against each other, and at that point transparency means two
   tasks reading through each other at three degrees of
   rotation — a mess rather than a heap.

   ON A PSEUDO-ELEMENT, and inset, because the row's own box is
   not the object that falls. A row is 40px tall so that the
   whole line is a target; what you can SEE in it is about
   twenty. Painting the full 40 and then stacking the slips
   tight enough to touch means each one covers the top of the
   words below it. The slip is the visible part — the
   component sends its own inset down as --slip, since only it
   knows how big the Box knob has made the contents.

   Behind the words, not over them: the row carries a z-index
   while it is fallen, which makes it a stacking context, so a
   negative one here lands under its own contents and nothing
   else. */
.chk-row[data-fell]::before {
  content: "";
  position: absolute;
  left: 0;
  right: 0;
  top: var(--slip, 9px);
  bottom: var(--slip, 9px);
  border-radius: 10px;
  background: var(--fill-slab, var(--card));
  z-index: -1;}

.chk-row:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px rgba(var(--fill-on-rgb, var(--ink-rgb)), 0.4);}

/* ── the box ────────────────────────────────────────────────
   The ring never changes. It is drawn once, at rest, and the
   fill opens inside it — so what you see is a box being
   filled in rather than one colour being swapped for another.
   \`overflow: hidden\` is what keeps the fill's overshoot
   inside the ring instead of past it. */
.chk-box {
  position: relative;
  flex: none;
  display: grid;
  place-items: center;
  overflow: hidden;
  box-shadow: inset 0 0 0 1.5px rgba(var(--fill-on-rgb, var(--ink-rgb)), 0.28);}

.chk-fill {
  position: absolute;
  inset: 0;
  background: var(--fill-on, var(--ink));
  /* from the middle out — an origin at a corner would read as
     a panel sliding in rather than as the box filling */
  transform-origin: center;}

/* ── the tick ───────────────────────────────────────────────
   Drawn rather than faded: \`stroke-dashoffset\` walks the
   stroke on from its start, so the mark is made the way a
   person makes it. It sits ON the fill and takes the fill's
   own ground colour, which is why it can be full strength and
   still be invisible until there is something under it. */
.chk-tick {
  position: relative;
  width: 68%;
  height: 68%;
  overflow: visible;
  fill: none;
  stroke: var(--fill-slab, var(--card));
  stroke-width: 2.6;
  stroke-linecap: round;
  stroke-linejoin: round;}

.chk-say {
  position: relative;
  /* sized to the WORDS, not to the row: the rule is a scale of
     this box, so a full-width span would strike out the empty
     half of the line as well */
  display: inline-block;
  font-size: 14px;
  font-weight: 450;
  letter-spacing: -0.01em;
  line-height: 1.2;}

.chk-word { display: inline-block; }

.chk-rule {
  position: absolute;
  left: 0;
  right: 0;
  /* on the type's own middle rather than the box's — a rule
     centred on a line box sits low, because the box carries
     the descender space and the letters do not */
  top: 46%;
  height: 1.5px;
  border-radius: 2px;
  background: currentColor;
  transform-origin: left center;
  pointer-events: none;}`,tokens:[`--card`,`--fill-on`,`--fill-on-rgb`,`--fill-slab`,`--font-ui`,`--ink`,`--ink-rgb`,`--pane-edge`],deps:[`framer-motion`],stubs:[]},carousel:{tsx:`import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";

/* SHOTS was Bencho's own pictures, which are not licensed
   to travel. Point this at yours. */
const SHOTS: { name: string; src: string }[] = [];

/* ══ Carousel ═════════════════════════════════════════════
   Cards on a turntable that drift at rest, give under the
   pointer, and can be swiped round.

   NOTHING EVER LEAVES THE FRAME, and that is the whole
   arrangement. This was a row twice — cards in a line, with
   the ones at the ends either dissolving into a mask or being
   cut by the edge of a box — and both are answers to the same
   question: what happens to a card when it runs out of block?
   A ring does not ask it. The cards go ROUND: out to one
   side, back and small, round to the other side, forward
   again. The furthest a card ever gets is the radius, which
   is a number this component chose, so there is no edge to
   treat and no box to put it in.

   IT IS THEREFORE ENDLESS. A row has a first card and a last
   one and has to decide what to do at each; a ring has
   neither, so the swipe never runs out and never rubber-bands.
   Swipe once and the front card shrinks and goes to the back
   while the next one comes forward — which is the motion he
   described, and it falls out of the geometry rather than
   being animated on top of it.

   THE ANGLE IS NOT TAKEN MODULO ANYTHING. \`turn\` counts up
   and down without limit and the angle is \`(i - turn) * step\`.
   Wrapping it to 0..360 would send a card the long way round
   the moment it crossed the seam, which is the one visible bug
   this arrangement can have — the same note the Pro sheet's
   reel carries, for the same reason.

   THREE MOTIONS, THREE ELEMENTS, ONE TRANSFORM EACH. The slot
   carries where the card is on the ring, the floater carries
   the drift, the card carries the tilt. They are nested rather
   than composed into one string because they are owned by
   three different things — the drag, a CSS animation and a
   pair of springs — and a single element cannot be written by
   three authors without one of them losing. */

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));
const mix = (a: number, b: number, t: number) => a + (b - a) * t;

/* the card is the PICTURES' own ratio, near enough — 160x226
   is 0.708 against their 2:3, so \`cover\` trims about six per
   cent off the height. These are photographs with nothing at
   their top or bottom edge, and the card reading as a card
   rather than as a slat is worth the last few rows. */
const CARD_W = 206;
const CARD_H = 292;

/* ── the frame, and it is only a frame ─────────────────────
   No box, no clip, no mask. Nothing here hides its overflow,
   which is what makes the next decision affordable.

   ── SIZED FOR THE DEFAULT, NOT FOR THE EXTREMES ───────────
   This is the decision that matters on the wall. Sized to
   hold Spread 150 with Depth 0 and Float 100 — the widest the
   knobs can make the ring — the frame came to 520x404, and at
   the arrangement it actually SHIPS at that left 40px of air
   either side and 50 top and bottom. Measured. That is dead
   space the wall pays for on every card: a block is fitted to
   its column by its bounding BOX, so air inside the box is
   the block being drawn smaller.

   476x340 is the shipping ring plus about eighteen pixels of
   margin. The card is 37% of the frame where it was 28.6%,
   and the overlay draws it 9% bigger as well, because the fit
   there is LOCK over the larger side.

   What it costs: at the far corners of the knobs the ring
   paints a little outside the frame. Nothing clips, so it
   simply overlaps the padding the wall card keeps around a
   block, and only when Spread, Depth and Float are all at
   once at settings nobody ships. The same trade the Balance
   card makes when it stretches past its own measured box.

   The cards also keep growing faster than the frame, for the
   same reason: 160x226 in 440x340 was 24% of the frame in
   card, 188x266 in 474x384 was 27%, 206x292 in 476x340 is
   37%.

   Fixed at these two numbers, because a frame that grew with
   a knob would rescale the whole block every time one moved —
   which is the thing the ResizeObserver on the wall and the
   overlay would both do. */
const STAGE_W = 476;
const STAGE_H = 340;

const ORBIT = 138;
/* ── how much smaller the back of the ring is ──────────────
   Read as a percentage of the way to half size: 100 puts the
   card at the back at 0.5, which is where this sits. The knob
   runs to 150 — 0.25 — because the ceiling was the default's
   own value and that is a knob with nothing above it, so
   every setting was a step DOWN from where it shipped.

   \`1 - depth / 200\` rather than the arithmetic it replaced,
   which said the same thing with a 0.5 buried in it. */
const DEPTH = 100;
const DEPTH_MAX = 150;
const CORNER = 18;
const FLOAT = 15;
const SINK = 50;
const SETTLE = 50;

/* ── how far back the ring leans ───────────────────────────
   A card at the back sits this much higher than one at the
   front. Scale alone says smaller, which the eye can read as
   further away OR as literally smaller; a card that also
   rides UP as it recedes is unmistakably going back, because
   that is what a ring seen from slightly above does. It costs
   one term and it is most of what makes the depth read.

   38 rather than 22 for a second reason: at 22 the card at
   the very back was invisible — 226 tall drawn at 0.75 and
   lifted 22 puts its top edge 6px BELOW the front card's, so
   one of the four was hidden completely at rest. At 38 it
   clears by ten, and seeing something behind is what tells
   you the ring goes round. */
const LEAN = 38;

/* how many px of drag turn the ring one position */
const PULL = 140;

/* how far ahead of the release the throw looks, in ms of
   travel. It is what makes a short fast flick move a card:
   without it a swipe is judged on distance alone and a quick
   one that barely moved counts for nothing. */
const TOSS = 150;
/* and how many it may skip. A flick can carry two; past that
   the ring blurs and you have lost your place on it. */
const MOST = 2;

const BASE = 620;

/* ── the pictures ARE the count ────────────────────────────
   It was a 3..6 knob while the cards were coloured faces,
   which is a knob you can only have when the cards carry
   nothing: with photographs, one more card than pictures has
   to be one of them a second time, and the same picture twice
   on one ring reads as a bug rather than as a setting. So the
   number of cards is \`SHOTS.length\` and nothing else —
   add a file, run the script, and the ring has another
   position. Five today.

   Five is also the better ring. With four, one card sits at
   180 degrees, which is directly behind the front one and out
   of sight; at 72-degree steps nothing is ever exactly
   behind anything, so every card is at least partly visible
   at rest and the ring reads as a ring rather than as three
   cards and a rumour.

   They are inlined by scripts/carousel.sh — drop new files in
   src/assets/carousel and run it. The order is the filenames
   sorted, so renaming one moves it. */
const N = SHOTS.length;

/* ── which one is at the front when it opens ───────────────
   BY NAME, not by index. The order is whatever the filenames
   sort to, so an index here would be a number that silently
   means a different picture the day somebody adds a file —
   and "the card it opens on" is a decision, not an accident
   of the alphabet. Falls back to the middle of the ring if
   the name is not there, which is where it used to open. */
const FRONT = "man";
const OPENS_ON = (() => {
  const i = SHOTS.findIndex((s) => s.name === FRONT);
  return i < 0 ? Math.floor((N - 1) / 2) : i;
})();

/* ── every card sits at its own angle ──────────────────────
   Numbers that are not a pattern: no two the same, no
   symmetry to spot, and they do not alternate. A ring where
   the angles went -4, +4, -4, +4 is an arrangement somebody
   made; numbers that are merely different are a handful of
   photographs somebody put down.

   There is one per picture. It has to be — \`i % ANGLE.length\`
   would wrap a fifth card onto the first card's angle, and
   two of five sharing an angle is the pattern this list
   exists to avoid.

   They can be this generous again now the cards are on a
   ring. On a row an angle cost width — a turned card sweeps
   its corner sideways into its neighbour's air — and the
   spread knob's floor had to pay for it. Cards at different
   depths are allowed to overlap; that is what depth looks
   like. */
const ANGLE = [-4.2, 2.6, -1.4, 3.8, 1.7];

/* the drift's periods, deliberately awkward so no two cards
   are ever doing the same thing. See the note in index.css. */
const PERIOD = [4.7, 5.9, 6.7, 5.3, 7.1, 6.1];

type Spot = { x: number; y: number; s: number; z: number };

/* ── where a card sits, given where the ring is ────────────
   ONE function, read by the first paint and by the drag both.
   The drag writes transforms straight to the nodes — a render
   per pointermove and the ring visibly trails the finger — so
   there are two callers, and if they were two pieces of code
   they would drift apart the first time the geometry changed.

   \`f\` is the whole of it: 1 at the front, 0 at the back, and
   it drives the size, the lean and the paint order together.
   Position from the ANGLE rather than from a table of four
   places is what makes the transitions free — the card
   leaving swings out and back, the card arriving swings in
   and forward, and the one behind crosses without any of them
   knowing about the others. */
const spotOf = (i: number, turn: number, orbit: number, depth: number): Spot => {
  const th = (i - turn) * ((Math.PI * 2) / N);
  const f = (Math.cos(th) + 1) / 2;
  return {
    x: Math.sin(th) * orbit,
    y: -(1 - f) * LEAN,
    s: mix(1 - clamp(depth, 0, DEPTH_MAX) / 200, 1, f),
    /* ── paint order is a z-index, by hand ──────────────
       Everything here is 2D — scale and offset, not
       translateZ — so nothing sorts itself and a card would
       otherwise paint in DOM order and sit over the one in
       front of it. \`f\` already knows which is nearer. */
    z: Math.round(f * 100),
  };
};

const write = (el: HTMLElement, sp: Spot, angle: number) => {
  /* NO OPACITY IS WRITTEN HERE. The cards used to fade with
     distance, which meant dragging dimmed and lit every one of
     them — the whole block pulsed on a gesture that should
     only move things round. Size, lean and paint order say
     which is in front; none of them touch the picture. */
  el.style.transform = \`translate(-50%, -50%) translate(\${sp.x.toFixed(2)}px, \${sp.y.toFixed(2)}px) rotate(\${angle}deg) scale(\${sp.s.toFixed(4)})\`;
  el.style.zIndex = String(sp.z);
};

const out = (t: number) => 1 - (1 - t) ** 4;

/* ── inlined from ./spring ──────────────────────── */
/* ── one spring, for everything that settles ───────────────
   The maths was already on this bench twice, copied by hand:
   Humidity's wheel and Brightness's column both accumulate
   velocity toward a target, damp it, and snap when both the
   delta and the velocity fall under 0.02. Two copies is a
   coincidence; five would be a policy, so it comes out here
   before the elastic blocks are written against it.

   The two shipped copies are deliberately NOT refactored onto
   this. They work, they are tuned, and rewriting the innards
   of two live components to prove a point about duplication
   is how a good afternoon becomes a bad one. This is the one
   new code uses.

   Frames, not milliseconds. \`dt\` is expressed in sixtieths of
   a second and the damping is RAISED to it rather than
   multiplied by it, so a dropped frame decays the same amount
   of energy as the two frames it replaced. Multiplying is the
   version that makes a spring behave differently on a busy
   page, which is the hardest kind of bug to see.

   The loop parks itself the moment the value has settled.
   CLAUDE.md is not complimentary about the one permanent
   requestAnimationFrame already on this bench and there is no
   case for five more. */

/* 0..100 into the two numbers a spring actually has.

   50 is what Humidity and Brightness were tuned at, which is
   the rule every elastic knob on this bench follows — see
   lab/motion. Turn the panel to the middle and nothing has
   changed.

   Both ends have to be usable, which is what fixes the range:
   at 0 it is slow and heavy and still arrives, at 100 it is
   quick with a visible overshoot, and nowhere in between does
   it ring for longer than it takes to read. */
/* The pair is chosen by DAMPING RATIO and then written back
   as stiffness and decay, because the ratio is the thing a
   person is actually setting and the two numbers on their own
   do not say what they add up to.

     zeta = -ln(d) / (2 * sqrt(k))

   The first version of this ran 0.06..0.26 stiffness against
   0.93..0.74 decay, which reads as a sensible spread and is
   not one: it puts zeta between 0.15 and 0.16 across the
   WHOLE range, so every setting overshot by about sixty per
   cent and the knob only changed how fast it did it. Pull's
   return went 130px past its own resting position and lifted
   the content off the top of the card.

     0   → zeta ~0.85, heavy, arrives without a ring
     50  → zeta ~0.41, near where Humidity and Brightness sit
     100 → zeta ~0.20, lively, two visible rebounds

   Both ends shippable, which is the constraint that fixed the
   numbers rather than taste. */
const springOf = (tune: number) => ({
  /* stiffness: how hard it is pulled toward the target */
  k: 0.08 + (tune / 100) * 0.16,
  /* decay, per frame: how much of the velocity survives */
  d: 0.62 + (tune / 100) * 0.2,
});

/* Units matter. The snap threshold is absolute, so a caller
   works in pixels or in 0..100 — a spring driven over 0..1
   would be "settled" before it had visibly moved. */
function useSpring(target: number, tune = 50, instant = false) {
  const [at, setAt] = useState(target);
  const cur = useRef(target);
  const vel = useRef(0);
  const raf = useRef(0);

  useEffect(() => {
    if (instant) {
      cur.current = target;
      vel.current = 0;
      setAt(target);
      return;
    }
    const { k, d } = springOf(tune);
    let prev = 0;
    const tick = (t: number) => {
      const dt = prev ? clamp((t - prev) / 16.67, 0, 2.5) : 1;
      prev = t;
      vel.current += (target - cur.current) * k * dt;
      vel.current *= Math.pow(d, dt);
      cur.current += vel.current * dt;
      if (Math.abs(target - cur.current) < 0.02 && Math.abs(vel.current) < 0.02) {
        cur.current = target;
        vel.current = 0;
        setAt(target);
        raf.current = 0;
        return;
      }
      setAt(cur.current);
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf.current);
      raf.current = 0;
    };
    /* \`tune\` sits here beside \`target\` for the reason
       Brightness spells out: the loop closes over it, so
       without it a knob turned mid-flight would do nothing
       until something else restarted the effect. Restarting
       picks up from the refs, so it continues rather than
       snapping. */
  }, [target, tune, instant]);

  return at;
}

/* Read once, the way the wheel and the pill nav do. A
   preference, not a live input. */
const stillness = () =>
  typeof window !== "undefined" &&
  !!window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

/* ── inlined from ./motion ──────────────────────── */
/* ── elastic, as numbers a person can hold ─────────────────
   Several blocks here are the same idea in different clothes:
   something travels, stretches on the way, and overshoots
   when it lands. Their character lives in a duration and in
   one control point of a bezier — which is exactly the kind
   of thing nobody should have to name in order to tune.

   So the outside of every elastic knob is 0..100 and the
   inside is real units, and **50 is always what the component
   was already tuned to**. Turn every knob on the bench to the
   middle and nothing has changed. That is what makes these
   safe to expose: the default is not a number somebody has to
   remember, it is the middle of the slider.

   Both ends have to be shippable, which is the constraint
   that actually shapes these curves. The ranges below stop
   where the effect stops being the thing it is — a bar that
   moves in 40ms still reads as a bar snapping to a slot; one
   that moves in 20ms reads as broken. */

/* How long it takes, slower to faster, as a multiplier on
   whatever the component's own tuned duration is. 0 is a
   little over half again as slow, 100 is two and a half times
   as fast, 50 is exactly 1. */
const rate = (speed: number) => 1.6 - (speed / 100) * 1.2;

/* How hard it lands.

   In a cubic-bezier the second control point's y is the whole
   of an overshoot: at 1 the thing stops dead on its target,
   and past 1 it travels beyond and comes back. Everything
   else in the curve is the approach and stays put.

   \`tuned\` is the y this component was drawn with, so 50
   returns it unchanged and the slider is centred on the
   design rather than on some shared average. */
const overshoot = (bounce: number, tuned: number) =>
  Number((1 + (bounce / 100) * (tuned - 1) * 2).toFixed(3));

/* the same, ready to drop into a transition */
const curve = (bounce: number, tuned: number, x1 = 0.28, x2 = 0.36) =>
  \`cubic-bezier(\${x1}, \${overshoot(bounce, tuned)}, \${x2}, 1)\`;

export function Carousel({
  /* how far out to the sides the ring reaches, in px */
  orbit = ORBIT,
  /* how much smaller the back of the ring is, 0..100 */
  depth = DEPTH,
  corner = CORNER,
  /* how much they drift at rest, 0..100 — 0 is a still ring,
     which is a real setting and not a broken one */
  float = FLOAT,
  /* how deep the pointer presses, 0..100 */
  sink = SINK,
  /* how quickly a swipe settles, 0..100 */
  settle = SETTLE,
  /* ── seconds for one whole turn of the ring ──────────────
     0 is off, and off is the default: on the bench this ring
     is a thing you push, and one that also drifts round on its
     own would be answering a gesture nobody made. It is here
     for the places the carousel is a PICTURE rather than a
     control — the Pro sheet, today — where it has to carry
     itself because nobody is going to touch it. */
  spin = 0,
}: {
  orbit?: number;
  depth?: number;
  corner?: number;
  float?: number;
  sink?: number;
  settle?: number;
  spin?: number;
} = {}) {
  const still = stillness();

  const slots = useRef<(HTMLDivElement | null)[]>([]);
  /* ── where the ring is, and it is a REF ──────────────────
     A continuous position in card-steps: 0 puts the first
     card at the front, 1.5 is halfway between the second and
     third. It changes every frame of a drag, which is exactly
     the value that must not be state — React renders when a
     knob moves, the ring is painted.

     It is NOT clamped and NOT wrapped. See the note at the
     top: this is the number a modulo would ruin. */
  const turn = useRef(OPENS_ON);
  const raf = useRef(0);
  const drag = useRef<{
    x0: number; t0: number; last: number; t: number; vx: number; moved: boolean;
  } | null>(null);
  const [held, setHeld] = useState(false);

  const paint = useCallback(() => {
    slots.current.forEach((el, i) =>
      el && write(el, spotOf(i, turn.current, orbit, depth), ANGLE[i % ANGLE.length]));
  }, [orbit, depth]);

  /* placed on mount, and again whenever a knob changes the
     arithmetic under it */
  useLayoutEffect(paint, [paint]);

  useEffect(() => () => cancelAnimationFrame(raf.current), []);

  /* ── the ring turning itself ─────────────────────────────
     Its own frame loop and its own handle, deliberately not
     \`raf\` — that one belongs to the settle after a swipe, and
     the two sharing it would mean whichever started last
     cancelled the other.

     It advances \`turn\` by time rather than stepping between
     whole positions: a ring that clicks from card to card is
     reading as a slideshow, and the whole point of this one is
     that it is a continuous ring you are looking at side on.

     Held pauses it. Nothing on the Pro sheet can grab it —
     that reel is pointer-events: none — but the pause costs a
     line and means the prop is safe anywhere. */
  useEffect(() => {
    if (!spin || still || held) return;
    let id = 0;
    let prev = 0;
    const step = (t: number) => {
      /* N cards over \`spin\` seconds is one whole revolution */
      if (prev) turn.current += ((t - prev) / 1000) * (N / spin);
      prev = t;
      paint();
      id = requestAnimationFrame(step);
    };
    id = requestAnimationFrame(step);
    return () => cancelAnimationFrame(id);
  }, [spin, still, held, paint]);

  /* ── the settle ──────────────────────────────────────────
     Quart-out from wherever the ring currently is to a whole
     position. It reads its start from the live value rather
     than from where the drag began, so a second swipe during
     one turns the ring further instead of snapping it back. */
  const glide = (to: number) => {
    cancelAnimationFrame(raf.current);
    const from = turn.current;
    if (still || from === to) {
      turn.current = to;
      paint();
      return;
    }
    const ms = BASE * rate(clamp(settle, 0, 100));
    const t0 = performance.now();
    const tick = (now: number) => {
      const p = Math.min(1, (now - t0) / ms);
      turn.current = mix(from, to, out(p));
      paint();
      if (p < 1) raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
  };

  const go = (d: number) => glide(Math.round(turn.current) + d);

  const down = (e: React.PointerEvent) => {
    cancelAnimationFrame(raf.current);
    drag.current = {
      x0: e.clientX, t0: turn.current, last: e.clientX,
      t: e.timeStamp, vx: 0, moved: false,
    };
    setHeld(true);
    try { e.currentTarget.setPointerCapture(e.pointerId); } catch { /* not a live pointer */ }
  };

  const move = (e: React.PointerEvent) => {
    const g = drag.current;
    if (!g) return;
    const dx = e.clientX - g.x0;
    if (!g.moved && Math.abs(dx) > 3) g.moved = true;

    /* px per ms, smoothed against the previous reading so one
       jittery frame cannot fake a flick — and measured from
       the LAST position rather than from the grab, because the
       speed at release is the only part of a swipe that says
       how far it meant to go */
    const dt = Math.max(1, e.timeStamp - g.t);
    g.vx = (g.vx + (e.clientX - g.last) / dt) / 2;
    g.last = e.clientX;
    g.t = e.timeStamp;

    /* ── no rubber band, because there is no end ─────────
       A row had to give at its first and last card, or it read
       as broken input. A ring has neither, so the drag is a
       plain one-to-one and keeps going as long as you do. */
    turn.current = g.t0 - dx / PULL;
    paint();
  };

  const up = () => {
    const g = drag.current;
    if (!g) return;
    drag.current = null;
    setHeld(false);
    /* where it would come to rest if it kept going, capped so
       a hard flick cannot spin the ring past where you can
       follow it */
    const carry = clamp((-g.vx * TOSS) / PULL, -MOST, MOST);
    const to = Math.round(turn.current + carry);
    if (g.moved) glide(to);
  };

  const key = (e: React.KeyboardEvent) => {
    const d = e.key === "ArrowRight" ? 1 : e.key === "ArrowLeft" ? -1 : 0;
    if (!d) return;
    e.preventDefault();
    go(d);
  };

  const r = clamp(corner, 0, 40);

  return (
    <div className="car" style={{ width: STAGE_W, height: STAGE_H }}>
      <div
        className="car-track"
        data-held={held}
        role="group"
        aria-label="Card carousel"
        aria-roledescription="carousel"
        tabIndex={0}
        onKeyDown={key}
        onPointerDown={down}
        onPointerMove={move}
        onPointerUp={up}
        onPointerCancel={up}
      >
        {SHOTS.map((shot, i) => (
          <div
            key={shot.name}
            ref={(el) => { slots.current[i] = el; }}
            className="car-slot"
            style={{ width: CARD_W, height: CARD_H }}
          >
            {/* ── the drift ─────────────────────────────────
                Its own element, so the keyframes own this
                transform outright and neither the ring nor the
                tilt ever writes it. The period is per card and
                the amplitudes are the knob. */}
            <div
              className="car-float"
              style={{
                /* at Float 0 the keyframes come off rather than
                   running at zero amplitude. Identical to look
                   at, and one of them holds a compositor layer
                   per card for a motion the knob has just
                   turned off. */
                animationName: float <= 0 ? "none" : undefined,
                animationDuration: \`\${PERIOD[i % PERIOD.length]}s\`,
                ["--lift" as string]: \`\${((clamp(float, 0, 100) / 100) * 16).toFixed(2)}px\`,
                ["--sway" as string]: \`\${((clamp(float, 0, 100) / 100) * 1.4).toFixed(2)}deg\`,
              }}
            >
              <Card
                shot={shot.src}
                corner={r}
                sink={sink}
                /* a card under a finger that is turning the
                   ring is not being pressed, it is being
                   carried — and two gestures fighting for one
                   transform is the one way this can look
                   broken */
                off={held || still}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ── one card, and the press is its own ───────────────────
   A component per card rather than a loop, because the tilt is
   a pair of springs and a hook cannot be called n times from
   the parent. It costs nothing at rest: a spring at its target
   runs no loop at all. */
function Card({
  shot,
  corner,
  sink,
  off,
}: {
  shot: string;
  corner: number;
  sink: number;
  off: boolean;
}) {
  const skin = useRef<HTMLDivElement | null>(null);
  const [pt, setPt] = useState({ x: 0, y: 0 });
  const [on, setOn] = useState(false);
  const still = stillness();

  /* ── the state, and there is only this ───────────────────
     Where the pointer is, as -1..1 on each axis, sprung. The
     spring is on the POSITION rather than on the rotation, so
     the transform and both gradients are three readings of one
     number instead of three things animating toward the same
     place. */
  const live = on && !off;
  const sx = useSpring(live ? pt.x : 0, 50, still);
  const sy = useSpring(live ? pt.y : 0, 50, still);
  const lit = useSpring(live ? 1 : 0, 50, still);

  const deep = clamp(sink, 0, 100) / 100;
  const max = deep * 13;
  /* IT SINKS, IT DOES NOT LIFT — the tilt card's rule. The
     point you are over goes AWAY and the far side comes up, so
     the card is being touched rather than displayed. */
  const rx = -sy * max;
  const ry = sx * max;

  /* the pointer in the card's own terms, as a PERCENTAGE. The
     wall, the overlay and the Pro sheet all draw this card at
     their own scale, and a gradient placed in pixels would
     land somewhere else in each of them. */
  const px = ((sx + 1) / 2) * 100;
  const py = ((sy + 1) / 2) * 100;
  const dark = deep * 0.5 * lit;
  /* the rim is a hint, not a highlight: at the tilt card's own
     0.34 a white wash slides across the photograph and reads
     as a sheen laid ON the picture rather than as the far edge
     of a dented surface catching light */
  const rim = deep * 0.16 * lit;

  const track = (e: React.PointerEvent) => {
    const el = skin.current;
    if (!el) return;
    const b = el.getBoundingClientRect();
    setPt({
      x: clamp(((e.clientX - b.left) / b.width) * 2 - 1, -1, 1),
      y: clamp(((e.clientY - b.top) / b.height) * 2 - 1, -1, 1),
    });
    setOn(true);
  };

  return (
    <div
      ref={skin}
      className="car-card"
      onPointerMove={track}
      /* \`out\` with a containment test rather than \`leave\` — the
         rehearsal's scripted pointer walks off carrying
         \`relatedTarget: null\`, which React does not synthesise
         a leave from, and the card would finish the demo still
         sunk under a cursor that had gone. */
      onPointerOut={(e) => {
        const el = skin.current;
        const to = e.relatedTarget as Node | null;
        if (!el || !to || !el.contains(to)) setOn(false);
      }}
      onPointerCancel={() => setOn(false)}
      style={{
        borderRadius: corner,
        backgroundImage: \`url(\${shot})\`,
        /* translateZ FIRST, so the retreat is measured in the
           room's axes rather than in the card's own — after a
           rotation the card's z points off to one side and
           "back" stops meaning back */
        transform: \`translateZ(\${(-10 * deep * lit).toFixed(2)}px) rotateX(\${rx.toFixed(2)}deg) rotateY(\${ry.toFixed(2)}deg)\`,
        /* ── ONE SHADOW, AND IT DOES NOT MOVE ─────────────
           It tightened as the card sank, which is the honest
           physics, and on four cards it was four shadows
           resizing as the pointer crossed them — the ring
           flickering rather than one card being touched. The
           dent and the rim say the card went back; the shadow
           only has to say it is off the ground. */
        boxShadow: "0 12px 28px -10px rgba(var(--shadow-rgb), 0.28)",
      }}
    >
      {/* the dent, and the rim opposite it. The shadow pools
          where the surface is deepest, which is under the
          pointer, and the light catches the far edge that has
          risen — so the two are placed at mirrored points and
          neither is centred on anything. This layer is what
          makes the transform read as a press. */}
      <span
        className="car-sheen"
        aria-hidden="true"
        style={{
          borderRadius: corner,
          backgroundImage: \`radial-gradient(44% 36% at \${px.toFixed(1)}% \${py.toFixed(1)}%, rgba(9, 14, 28, \${dark.toFixed(3)}) 0%, rgba(9, 14, 28, 0) 100%), radial-gradient(54% 44% at \${(100 - px).toFixed(1)}% \${(100 - py).toFixed(1)}%, rgba(255, 255, 255, \${rim.toFixed(3)}) 0%, rgba(255, 255, 255, 0) 100%)\`,
        }}
      />
    </div>
  );
}
`,css:`/* ══ Carousel ═══════════════════════════════════════════════
   A row of cards that drift at rest, give under the pointer,
   and can be thrown. Three motions on three nested elements,
   one transform each — see the note in Carousel.tsx for why
   they cannot share a node. */
.car {
  position: relative;
  font-family: var(--font-ui);}

/* ── the frame is only a frame ─────────────────────────────
   No background, no clip, no mask. This was a box that cut
   the cards at its edges, and before that a mask that faded
   them out there, and both were answers to the question of
   what happens to a card when it runs out of block. The cards
   are on a ring now and never reach an edge, so the question
   is gone and so is everything that was answering it.

   Which also means nothing here forces \`transform-style:
   flat\` any more — overflow and mask both did, and both were
   safe only because the perspective sits two levels down on
   \`.car-float\`. It no longer has to be. */
.car-track {
  position: absolute;
  inset: 0;
  touch-action: pan-y;
  cursor: grab;}

.car-track[data-held="true"] {
  cursor: grabbing;}

.car-track:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px var(--bg), 0 0 0 4px rgba(var(--ink-rgb), 0.4);}

/* the slot holds WHERE on the ring and the card's own resting
   ANGLE, written per frame by the component — so it carries no
   transition of its own, or the easing and the drag would
   re-interpolate against each other and what you would see is
   the transition rather than the finger */
.car-slot {
  position: absolute;
  left: 50%;
  top: 50%;
  transform-origin: center;}

/* ── the drift ──────────────────────────────────────────────
   Keyframes rather than a loop: a rAF per card would be a
   permanent loop for motion nobody is watching, and a wall
   holding several of these blocks would run a dozen. This
   runs on the compositor and pauses itself when the tab
   hides. The period is set per card and deliberately does not
   divide into its neighbours' — that is what stops the row
   breathing in unison.

   The perspective lives HERE, not on the track: on the track
   a card at the edge of the row would tilt toward the middle
   of the stage rather than toward the finger on it. Each card
   is its own object being touched and wants its own vanishing
   point. */
.car-float {
  width: 100%;
  height: 100%;
  perspective: 760px;
  animation: car-bob 5s ease-in-out infinite;}

.car-card {
  position: relative;
  width: 100%;
  height: 100%;
  background-size: cover;
  background-position: center;
  /* no transition: the tilt is sprung in the component, and a
     transition on top would be a second opinion about how this
     card settles */}

.car-sheen {
  position: absolute;
  inset: 0;
  display: block;
  pointer-events: none;}

@media (prefers-reduced-motion: reduce) {
  .car-float { animation: none; }
}

@keyframes car-bob {
  0%, 100% {
    transform: translateY(calc(var(--lift, 4px) * -1)) rotate(calc(var(--sway, 1deg) * -1));
  }
  50% {
    transform: translateY(var(--lift, 4px)) rotate(var(--sway, 1deg));
  }}`,tokens:[`--bg`,`--font-ui`,`--ink-rgb`,`--lift`,`--sway`],deps:[],stubs:[`SHOTS`]},palette:{tsx:`import { useEffect, useId, useRef, useState } from "react";
import { useMotionValue, useSpring as useMotionSpring, useTransform, useVelocity } from "framer-motion";
import { RefreshCw } from "lucide-react";

/* ══ Palette ══════════════════════════════════════════════
   Three to five colours that go together, and a button that
   finds you another set.

   ── THE COLOURS ARE PICKED IN OKLCH ───────────────────────
   Which is the entire difference between this and the random
   hex generator everybody writes first. In HSL, \`lightness\`
   is a lie: hsl(60 90% 50%) is a bright yellow and
   hsl(240 90% 50%) is a near-black blue, at the same number.
   So a palette built by holding L and stepping the hue comes
   out with one swatch that glows and one you can barely see.

   OKLCH is perceptually uniform — equal steps in L look like
   equal steps — so a ramp written in it is a ramp you can
   actually see. The palette is generated there and converted
   to hex on the way out, because hex is what somebody wants
   to paste into their own file.

   ── AND THEY ARE A RAMP, NOT A SPIN ───────────────────────
   Four random hues do not make a palette however even their
   lightness is. What makes a set look chosen is that it
   agrees about one thing and varies another: these hold a
   hue family and ramp the LIGHTNESS across it, which is what
   a designer does by hand.

   Chroma peaks in the middle rather than being held flat, for
   the same reason a very light and a very dark colour cannot
   be vivid — there is no room left in the gamut, and asking
   for it is what makes generated palettes go chalky at one
   end and muddy at the other. */

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

/* ── oklch → hex ───────────────────────────────────────────
   Björn Ottosson's matrices, unchanged. The path is
   oklch → oklab → LMS → linear sRGB → sRGB, and the only
   liberty taken is the clamp at the end: a colour outside the
   gamut is clipped per channel rather than gamut-mapped,
   which is the wrong answer in general and a fine one here
   because the chroma below never asks for one. */
function hex(L: number, C: number, H: number) {
  const h = (H * Math.PI) / 180;
  const a = C * Math.cos(h);
  const b = C * Math.sin(h);

  const l_ = L + 0.3963377774 * a + 0.2158037573 * b;
  const m_ = L - 0.1055613458 * a - 0.0638541728 * b;
  const s_ = L - 0.0894841775 * a - 1.291485548 * b;
  const l = l_ ** 3, m = m_ ** 3, s = s_ ** 3;

  const lin = [
    4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
    -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
    -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s,
  ];

  return (
    "#" +
    lin
      .map((v) => {
        const g = v <= 0.0031308 ? 12.92 * v : 1.055 * Math.abs(v) ** (1 / 2.4) - 0.055;
        return Math.round(clamp(g, 0, 1) * 255)
          .toString(16)
          .padStart(2, "0");
      })
      .join("")
  );
}

export type Swatch = { hex: string };

/* ── one palette ───────────────────────────────────────────
   A base hue, a step between neighbours, and a ramp down the
   lightness. Everything else falls out of those three.

   The step is small and can go either way — 16 to 34 degrees
   — which keeps the family analogous rather than scattered. A
   wider spread is not a bolder palette, it is a list of
   colours.

   One set in three gets an ACCENT: the last swatch jumps most
   of the way round the wheel. A ramp on its own is tasteful
   and slightly dull, and the odd jump is what stops a run of
   generated sets feeling like one set regenerated.

   150 to 175 degrees rather than a flat 180. A true
   complement is the harshest pair on the wheel — it was
   putting a forest green on the end of a set of pinks, which
   is a colour theory exercise rather than a palette. Backing
   off a few degrees is the split-complement every painter
   uses instead, and it keeps the accent surprising without
   making it an argument.

   And it continues in the ramp's own direction rather than
   picking a side: an accent that jumped backwards past the
   colours it came from reads as a mistake in the sequence. */
function make(n: number): Swatch[] {
  const base = Math.random() * 360;
  const step = (16 + Math.random() * 18) * (Math.random() < 0.5 ? -1 : 1);
  const accent = Math.random() < 0.34;

  return Array.from({ length: n }, (_, i) => {
    const p = n === 1 ? 0 : i / (n - 1);
    /* light at the top of the ramp, deep at the bottom */
    const L = 0.9 - p * 0.5;
    /* and vivid in the middle, where the gamut has the room */
    const C = 0.05 + Math.sin(p * Math.PI) * 0.105;
    const H =
      accent && i === n - 1
        ? base + (n - 1) * step + (150 + Math.random() * 25) * Math.sign(step)
        : base + i * step;
    return { hex: hex(L, C, ((H % 360) + 360) % 360) };
  });
}

/* ── the layout ────────────────────────────────────────────
   TWO PILLS SIDE BY SIDE: the colours in one, the refresh in
   its own. It was a single slab with the button tucked in at
   the right, which made the button part of the palette — and
   it is not, it is the thing that replaces the palette. A
   control that acts on an object should not be sitting inside
   it.

   Split, the two read as what they are: a display and a
   button. They share a height, a padding and a corner, so
   nothing about them says they are unrelated — only that they
   are two things.

   The swatches inside the first pill are still SEGMENTS of one
   bar rather than four cards in a row: a palette is one thing
   made of parts, and four separate tiles read as four separate
   decisions.

   The button pill's inside is one swatch square, and its
   button takes the swatch's corner — so the tool pill holds a
   swatch-shaped thing and the corner knob moves both. */
const W = 300;
/* the inset inside each pill. It was also the gap between
   them — see GAP, which is where that stopped being true. */
const PAD = 10;
const BAR_H = 58;
/* ── how wide the refresh is ───────────────────────────────
   The button is as TALL as a swatch and much narrower than
   one. It was a square, which made the tool pill the same
   shape as the thing it acts on and gave an 18px glyph a 58px
   box to sit in — a lot of empty pill for one icon.

   30 against a 58 height is nearly two to one, which is what
   makes it read as a KEY: an upright slot you press, rather
   than a tile that happens to have a glyph on it. There is no
   hover fill for it to need room for any more — the glyph
   just lightens — so the six pixels either side of the icon
   are the whole of what the button has to hold.

   Every pixel it gives up goes to the colours: the swatches
   are 53 wide now, against 45 when this was a square. */
const TOOL = 30;
/* ── the air between the two pills ─────────────────────────
   6, and it is no longer PAD. Those two were deliberately the
   same number once, back when the button sat INSIDE the slab:
   the gap beside the bar and the gap above it were the same
   kind of space, and two numbers there would have been a
   decision nobody made.

   They are two objects now, and the space BETWEEN two objects
   is not the space inside one. At 10 the pills read as two
   things that happen to be near each other; at 6 they read as
   a pair — near enough to belong together, far enough apart
   to be separate, which is exactly what they are. */
const GAP = 6;
const CORNER = 14;
const BASE = 760;
/* ── the gap between swatches ──────────────────────────────
   Small on purpose. The bar was one flush strip and the
   colours were segments of it, which meant the rounded ends
   had to come from the container clipping them — and a swatch
   that cannot leave its slot cannot overshoot, so the elastic
   on the way back was being cut off at the edges.

   Four is enough to read as four objects and not enough to
   stop reading as one bar. It is also what lets the goo do
   something at rest-adjacent moments: a blur of five bridges
   four pixels, so the swatches neck toward each other as they
   move and part again cleanly. */
const SEAM = 4;

/* ── the one way a colour becomes another one ──────────────
   ORB: the swatch draws into a circle, changes colour there,
   and spreads back out into its slot.

   There were five, then three, and now one. The other four
   were not broken — \`pinch\` necked into a droplet, \`flip\`
   turned edge-on, \`split\` parted in two, \`bounce\` squashed
   flat — but a block that ships four ways to do one thing is
   asking whoever opens it to rule out three by hand, and none
   of them said anything this does not.

   What every survivor had in common, and every discarded one
   lacked, is worth keeping written down: the swatch DEFORMS
   and swaps its colour at the frame there is least of it to
   look at. Nothing here fades one colour into another. An
   alpha-contrast filter blurs SourceGraphic, so anything
   painting a new colour over an old one inside the same
   swatch shows you the two smeared together — every muddy
   value in between, and none of them in either palette. Each
   swatch is one solid colour at every frame, and the blur only
   ever bridges the gap BETWEEN swatches. That is liquid; the
   other thing is smear. */

/* how much blur the run carries. Zero at rest — see the note
   where it is used. */
const HEAT = 5;

/* ── they all go at once ───────────────────────────────────
   Every swatch runs the same clock. They used to be staggered,
   each on its own window of the run, so the change travelled
   along the bar — which is a nice effect and the wrong one
   here. A wave says the swatches are a sequence and that one
   caused the next; they are not, they are a set, and pressing
   refresh replaces all of them in the same instant. Together
   is what that press actually did.

   It also makes the goo mean more rather than less: four
   swatches contracting on the same frame leave four gaps
   opening at the same rate, and the bridge between them is one
   piece of motion instead of a blur chasing a wavefront. */

/* ── out fast, back PAST the mark ──────────────────────────
   The deformation is not a sine. A sine is symmetric and
   lands exactly on rest, which is a shape being resized; what
   makes these read as elastic is that the return overshoots —
   the swatch comes back a few per cent bigger than it needs to
   be and settles. That is the whole difference between
   \`animated\` and \`springy\`, and it costs one back-out curve.

   The change happens at OUT, the top of the deformation, and
   the longer tail after it is the settle. */
const OUT = 0.4;
const back = (k: number) => {
  const c = 1.7;
  const u = k - 1;
  return 1 + (c + 1) * u ** 3 + c * u ** 2;
};
const swellOf = (ti: number) =>
  ti <= 0 ? 0 : ti < OUT ? 1 - (1 - ti / OUT) ** 3 : 1 - back((ti - OUT) / (1 - OUT));

const mix = (a: number, b: number, t: number) => a + (b - a) * t;

/* ── inlined from ./motionkit ──────────────────────── */
/* ══ liquid ═══════════════════════════════════════════════
   Shared parts for the Framer Motion layer: one spring, one
   goo filter, one velocity→skew binding.

   ── why the filter is a hook ────────────────────────────
   The filter is embedded in each component's own return, but
   its id CANNOT be a literal. Every block here renders twice
   at once — once in the wall card, once in the detail overlay
   — and duplicate SVG ids do not scope, they collide: the
   second instance silently steals the first one's filter.
   useId() gives each mount its own name.

   ── what the goo can and cannot do ──────────────────────
   This is feGaussianBlur + feColorMatrix, not a shader. The
   matrix multiplies alpha by \`cut\` and subtracts half of it,
   so alpha below 0.5 lands on zero and everything above 0.536
   is fully opaque. That hard edge is what fuses nearby shapes
   into one blob — and it is also why this must never touch
   text: glyph antialiasing lives entirely below 0.5, so type
   under this filter loses its edges and then itself. */

/* the elastic, as specified: ζ = 14 / (2·√(220·0.5)) ≈ 0.67,
   so it overshoots about 6% before it settles. A deliberate
   bounce, not a wobble. */
const LIQUID = {
  type: "spring" as const,
  stiffness: 220,
  damping: 14,
  mass: 0.5,
};

/* Non-drag blocks reuse the same feel without the overshoot,
   so a toggle does not bounce like a dragged card. */
/* ── the same liquid, without the overshoot ────────────────
   For shapes whose corner radius is animating: a spring that
   passes its target drags the radius past it too, and corners
   that dip under and come back read as a wobble rather than
   as a bounce.

   NOT just LIQUID with more damping, which is what this was.
   Raising damping alone to 30 against the same stiffness put
   ζ at 1.43 — comfortably overdamped, so it stopped
   overshooting by creeping: about 470ms to settle, against
   LIQUID's 290ms. It read as slow because it was.

   Stiffness comes up with the damping instead, which holds ζ
   at 1.03 — no overshoot, and it lands in about 180ms. */
const LIQUID_STILL = { ...LIQUID, stiffness: 420, damping: 30 };

function useGoo(blur = 7, cut = 28) {
  /* useId yields ":r0:" — legal in an id attribute but not in
     a url(#…) reference, so strip the colons. */
  const id = \`goo-\${useId().replace(/:/g, "")}\`;
  const goo = (
    <svg className="liq-defs" aria-hidden="true" focusable="false">
      <defs>
        <filter
          id={id}
          x="-50%"
          y="-50%"
          width="200%"
          height="200%"
          colorInterpolationFilters="sRGB"
        >
          <feGaussianBlur in="SourceGraphic" stdDeviation={blur} result="smear" />
          <feColorMatrix
            in="smear"
            type="matrix"
            values={\`1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 \${cut} \${-(cut / 2)}\`}
          />
        </filter>
      </defs>
    </svg>
  );
  return { id, url: \`url(#\${id})\`, goo };
}

/* ── drag velocity → skew ────────────────────────────────
   Feed x/y as the thing moves; the element leans against its
   own motion. Springing the skew rather than reading velocity
   raw is what keeps it organic — raw velocity is noisy enough
   to read as a jitter. */
function useDragSkew(limit = 12, range = 1600) {
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const vx = useVelocity(x);
  const vy = useVelocity(y);
  const skewX = useMotionSpring(useTransform(vx, [-range, range], [limit, -limit]), LIQUID);
  const skewY = useMotionSpring(
    useTransform(vy, [-range, range], [limit / 2, -limit / 2]),
    LIQUID,
  );
  return { x, y, skewX, skewY };
}

/* ── token → real colour ─────────────────────────────────
   Framer interpolates colours, but only real ones. A custom
   property does not qualify twice over: getPropertyValue
   hands back the unresolved token stream, and half of these
   tokens are color-mix(), which is not a colour until
   something computes it.

   So we let the engine do it. A hidden probe inside the
   component inherits the component's own custom properties —
   including any [data-fill] or [data-surface] override on an
   ancestor — and \`color\` on it computes all the way down to
   an rgb triple we can hand to Framer.

   Re-read whenever the theme or fill flips, or the animation
   would tween toward the previous palette. */
function useTokens(
  ref: React.RefObject<HTMLElement | null>,
  names: string[],
): Record<string, string> {
  const [vals, setVals] = useState<Record<string, string>>({});
  const key = names.join("|");
  const last = useRef("");

  useEffect(() => {
    const host = ref.current;
    if (!host) return;

    const read = () => {
      const probe = document.createElement("span");
      probe.style.cssText = "position:absolute;visibility:hidden;pointer-events:none";
      host.appendChild(probe);
      const next: Record<string, string> = {};
      for (const n of names) {
        /* a bare token gets wrapped; anything else (a fallback
           chain, a literal) is already a colour expression */
        probe.style.color = n.startsWith("--") ? \`var(\${n})\` : n;
        next[n] = getComputedStyle(probe).color;
      }
      probe.remove();
      const sig = JSON.stringify(next);
      if (sig !== last.current) {
        last.current = sig;
        setVals(next);
      }
    };

    read();

    /* every ancestor that can redefine the palette */
    const mo = new MutationObserver(read);
    const flags = ["data-theme", "data-fill", "data-surface", "data-stroke"];
    for (let el: HTMLElement | null = host; el; el = el.parentElement) {
      mo.observe(el, { attributes: true, attributeFilter: flags });
    }
    return () => mo.disconnect();
  }, [ref, key]);

  return vals;
}

/* ── inlined from ./motion ──────────────────────── */
/* ── elastic, as numbers a person can hold ─────────────────
   Several blocks here are the same idea in different clothes:
   something travels, stretches on the way, and overshoots
   when it lands. Their character lives in a duration and in
   one control point of a bezier — which is exactly the kind
   of thing nobody should have to name in order to tune.

   So the outside of every elastic knob is 0..100 and the
   inside is real units, and **50 is always what the component
   was already tuned to**. Turn every knob on the bench to the
   middle and nothing has changed. That is what makes these
   safe to expose: the default is not a number somebody has to
   remember, it is the middle of the slider.

   Both ends have to be shippable, which is the constraint
   that actually shapes these curves. The ranges below stop
   where the effect stops being the thing it is — a bar that
   moves in 40ms still reads as a bar snapping to a slot; one
   that moves in 20ms reads as broken. */

/* How long it takes, slower to faster, as a multiplier on
   whatever the component's own tuned duration is. 0 is a
   little over half again as slow, 100 is two and a half times
   as fast, 50 is exactly 1. */
const rate = (speed: number) => 1.6 - (speed / 100) * 1.2;

/* How hard it lands.

   In a cubic-bezier the second control point's y is the whole
   of an overshoot: at 1 the thing stops dead on its target,
   and past 1 it travels beyond and comes back. Everything
   else in the curve is the approach and stays put.

   \`tuned\` is the y this component was drawn with, so 50
   returns it unchanged and the slider is centred on the
   design rather than on some shared average. */
const overshoot = (bounce: number, tuned: number) =>
  Number((1 + (bounce / 100) * (tuned - 1) * 2).toFixed(3));

/* the same, ready to drop into a transition */
const curve = (bounce: number, tuned: number, x1 = 0.28, x2 = 0.36) =>
  \`cubic-bezier(\${x1}, \${overshoot(bounce, tuned)}, \${x2}, 1)\`;

/* ── inlined from ./spring ──────────────────────── */
/* ── one spring, for everything that settles ───────────────
   The maths was already on this bench twice, copied by hand:
   Humidity's wheel and Brightness's column both accumulate
   velocity toward a target, damp it, and snap when both the
   delta and the velocity fall under 0.02. Two copies is a
   coincidence; five would be a policy, so it comes out here
   before the elastic blocks are written against it.

   The two shipped copies are deliberately NOT refactored onto
   this. They work, they are tuned, and rewriting the innards
   of two live components to prove a point about duplication
   is how a good afternoon becomes a bad one. This is the one
   new code uses.

   Frames, not milliseconds. \`dt\` is expressed in sixtieths of
   a second and the damping is RAISED to it rather than
   multiplied by it, so a dropped frame decays the same amount
   of energy as the two frames it replaced. Multiplying is the
   version that makes a spring behave differently on a busy
   page, which is the hardest kind of bug to see.

   The loop parks itself the moment the value has settled.
   CLAUDE.md is not complimentary about the one permanent
   requestAnimationFrame already on this bench and there is no
   case for five more. */

/* 0..100 into the two numbers a spring actually has.

   50 is what Humidity and Brightness were tuned at, which is
   the rule every elastic knob on this bench follows — see
   lab/motion. Turn the panel to the middle and nothing has
   changed.

   Both ends have to be usable, which is what fixes the range:
   at 0 it is slow and heavy and still arrives, at 100 it is
   quick with a visible overshoot, and nowhere in between does
   it ring for longer than it takes to read. */
/* The pair is chosen by DAMPING RATIO and then written back
   as stiffness and decay, because the ratio is the thing a
   person is actually setting and the two numbers on their own
   do not say what they add up to.

     zeta = -ln(d) / (2 * sqrt(k))

   The first version of this ran 0.06..0.26 stiffness against
   0.93..0.74 decay, which reads as a sensible spread and is
   not one: it puts zeta between 0.15 and 0.16 across the
   WHOLE range, so every setting overshot by about sixty per
   cent and the knob only changed how fast it did it. Pull's
   return went 130px past its own resting position and lifted
   the content off the top of the card.

     0   → zeta ~0.85, heavy, arrives without a ring
     50  → zeta ~0.41, near where Humidity and Brightness sit
     100 → zeta ~0.20, lively, two visible rebounds

   Both ends shippable, which is the constraint that fixed the
   numbers rather than taste. */
const springOf = (tune: number) => ({
  /* stiffness: how hard it is pulled toward the target */
  k: 0.08 + (tune / 100) * 0.16,
  /* decay, per frame: how much of the velocity survives */
  d: 0.62 + (tune / 100) * 0.2,
});

/* Units matter. The snap threshold is absolute, so a caller
   works in pixels or in 0..100 — a spring driven over 0..1
   would be "settled" before it had visibly moved. */
function useSpring(target: number, tune = 50, instant = false) {
  const [at, setAt] = useState(target);
  const cur = useRef(target);
  const vel = useRef(0);
  const raf = useRef(0);

  useEffect(() => {
    if (instant) {
      cur.current = target;
      vel.current = 0;
      setAt(target);
      return;
    }
    const { k, d } = springOf(tune);
    let prev = 0;
    const tick = (t: number) => {
      const dt = prev ? clamp((t - prev) / 16.67, 0, 2.5) : 1;
      prev = t;
      vel.current += (target - cur.current) * k * dt;
      vel.current *= Math.pow(d, dt);
      cur.current += vel.current * dt;
      if (Math.abs(target - cur.current) < 0.02 && Math.abs(vel.current) < 0.02) {
        cur.current = target;
        vel.current = 0;
        setAt(target);
        raf.current = 0;
        return;
      }
      setAt(cur.current);
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf.current);
      raf.current = 0;
    };
    /* \`tune\` sits here beside \`target\` for the reason
       Brightness spells out: the loop closes over it, so
       without it a knob turned mid-flight would do nothing
       until something else restarted the effect. Restarting
       picks up from the refs, so it continues rather than
       snapping. */
  }, [target, tune, instant]);

  return at;
}

/* Read once, the way the wheel and the pill nav do. A
   preference, not a live input. */
const stillness = () =>
  typeof window !== "undefined" &&
  !!window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

export function Palette({
  /* how many colours, 3..5 */
  count = 4,
  /* the swatch's corner, 0..29 — half of a 58px swatch, which
     is the pill, so the slider runs from square to as round as
     the shape can be. The ceiling moves with BAR_H; past half
     the height a rounded rectangle stops changing. */
  corner = CORNER,
  /* how quickly a colour changes, 0..100 */
  morph = 50,
}: {
  count?: number;
  corner?: number;
  morph?: number;
} = {}) {
  const n = clamp(Math.round(count), 3, 5);
  const [pal, setPal] = useState<Swatch[]>(() => make(n));
  const [next, setNext] = useState<Swatch[] | null>(null);
  const [t, setT] = useState(0);
  const raf = useRef(0);
  const spins = useRef(0);
  const still = stillness();

  /* ── the goo rides the run ───────────────────────────────
     Zero at rest, so the seams are as crisp as two rectangles
     — a standing blur would smear neighbouring colours into
     each other and turn the bar into one gradient. It only
     reaches while something is moving, and because every
     swatch is a single solid colour at every frame, the blur
     it applies can only ever bridge the gap BETWEEN two
     swatches. That is the liquid; there is no smear anywhere
     inside a colour. */
  const heat = Math.sin(Math.PI * clamp(t, 0, 1)) * HEAT;
  const { url: gooUrl, goo } = useGoo(heat, 26);

  /* the palette follows the knob without waiting for a press */
  if (pal.length !== n) {
    setPal(make(n));
    setNext(null);
  }

  const roll = () => {
    /* a press mid-run is ignored rather than queued: a second
       set arriving over a half-finished one would leave some
       swatches showing a palette that no longer exists */
    if (raf.current) return;
    spins.current += 1;

    const fresh = make(n);
    if (still) {
      setPal(fresh);
      return;
    }

    setNext(fresh);
    const ms = BASE * rate(clamp(morph, 0, 100));
    const t0 = performance.now();
    const tick = (now: number) => {
      const p = Math.min(1, (now - t0) / ms);
      setT(p);
      if (p < 1) {
        raf.current = requestAnimationFrame(tick);
      } else {
        raf.current = 0;
        setPal(fresh);
        setNext(null);
        setT(0);
      }
    };
    raf.current = requestAnimationFrame(tick);
  };

  /* the tool pill takes the same padding as the other one, so
     the two come out the same height without either being told
     what the other is */
  const toolW = TOOL + PAD * 2;
  const barW = W - toolW - GAP - PAD * 2;
  /* the seams come out of the row before it is divided, so
     the swatches stay equal whatever the count is */
  const seg = (barW - SEAM * (n - 1)) / n;
  const step = seg + SEAM;
  const r = clamp(corner, 0, BAR_H / 2);
  /* ── the slab's corner, and why it is not just r + PAD ────
     Concentric is the right rule for a curve wrapping another
     curve: stay one padding out and the two stay parallel.
     But at r = 0 there is no curve to stay parallel TO, and a
     flat rule leaves square swatches sitting in a rounded
     slab — two different decisions in one object, which is
     the thing this knob exists to keep in agreement.

     So the offset FADES IN over the first CORNER pixels. The
     default and the top of the slider are untouched — 14
     still gives 24, 29 still gives 39 — only the bottom end,
     which is the end that was wrong. */
  const slabR = r + PAD * Math.min(1, r / CORNER);

  /* ── the beat ────────────────────────────────────────────
     The whole colour pill dips while the swatches are drawn
     in, and comes back a hair past its own size — the swatches
     contracting is a small motion happening inside a box that
     is not moving, and the box giving with them is what makes
     the press land on the palette rather than on four shapes
     in it.

     This is the one place here that uses a SCALE rather than
     writing width and height, which is normally how a corner
     radius gets dragged out of shape. At three and a half per
     cent it is under a pixel of radius, and more to the point
     nobody reads a pulse as a change of shape — they read it
     as a pulse. Writing the size instead would relayout the
     bar under the swatches every frame, which is the thing
     actually worth avoiding.

     Raw \`swellOf\`, not the clamped \`d\` the swatches use: the
     tail of that curve goes past rest, so the pill returns
     slightly over 1 and settles. That overshoot IS the beat —
     clamp it away and this is just a shrink. */
  const beat = 1 - 0.035 * swellOf(clamp(t, 0, 1));

  return (
    <div className="pal" style={{ width: W, gap: GAP }}>
      <div
        className="pal-slab"
        style={{ padding: PAD, borderRadius: slabR, scale: beat }}
      >
        {/* No clip and no corner of its own. Each swatch
            carries its own radius, so the bar is only a box to
            position them in — and a bar that clipped would cut
            off the overshoot, which is the part of the motion
            worth keeping. */}
        <div className="pal-bar" style={{ height: BAR_H, width: barW }}>
          <div className="pal-blobs" aria-hidden="true" style={{ filter: gooUrl }}>
            {pal.map((c, i) => {
              /* one clock, read by every swatch — see the note
                 above on why they are not staggered */
              const ti = clamp(t, 0, 1);
              /* the change happens at the top of the
                 deformation, which is the frame there is least
                 of the swatch to see */
              const shown = next && ti >= OUT ? next[i].hex : c.hex;
              const d = Math.max(0, swellOf(ti));

              /* into a circle and back out into its slot */
              const side = mix(seg, BAR_H * 0.66, d);
              const h = mix(BAR_H, BAR_H * 0.66, d);
              return (
                <span
                  key={i}
                  className="pal-seg"
                  style={{
                    background: shown,
                    width: side,
                    height: h,
                    top: (BAR_H - h) / 2,
                    borderRadius: mix(r, h / 2, d),
                    transform: \`translateX(\${(i * step + (seg - side) / 2).toFixed(2)}px)\`,
                  }}
                />
              );
            })}
          </div>
        </div>
      </div>

      {/* ── the button, in a pill of its own ────────────────
          Same padding and same corner as the palette's, and
          the button inside it is one swatch square wearing the
          swatch's radius — so the corner knob moves this too
          and the two pills never disagree about what a corner
          is here. */}
      <div className="pal-slab pal-tool" style={{ padding: PAD, borderRadius: slabR }}>
        <button
          className="pal-go"
          onClick={roll}
          aria-label="Generate a new palette"
          style={{ width: TOOL, height: BAR_H, borderRadius: r }}
        >
          {/* a turn per press, and it keeps turning the same
              way — a glyph that unwound would say "undo" */}
          <RefreshCw
            size={18}
            strokeWidth={2.2}
            style={{ rotate: \`\${spins.current * 180}deg\` }}
          />
        </button>
      </div>

      {goo}
    </div>
  );
}
`,css:`/* ══ Palette ════════════════════════════════════════════════
   A filled bar of colours and the refresh at its end.
   Everything that moves is written from one number in
   Palette.tsx; what is here is the shell. */
.pal {
  font-family: var(--font-ui);
  /* two pills, and the gap between them is written inline
     alongside the padding inside them — the same number in
     both places on purpose */
  display: flex;
  align-items: stretch;}

/* ── the slab ───────────────────────────────────────────────
   \`--fill-slab\`, which is the Fill control's own token: white
   when the block is filled light and \`--slab-dark\` when it is
   filled dark. It was \`--slab\` — the filled-block pair — which
   is near-black in light, and a palette wants a white card to
   sit on far more than it wants a black one. The fallback is
   \`--card\` for any mount outside a stage that sets the
   attribute. */
.pal-slab {
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--fill-slab, var(--card));}

/* the hairline is the Stroke control's to give, the way it is
   for every other block — a spread shadow rather than a
   border, so it costs the slab no layout */
[data-stroke="on"] .pal-slab {
  box-shadow: 0 0 0 1px var(--pane-edge);}

/* ── the tool pill ──────────────────────────────────────────
   No growing; its width comes from the component. And IT is
   what sinks under a press, not the button inside it — the
   thing being pressed is the pill, a button that shrank inside
   a pill that did not would read as two objects where there is
   one. Same curve the rest of the bench presses on. */
.pal-tool {
  flex: none;
  transition: scale 130ms cubic-bezier(0.3, 0.9, 0.4, 1);}

.pal-tool:has(.pal-go:active) {
  scale: 0.94;}

.pal-bar {
  position: relative;
  flex: none;
  /* NO clip and no corner. Each swatch carries its own radius
     now that there are gaps between them, so there is nothing
     for the bar to shape — and a bar that clipped would cut
     off the overshoot on the way back, which is the part of
     the motion worth having. */}

.pal-blobs {
  position: absolute;
  inset: 0;}

.pal-seg {
  position: absolute;
  left: 0;
  top: 0;
  height: 100%;
  /* every mode is one solid colour at every frame now, so
     there is nothing inside to clip — and the swatch has to be
     free to bulge past its own slot, which is what the
     overshoot on the way back is */
  /* transform and width are written per frame — no transition,
     or the easing and the tween re-interpolate against each
     other and what you see is the transition rather than the
     move */}

/* the height is written per frame too — \`bounce\` and \`orb\`
   both lose some of it — so the rule cannot claim 100% */

/* ── the refresh ────────────────────────────────────────────
   Width, height and corner all come from the component: it
   wears the swatch's own radius, so the Corner knob moves it
   with everything else. NO CHROME AT ALL, at rest or on
   hover — on whatever ink the fill asks for. */
.pal-go {
  flex: none;
  display: grid;
  place-items: center;
  border: 0;
  background: transparent;
  color: var(--fill-on, var(--ink-2));
  cursor: pointer;
  transition: color 160ms ease;}

/* ── hover lightens the glyph, it does not fill the box ─────
   A grey pad appearing behind the icon is a second shape
   arriving on a block whose whole subject is shapes, and it
   was landing inside a pill that already reads as a button —
   chrome drawn on top of chrome. The ink easing off says the
   same thing with nothing new on screen.

   A LIGHTER COLOUR, NOT A FADED ONE. Alpha would have been
   fewer characters and it is the wrong tool: a translucent
   glyph lets whatever is behind it through, so the icon takes
   the slab's tint at rest and something else the moment this
   block sits on any other ground. \`color-mix\` resolves to one
   opaque colour — the fill's own ink walked 45% toward the
   fill's own slab — so it is a grey that was chosen rather
   than a black that is partly missing.

   And it reads in both fills for free, because both ends of
   the mix are the Fill control's tokens: on white the black
   goes to a lighter black, on near-black the white goes to a
   softer white. Same gesture, no second rule. */
.pal-go:hover {
  color: color-mix(in srgb, var(--fill-on, var(--ink-2)) 55%, var(--fill-slab, var(--card)));}

.pal-go:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px var(--fill-slab, var(--card)),
    0 0 0 4px rgba(var(--fill-on-rgb, var(--ink-rgb)), 0.45);}

/* ── the glyph turns, and only one way ──────────────────────
   A half turn per press, accumulated — so it never unwinds.
   A refresh icon that spun back would be saying undo. */
.pal-go svg {
  transition: rotate 620ms cubic-bezier(0.22, 1, 0.36, 1);}

@media (prefers-reduced-motion: reduce) {
  .pal-go, .pal-go svg, .pal-tool { transition-duration: 1ms; }
}`,tokens:[`--card`,`--fill-on`,`--fill-on-rgb`,`--fill-slab`,`--font-ui`,`--ink-2`,`--ink-rgb`,`--pane-edge`],deps:[`framer-motion`,`lucide-react`],stubs:[]},aspect:{tsx:`import { useRef, useState } from "react";

/* SHEEP was Bencho's own pictures, which are not licensed
   to travel. Point this at yours. */
const SHEEP: string = "";

/* ══ Aspect ═══════════════════════════════════════════════
   A picture and three shapes to put it in.

   THE THREE FORMATS HAVE THE SAME AREA. That is the whole
   idea and it is not how most crop switchers are built —
   the common version fixes the width and lets the height do
   whatever the ratio says, which means the landscape is a
   third of the portrait and switching feels like the picture
   grew rather than like it was cropped. Equal area is what a
   crop actually is: the same amount of picture, held a
   different way. 276x207, 239x239 and 207x276 are within
   0.02% of each other.

   It also decides the frame. Every shape fits inside one
   276x276 square, so the block's bounding box is the biggest
   any of them gets and the wall never rescales it mid-move.

   NO CROP IN THE FILE. The source is 3:4 and stays that way
   — see scripts/sheep.sh — so \`cover\` does all three crops
   from one picture, and the portrait tab is the whole
   illustration rather than a slice of it. */

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

/* the square the three shapes fit inside, and the block's
   own width */
const W = 276;
const GAP = 16;
const BAR = 36;

const SHAPES = [
  { id: "land", w: 276, h: 207, label: "Landscape, 4 by 3" },
  { id: "square", w: 239, h: 239, label: "Square, 1 by 1" },
  { id: "tall", w: 207, h: 276, label: "Portrait, 3 by 4" },
] as const;

/* ── the icons are the shapes ──────────────────────────────
   Drawn rather than imported, and lucide does ship a
   rectangle in each orientation. The reason not to use them
   is that here the icon is not a symbol FOR the format, it
   IS the format — so it has to be at the real ratio, and
   lucide's rectangles are at whatever ratio looked right in
   a 24 grid.

   Same constant area as the pictures, for the same reason:
   three marks of visibly different size would say the
   formats are different sizes, which is the thing the block
   is at pains to say they are not. 13 square, and the other
   two are that area at 4:3 and 3:4. */
const MARK = {
  land: { x: 1.5, y: 3.38, w: 15, h: 11.25 },
  square: { x: 2.5, y: 2.5, w: 13, h: 13 },
  tall: { x: 3.38, y: 1.5, w: 11.25, h: 15 },
} as const;

const BASE = 520;

/* ── inlined from ./motion ──────────────────────── */
/* ── elastic, as numbers a person can hold ─────────────────
   Several blocks here are the same idea in different clothes:
   something travels, stretches on the way, and overshoots
   when it lands. Their character lives in a duration and in
   one control point of a bezier — which is exactly the kind
   of thing nobody should have to name in order to tune.

   So the outside of every elastic knob is 0..100 and the
   inside is real units, and **50 is always what the component
   was already tuned to**. Turn every knob on the bench to the
   middle and nothing has changed. That is what makes these
   safe to expose: the default is not a number somebody has to
   remember, it is the middle of the slider.

   Both ends have to be shippable, which is the constraint
   that actually shapes these curves. The ranges below stop
   where the effect stops being the thing it is — a bar that
   moves in 40ms still reads as a bar snapping to a slot; one
   that moves in 20ms reads as broken. */

/* How long it takes, slower to faster, as a multiplier on
   whatever the component's own tuned duration is. 0 is a
   little over half again as slow, 100 is two and a half times
   as fast, 50 is exactly 1. */
const rate = (speed: number) => 1.6 - (speed / 100) * 1.2;

/* How hard it lands.

   In a cubic-bezier the second control point's y is the whole
   of an overshoot: at 1 the thing stops dead on its target,
   and past 1 it travels beyond and comes back. Everything
   else in the curve is the approach and stays put.

   \`tuned\` is the y this component was drawn with, so 50
   returns it unchanged and the slider is centred on the
   design rather than on some shared average. */
const overshoot = (bounce: number, tuned: number) =>
  Number((1 + (bounce / 100) * (tuned - 1) * 2).toFixed(3));

/* the same, ready to drop into a transition */
const curve = (bounce: number, tuned: number, x1 = 0.28, x2 = 0.36) =>
  \`cubic-bezier(\${x1}, \${overshoot(bounce, tuned)}, \${x2}, 1)\`;

export function Aspect({
  corner = 18,
  /* how quickly the frame changes shape, 0..100 — 50 is the
     tuned 520ms */
  morph = 50,
}: { corner?: number; morph?: number } = {}) {
  const [at, setAt] = useState(1);
  const tabs = useRef<(HTMLButtonElement | null)[]>([]);

  const ms = Math.round(BASE * rate(clamp(morph, 0, 100)));
  const shape = SHAPES[at];

  const pick = (i: number, focus = false) => {
    if (i === at) return;
    setAt(i);
    if (focus) tabs.current[i]?.focus();
  };

  /* ── arrows move the choice ──────────────────────────────
     One of the three is always chosen, which makes this a
     radio group rather than a row of buttons — and a radio
     group is driven with the arrow keys, with only the
     chosen one in the tab order. Tab reaches the control,
     arrows choose inside it. */
  const key = (e: React.KeyboardEvent) => {
    const d = e.key === "ArrowRight" || e.key === "ArrowDown" ? 1
      : e.key === "ArrowLeft" || e.key === "ArrowUp" ? -1
      : 0;
    if (!d) return;
    e.preventDefault();
    pick((at + d + SHAPES.length) % SHAPES.length, true);
  };

  return (
    <div
      className="asp"
      style={{ width: W, height: W + GAP + BAR, ["--asp-ms" as string]: \`\${ms}ms\` }}
    >
      {/* The stage is the full square and never changes, so
          the picture is centred in a box that is not moving.
          Sizing the stage to the picture instead would make
          the tabs below it climb and drop as the shape
          changed — the one thing on this block that has no
          business moving. */}
      <div className="asp-stage" style={{ height: W }}>
        {/* ── width and height, NEVER a scale ─────────────
            The same rule the detail overlay's block follows,
            for the same reason: a scaled box drags its corner
            radius with it, and the corner has to read as the
            same rounded frame throughout rather than as a
            rectangle being stretched. \`cover\` is what keeps
            the picture itself undistorted while the frame
            moves — so this reads as a crop changing, which is
            what it is, rather than as an image being
            squashed. */}
        <div
          className="asp-pic"
          style={{
            width: shape.w,
            height: shape.h,
            borderRadius: clamp(corner, 0, 40),
            backgroundImage: \`url(\${SHEEP})\`,
          }}
        />
      </div>

      <div className="asp-tabs" role="radiogroup" aria-label="Aspect ratio" onKeyDown={key}>
        {/* ── the thumb ───────────────────────────────────
            One element sliding, not three backgrounds fading.
            A fill that appears under the new tab while
            another disappears is two events; a thumb that
            travels is one, and it is the one that says these
            three are positions of the same control. */}
        <span
          className="asp-thumb"
          aria-hidden="true"
          style={{ transform: \`translateX(\${at * 100}%)\` }}
        />
        {SHAPES.map((s, i) => {
          const m = MARK[s.id];
          return (
            <button
              key={s.id}
              ref={(el) => { tabs.current[i] = el; }}
              className="asp-tab"
              role="radio"
              aria-checked={i === at}
              aria-label={s.label}
              /* the chosen one is the only one in the tab
                 order — see the note on \`key\` */
              tabIndex={i === at ? 0 : -1}
              onClick={() => pick(i)}
            >
              <svg width={18} height={18} viewBox="0 0 18 18" aria-hidden="true">
                <rect
                  x={m.x}
                  y={m.y}
                  width={m.w}
                  height={m.h}
                  rx={2}
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={1.5}
                />
              </svg>
            </button>
          );
        })}
      </div>
    </div>
  );
}
`,css:`/* No stroke rule here on purpose — see the note on the
   catalog entry. \`--pane-edge\` is 8% ink, which reads against
   a pane and disappears against a photograph, so the block
   does not offer the switch rather than offering one that
   reports a state it is not producing. */

/* ══ Aspect ═════════════════════════════════════════════════
   A picture and three shapes to put it in. Almost everything
   that moves is written in the markup from the chosen shape;
   what is here is the transition itself and the chrome. */
.asp {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 16px;
  font-family: var(--font-ui);}

/* the full square, and it never changes size — the picture is
   centred in a box that is not moving, so the tabs below do
   not climb and drop as the shape changes */
.asp-stage {
  display: grid;
  place-items: center;
  width: 100%;}

.asp-pic {
  background-color: var(--surface-2);
  background-size: cover;
  background-position: center;
  /* \`cover\` and a frame that moves: the picture stays
     undistorted and the CROP changes, which is what a format
     switch actually is. Contain would letterbox and fit would
     squash. */
  transition:
    width var(--asp-ms, 520ms) cubic-bezier(0.22, 1, 0.36, 1),
    height var(--asp-ms, 520ms) cubic-bezier(0.22, 1, 0.36, 1);}

/* ── the tab strip ──────────────────────────────────────────
   .dtl-seg's numbers, which is the segmented control the
   panel beside this block is already wearing: 36 tall, 2 of
   padding, a 6% ink track and 999 on both. Copied by value
   rather than by class because that one belongs to the site's
   chrome and this is a component — but a block that invented
   its own segmented control would be a third opinion about
   what one looks like, sitting six inches from the second.

   The tabs are 40 wide, against .dtl-seg's 58 for a word.
   That is what a 18px glyph needs to stop being a hit target
   you have to aim at — they were 18 wide, which is the icon
   and no more. */
.asp-tabs {
  position: relative;
  display: grid;
  grid-template-columns: repeat(3, 40px);
  padding: 2px;
  border-radius: 999px;
  background: rgba(var(--ink-rgb), 0.06);}

.asp-thumb {
  position: absolute;
  top: 2px; left: 2px;
  width: calc((100% - 4px) / 3);
  height: calc(100% - 4px);
  border-radius: 999px;
  background: var(--card);
  box-shadow: 0 1px 2px rgba(var(--ink-rgb), 0.1);
  /* ── it LEADS the picture ──────────────────────────────
     Both are the same event and both answer the one knob, so
     the thumb is not on a duration of its own — it is a
     fraction of the picture's. A control that takes as long
     as the thing it controls feels like it did not hear you;
     one that arrives first reads as the cause of what
     follows. */
  transition: transform calc(var(--asp-ms, 520ms) * 0.55)
    cubic-bezier(0.22, 1, 0.36, 1);
  pointer-events: none;}

.asp-tab {
  position: relative;
  display: grid;
  place-items: center;
  height: 32px;
  padding: 0;
  border: 0;
  border-radius: 999px;
  background: transparent;
  color: var(--ink-3);
  cursor: pointer;
  transition: color 160ms ease, scale 130ms cubic-bezier(0.3, 0.9, 0.4, 1);}

.asp-tab:hover { color: var(--ink); }

.asp-tab[aria-checked="true"] { color: var(--ink); }

/* the same give every other control on this bench has */
.asp-tab:active { scale: 0.92; }

.asp-tab:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px var(--card), 0 0 0 4px rgba(var(--ink-rgb), 0.35);}

@media (prefers-reduced-motion: reduce) {
  .asp-pic, .asp-thumb, .asp-tab { transition-duration: 1ms; }
}`,tokens:[`--asp-ms`,`--card`,`--font-ui`,`--ink`,`--ink-3`,`--ink-rgb`,`--surface-2`],deps:[],stubs:[`SHEEP`]},tilt:{tsx:`import { useEffect, useRef, useState } from "react";

/* BUTTERFLY was Bencho's own pictures, which are not licensed
   to travel. Point this at yours. */
const BUTTERFLY: string = "";

/* ══ Tilt ═════════════════════════════════════════════════
   A picture card that gives under the pointer.

   IT SINKS, IT DOES NOT LIFT. Every tilt card on the internet
   rotates TOWARD the cursor: the corner you are nearest rises
   to meet you and the card reads as a slab of glass catching
   the light. This one does the opposite — the point you are
   over goes AWAY, and the far side comes up. The difference
   is one minus sign and it is the whole component: a surface
   that rises to your finger is being displayed to you, and a
   surface that gives under it is being touched.

   Which means the sign is not a detail to get right by
   fiddling. Cursor at the top → the top edge has to go back,
   which is a POSITIVE rotateX; cursor at the right → the
   right edge goes back, which is a positive rotateY. Hence
   \`rx = -ny\` and \`ry = +nx\`, the negation of the usual pair.

   THE ROTATION ALONE IS NOT ENOUGH. A rotation about the
   centre is symmetric — the near side down, the far side up
   by the same amount — and on its own it reads as a card
   pivoting, not as one being pressed. What makes it a press
   is that the darkest point tracks the pointer: a depression
   catches shadow at its deepest, and the rim opposite catches
   light. Those two gradients are doing at least as much of
   the work as the transform is, and neither would convince on
   its own.

   ONE PAIR OF NUMBERS IS THE STATE. Two springs hold where
   the pointer is, normalised to -1..1, and the rotation, both
   gradients and the shadow are all read off them. Nothing
   here has a transition of its own — see the note on Sound
   for why that matters, which is the same reason. */

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));
const mix = (a: number, b: number, t: number) => a + (b - a) * t;

/* Portrait, and the picture is cropped to it by
   scripts/butterfly.sh rather than being fitted at runtime —
   change one and change the other or the crop moves. */
const W = 260;
const H = 320;

/* ── how deep the room is ──────────────────────────────────
   The one number that decides whether this reads as a card
   turning or as a poster being sheared. Perspective is the
   distance from the viewer to the screen, so a small number
   is a face close to the glass: the near corner grows, the
   far corner shrinks, and ten degrees looks like thirty.

   800 against a 320px card is about two and a half card
   heights back — far enough that the foreshortening is a
   suggestion rather than a fisheye, close enough that the
   corners are visibly different sizes. It is not a knob
   because it is not a separate idea from the tilt: both
   answer "how 3D", and two sliders for one feeling is how a
   panel stops meaning anything. */
const DEPTH = 800;

/* how far the whole card retreats while it is being touched.
   Small on purpose — this is the difference between a card
   that tips and a card that is pushed, and at anything past
   about twenty it stops being a press and becomes a zoom. */
const SINK = 14;

const CORNER = 20;
const TILT = 10;
const SHADE = 60;

/* ── inlined from ./spring ──────────────────────── */
/* ── one spring, for everything that settles ───────────────
   The maths was already on this bench twice, copied by hand:
   Humidity's wheel and Brightness's column both accumulate
   velocity toward a target, damp it, and snap when both the
   delta and the velocity fall under 0.02. Two copies is a
   coincidence; five would be a policy, so it comes out here
   before the elastic blocks are written against it.

   The two shipped copies are deliberately NOT refactored onto
   this. They work, they are tuned, and rewriting the innards
   of two live components to prove a point about duplication
   is how a good afternoon becomes a bad one. This is the one
   new code uses.

   Frames, not milliseconds. \`dt\` is expressed in sixtieths of
   a second and the damping is RAISED to it rather than
   multiplied by it, so a dropped frame decays the same amount
   of energy as the two frames it replaced. Multiplying is the
   version that makes a spring behave differently on a busy
   page, which is the hardest kind of bug to see.

   The loop parks itself the moment the value has settled.
   CLAUDE.md is not complimentary about the one permanent
   requestAnimationFrame already on this bench and there is no
   case for five more. */

/* 0..100 into the two numbers a spring actually has.

   50 is what Humidity and Brightness were tuned at, which is
   the rule every elastic knob on this bench follows — see
   lab/motion. Turn the panel to the middle and nothing has
   changed.

   Both ends have to be usable, which is what fixes the range:
   at 0 it is slow and heavy and still arrives, at 100 it is
   quick with a visible overshoot, and nowhere in between does
   it ring for longer than it takes to read. */
/* The pair is chosen by DAMPING RATIO and then written back
   as stiffness and decay, because the ratio is the thing a
   person is actually setting and the two numbers on their own
   do not say what they add up to.

     zeta = -ln(d) / (2 * sqrt(k))

   The first version of this ran 0.06..0.26 stiffness against
   0.93..0.74 decay, which reads as a sensible spread and is
   not one: it puts zeta between 0.15 and 0.16 across the
   WHOLE range, so every setting overshot by about sixty per
   cent and the knob only changed how fast it did it. Pull's
   return went 130px past its own resting position and lifted
   the content off the top of the card.

     0   → zeta ~0.85, heavy, arrives without a ring
     50  → zeta ~0.41, near where Humidity and Brightness sit
     100 → zeta ~0.20, lively, two visible rebounds

   Both ends shippable, which is the constraint that fixed the
   numbers rather than taste. */
const springOf = (tune: number) => ({
  /* stiffness: how hard it is pulled toward the target */
  k: 0.08 + (tune / 100) * 0.16,
  /* decay, per frame: how much of the velocity survives */
  d: 0.62 + (tune / 100) * 0.2,
});

/* Units matter. The snap threshold is absolute, so a caller
   works in pixels or in 0..100 — a spring driven over 0..1
   would be "settled" before it had visibly moved. */
function useSpring(target: number, tune = 50, instant = false) {
  const [at, setAt] = useState(target);
  const cur = useRef(target);
  const vel = useRef(0);
  const raf = useRef(0);

  useEffect(() => {
    if (instant) {
      cur.current = target;
      vel.current = 0;
      setAt(target);
      return;
    }
    const { k, d } = springOf(tune);
    let prev = 0;
    const tick = (t: number) => {
      const dt = prev ? clamp((t - prev) / 16.67, 0, 2.5) : 1;
      prev = t;
      vel.current += (target - cur.current) * k * dt;
      vel.current *= Math.pow(d, dt);
      cur.current += vel.current * dt;
      if (Math.abs(target - cur.current) < 0.02 && Math.abs(vel.current) < 0.02) {
        cur.current = target;
        vel.current = 0;
        setAt(target);
        raf.current = 0;
        return;
      }
      setAt(cur.current);
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf.current);
      raf.current = 0;
    };
    /* \`tune\` sits here beside \`target\` for the reason
       Brightness spells out: the loop closes over it, so
       without it a knob turned mid-flight would do nothing
       until something else restarted the effect. Restarting
       picks up from the refs, so it continues rather than
       snapping. */
  }, [target, tune, instant]);

  return at;
}

/* Read once, the way the wheel and the pill nav do. A
   preference, not a live input. */
const stillness = () =>
  typeof window !== "undefined" &&
  !!window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

export function Tilt({
  /* the most either axis turns, in degrees */
  tilt = TILT,
  corner = CORNER,
  /* how dark the dent gets, 0..100 */
  shade = SHADE,
}: { tilt?: number; corner?: number; shade?: number } = {}) {
  const skin = useRef<HTMLDivElement | null>(null);
  const [at, setAt] = useState({ x: 0, y: 0 });
  const [on, setOn] = useState(false);
  const still = stillness();

  /* ── the state, and there is only this ───────────────────
     Where the pointer is, as -1..1 on each axis, sprung. The
     spring is on the POSITION rather than on the rotation, so
     the gradients and the transform can never disagree about
     where the finger is — they are three readings of one
     number instead of three things being animated towards
     the same place.

     Sprung rather than tracked one-to-one because a card with
     no weight follows the cursor exactly and reads as a
     texture pinned to the mouse. The lag is what gives it
     mass, and the settle on the way out is the only reason
     leaving the card feels like anything at all. */
  const sx = useSpring(on ? at.x : 0, 50, still);
  const sy = useSpring(on ? at.y : 0, 50, still);
  /* one more for how much of any of this applies, so the
     shadow and the sheen fade rather than cutting */
  const lit = useSpring(on ? 1 : 0, 50, still);

  const max = clamp(tilt, 0, 20);
  const rx = -sy * max;
  const ry = sx * max;

  /* the pointer in the card's own terms, as a PERCENTAGE —
     the wall and the overlay both draw this block at their
     own scale, and a gradient placed in pixels would land
     somewhere else in each of them */
  const px = ((sx + 1) / 2) * 100;
  const py = ((sy + 1) / 2) * 100;

  const dark = (clamp(shade, 0, 100) / 100) * 0.55 * lit;
  const rim = (clamp(shade, 0, 100) / 100) * 0.34 * lit;

  const track = (e: React.PointerEvent) => {
    const el = skin.current;
    if (!el) return;
    /* measured from the FRAME, which never moves. Reading the
       card instead would be asking a rotating object where it
       is, and near the edges it has already turned away from
       the pointer that is asking. */
    const r = el.getBoundingClientRect();
    setAt({
      x: clamp(((e.clientX - r.left) / r.width) * 2 - 1, -1, 1),
      y: clamp(((e.clientY - r.top) / r.height) * 2 - 1, -1, 1),
    });
    setOn(true);
  };

  return (
    <div
      className="tlt"
      ref={skin}
      style={{ width: W, height: H, perspective: DEPTH }}
      /* pointer, not mouse: the same handler carries a finger
         dragged across the card, so a phone gets the effect
         while it is being touched rather than getting nothing
         at all. */
      onPointerMove={track}
      /* ── \`out\` with a containment test, NOT \`leave\` ───────
         Which is what leave IS — the browser derives it from
         exactly this event by asking whether the thing you
         moved to is inside the thing you were on — so this is
         not a second mechanism, it is the same one written
         out. What it buys is the case React would not
         synthesise: the rehearsal drives a scripted pointer by
         dispatching \`pointerout\`, and its final beat walks off
         the card carrying \`relatedTarget: null\`. Measured, no
         \`onPointerLeave\` came of it, and every card on the
         wall finished its demo still sunk under a cursor that
         had gone.

         Null counts as outside, which is also the honest
         answer for a real pointer leaving the window. */
      onPointerOut={(e) => {
        const el = skin.current;
        const to = e.relatedTarget as Node | null;
        if (!el || !to || !el.contains(to)) setOn(false);
      }}
      /* a touch taken over by a scroll never reports leaving */
      onPointerCancel={() => setOn(false)}
    >
      <div
        className="tlt-card"
        style={{
          borderRadius: clamp(corner, 0, 40),
          backgroundImage: \`url(\${BUTTERFLY})\`,
          /* translateZ FIRST, so the retreat is measured in
             the room's axes rather than in the card's own —
             after a rotation, the card's z points somewhere
             off to the side and "back" stops meaning back. */
          transform: \`translateZ(\${-SINK * lit}px) rotateX(\${rx}deg) rotateY(\${ry}deg)\`,
          /* ── the shadow TIGHTENS ────────────────────────
             A thing pressed into a surface has less air under
             it, so the gap closes and the shadow draws in.
             Growing it on hover is the reflex — it is what a
             card that LIFTS would do — and it fights every
             other cue here. */
          boxShadow: \`0 \${mix(20, 9, lit)}px \${mix(44, 24, lit)}px -8px rgba(15, 23, 42, \${mix(
            0.22,
            0.15,
            lit,
          )})\`,
        }}
      >
        {/* ── the dent, and the rim opposite it ───────────
            The shadow pools where the surface is deepest,
            which is under the pointer, and the light catches
            the far edge that has risen — so the two are
            placed at mirrored points and neither is centred
            on anything. This is the layer that makes the
            transform read as a press. */}
        <span
          className="tlt-sheen"
          aria-hidden="true"
          style={{
            backgroundImage: \`radial-gradient(42% 34% at \${px}% \${py}%, rgba(9, 14, 28, \${dark}) 0%, rgba(9, 14, 28, 0) 100%), radial-gradient(52% 42% at \${
              100 - px
            }% \${100 - py}%, rgba(255, 255, 255, \${rim}) 0%, rgba(255, 255, 255, 0) 100%)\`,
          }}
        />
      </div>
    </div>
  );
}
`,css:`/* ══ Tilt ═══════════════════════════════════════════════════
   A picture card that gives under the pointer. Almost nothing
   is here: the rotation, both gradients and the shadow are
   written per frame from the pointer's position, and a rule
   in this file that also had an opinion about any of them
   would be a second author. What is left is the things that
   are true whatever the pointer is doing. */
.tlt {
  position: relative;
  /* The frame is what the pointer is measured against and it
     is deliberately the ONLY thing in here that never moves.
     The perspective lives on it rather than on the card for
     the usual reason: on the card itself, \`perspective\` is
     applied per element and the vanishing point rides along
     with the rotation instead of staying put in the room. */}

.tlt-card {
  position: absolute;
  inset: 0;
  background-color: var(--surface-2);
  background-size: cover;
  background-position: center;
  /* \`cover\` and a fixed frame, so the crop is the one
     scripts/butterfly.sh already made rather than a second
     one on top of it */
  overflow: hidden;
  /* NO \`will-change\`. It would hold a composited layer for
     every copy of this block on the wall, permanently, to
     save one frame on a hover that may never come — the same
     bookkeeping CLAUDE.md objects to for permanent rAF. The
     browser promotes this on its own once the transform
     starts moving. */}

/* ── the dent and the rim ───────────────────────────────────
   One element, two gradients, both placed from the pointer —
   the dark one under it and the light one at its mirror. It
   inherits the corner rather than being told one, so the knob
   only has to reach the card. */
.tlt-sheen {
  position: absolute;
  inset: 0;
  border-radius: inherit;
  pointer-events: none;}`,tokens:[`--surface-2`],deps:[],stubs:[`BUTTERFLY`]},sound:{tsx:`import { useEffect, useRef, useState } from "react";
import { Heart, SkipBack, SkipForward } from "lucide-react";

/* COVER was Bencho's own pictures, which are not licensed
   to travel. Point this at yours. */
const COVER: string = "";

/* ══ Sound ════════════════════════════════════════════════
   A now-playing pill that opens into a player.

   ONE NUMBER IS THE STATE. There is a single spring running
   0 → 100, and every position, size, radius and type size
   below is read off it. Nothing has a transition of its own
   and nothing is on a clock — which is the whole reason the
   transformation reads as one object changing rather than as
   several elements that were told to move at the same time.
   With eight CSS transitions there are eight chances for one
   of them to arrive early; with one spring there are none.

   THE COVER IS THE HINGE. It is the only thing on the pill
   big enough to be recognised, so it is the thing the eye
   tracks, and it never disappears or crossfades — it travels
   from a 44px square at the left of a bar to a 220px square
   at the top of a card. Everything else takes its lead from
   where the cover went.

   The width never changes. A pill that also got wider would
   be growing in two directions at once, and the second one
   adds nothing: what a player does when it opens is show you
   more, downward. Holding the width still also means the
   right-hand controls only have to travel, not resize and
   travel — they slide in from the end of the bar and settle
   into a row under the art. */

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));
const mix = (a: number, b: number, t: number) => a + (b - a) * t;

/* ── eased, NOT sprung ─────────────────────────────────────
   The bench's shared useSpring is the wrong tool for this one
   thing, and the reason is the corner. A spring past its
   target takes every value derived from it along — measured
   at the tuned default it reached 492 against a target of
   404, and the radius went with it, dipping under 26 and
   coming back. That is a wobble, not a bounce, and it is the
   same mistake the create menu made and had removed.

   So: a curve that is quick off the mark and lands without
   ever passing the number it is going to. Quart-out is
   cubic-bezier(0.22, 1, 0.36, 1) in all but name, which is
   what every other one-shot morph on this bench uses.

   It reads its start from wherever it currently IS, so
   pressing again mid-flight turns the object around rather
   than snapping it to an end it never reached. */
const BASE = 460;

const QUART = (t: number) => 1 - (1 - t) ** 4;
/* the swell's clock — see the note where it is used */
const FLAT = (t: number) => t;
/* in AND out, for the one thing here that is a round trip
   between two shapes rather than an arrival at one */
const SWING = (t: number) =>
  t < 0.5 ? 4 * t ** 3 : 1 - (-2 * t + 2) ** 3 / 2;

function useTween(to: number, ms: number, instant = false, ease = QUART) {
  const [at, setAt] = useState(to);
  const cur = useRef(to);
  const raf = useRef(0);

  useEffect(() => {
    if (instant) {
      cur.current = to;
      setAt(to);
      return;
    }
    const from = cur.current;
    if (from === to) return;
    const t0 = performance.now();
    const step = (now: number) => {
      const t = Math.min(1, (now - t0) / ms);
      cur.current = from + (to - from) * ease(t);
      setAt(cur.current);
      raf.current = t < 1 ? requestAnimationFrame(step) : 0;
    };
    raf.current = requestAnimationFrame(step);
    return () => {
      cancelAnimationFrame(raf.current);
      raf.current = 0;
    };
  }, [to, ms, instant, ease]);

  return at;
}

/* One width for both states, and the frame's width too. */
const W = 260;
/* the bar, and the card. The frame is sized to the CARD —
   the wall fits a component by its bounding box, so a frame
   that grew would rescale the whole card mid-morph. */
/* 78, not 70. The track needs a band of its own at the foot —
   at 70 it cleared the sleeve by seven pixels, which reads as
   crowding it rather than as a line of its own. */
const SHUT = 78;
/* ── the card is the bar, grown ────────────────────────────
   It used to put a 232px sleeve across the top with the words
   underneath — a different LAYOUT at the far end of the morph,
   which meant the words had to travel from beside the cover to
   below it while the cover itself moved and quadrupled. Three
   things rearranging at once is a transition you watch rather
   than an object you opened.

   So the arrangement is the same at both ends: sleeve left,
   words beside it, and the only thing that MOVES between the
   two is the transport — from the end of the row down to the
   middle, which is the one change worth reading. Everything
   else simply gets bigger.

   398 to 218 as a side effect, and that is not a small one:
   the wall fits a component by its bounding box, so the frame
   is what decided how small the bar was drawn. At 260x398 the
   longest side was the height and everything rendered at 0.64.
   At 260x218 the width wins and it draws at full size.

   Its HEIGHT is declared under the stack it falls out of. */

/* ── ONE margin, both states ───────────────────────────────
   Not one per state. It was 10 on the bar and 16 on the card,
   which meant the sleeve, the track and the transport all
   slid inward as the thing opened — a fourth motion nobody
   asked for, on top of the three that are the point. The
   object grows; its frame does not move.

   Everything answers to it: the sleeve's inset, the rail's
   inset, where the transport row ends, and the room under it.
   These used to be four numbers agreeing by luck — 8 here, 10
   there, 16 for the vertical — which is also why nothing
   looked tight.

   The sleeve is square, so one number is its width and its
   height at each end — and on the card it is the number the
   whole stack below is measured from. */
const PAD = 10;
const ART = { s: [40, 64] } as const;

/* ── the two corners, and they are CONCENTRIC ──────────────
   The box's radius is the sleeve's plus the margin between
   them. That is not a preference, it is what makes a corner
   hug what is inside it: two curves offset by a constant
   distance stay parallel, and any other pair pinches at 45°.

   32 was picked by eye and it was 6 too many — the card's
   curve swept wider than the sleeve's and left the artwork's
   top-left sitting inside a bend that had already turned.
   26 = 16 + 10 hugs it, and the bar's 20 = 10 + 10 does the
   same at its own size.

   ── AND THAT IS WHY IT CAN BE A KNOB AGAIN ────────────────
   It was a control once and it was removed, because what it
   set was the BOX's corner on its own: turn it down and the
   card squared off around a sleeve that had not, turn it up
   and the card's curve swept wide of the picture inside it.
   Every setting but one was wrong, so the honest fix was to
   delete the knob and keep the one.

   What the knob sets now is the SLEEVE, and the box is
   derived from it — \`sleeve + PAD\`, the same rule as before.
   So the two corners stay concentric at every value, and
   there is no setting that pinches. The knob moves a
   relationship rather than one of its two halves.

   It runs to 32 and stops there because that is where the
   64px sleeve becomes a circle; there is nothing past it but
   the same shape with a bigger number. The bar's sleeve
   scales by the ratio of the two squares, so it reaches its
   own circle at exactly the same setting. Square at one end
   of the slider, pill at the other, and the default sits
   where it always was. */
const CORNER = 16;
const CORNER_MAX = 32;

/* ── the card's stack, measured from the sleeve down ───────
   Each gap is the distance from the thing above it, and the
   card's HEIGHT falls out of the sum rather than being a
   number somebody kept in step by hand. Change the sleeve and
   the rail, the times, the transport and the foot all follow.

   The bar needs none of this: it is one row and a track, and
   both are placed off the same margin. */
const RAIL_GAP = 22;
const CLOCK_GAP = 8;   /* also .snd-bar's own gap */
const OPS_GAP = 16;
const RAIL_H = 3;
const CLOCK_H = 10;
const LEAD = 46;       /* the play button, opened */

const RAIL_Y = PAD + ART.s[1] + RAIL_GAP;
const OPS_Y = RAIL_Y + RAIL_H + CLOCK_GAP + CLOCK_H + OPS_GAP + LEAD / 2;
/* the transport's own bottom, and one more margin under it */
const OPEN = Math.round(OPS_Y + LEAD / 2 + PAD);

const TOTAL = 214;

/* ── the play mark is DRAWN, not swapped ───────────────────
   Two icons exchanged is a cut, however short you make the
   crossfade, and a transport button is the one control here
   you press more than once — a cut you see forty times is the
   thing you end up looking at.

   So both marks are the SAME two quadrilaterals, and the
   difference between them is where eight points are. The
   pause is a pair of bars; the play is that pair with the
   inner edges pulled to the middle and collapsed to a point,
   which is a triangle split down its own axis. Nothing
   appears and nothing leaves — the shapes are continuous the
   whole way, so there is no frame where the button is
   ambiguous about what it does.

   The points are lucide's own, so it sits at the same weight
   as the skip glyphs beside it: bars at x 6..10 and 14..18,
   a triangle from 6.5 to 20, stroked 2 with a round join,
   which is where the softened corners come from.

   Wound the same way in both — top-left, top-right,
   bottom-right, bottom-left — or the halves would turn
   inside out on the way across. The play's right half is a
   triangle written as a quad with its two right points on
   top of each other. */
const PAUSE_L = [6, 4, 10, 4, 10, 20, 6, 20] as const;
const PLAY_L = [6.5, 4, 13.25, 8, 13.25, 16, 6.5, 20] as const;
const PAUSE_R = [14, 4, 18, 4, 18, 20, 14, 20] as const;
const PLAY_R = [13.25, 8, 20, 12, 20, 12, 13.25, 16] as const;

const quad = (a: readonly number[], b: readonly number[], t: number) => {
  let d = "";
  for (let i = 0; i < 8; i += 2)
    d += \`\${i ? "L" : "M"}\${mix(a[i], b[i], t).toFixed(2)} \${mix(
      a[i + 1],
      b[i + 1],
      t,
    ).toFixed(2)}\`;
  return \`\${d}Z\`;
};

function Mark({
  playing,
  size,
  still,
}: {
  playing: boolean;
  size: number;
  still: boolean;
}) {
  /* 0 is the pause, 1 is the play. Eased both ends, unlike
     the box's own move: this one leaves a shape as well as
     arriving at one, and a curve that only softens the
     landing snaps out of the shape it was. */
  const t = useTween(playing ? 0 : 1, 300, still, SWING);

  /* ── the goo ─────────────────────────────────────────────
     Zero at both ends and one in the middle, so everything
     below is a bulge on the way rather than a difference
     between the two states — press twice and it lands on
     exactly what it started as.

     Three things ride it, and they are all the same idea:
     the mark squashes across as it stretches up, the two
     halves lean into each other until they touch, and the
     whole thing tips a few degrees and comes back level. A
     shape that changes size without ever changing volume is
     what makes something read as soft rather than as
     redrawn. The tilt swaps sign with the direction, so
     pausing is not just playing run backwards. */
  const goo = Math.sin(clamp(t, 0, 1) * Math.PI);
  const pull = 1.6 * goo;
  const tip = (playing ? -9 : 9) * goo;

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      aria-hidden="true"
      fill="currentColor"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinejoin="round"
      strokeLinecap="round"
      /* per cent, not pixels: this is the element's own box
         and the box is whatever size the morph is at. */
      style={{
        transformOrigin: "50% 50%",
        transform: \`rotate(\${tip}deg) scale(\${1 - 0.13 * goo}, \${1 + 0.11 * goo})\`,
      }}
    >
      <path d={quad(PAUSE_L, PLAY_L, t)} transform={\`translate(\${pull} 0)\`} />
      <path d={quad(PAUSE_R, PLAY_R, t)} transform={\`translate(\${-pull} 0)\`} />
    </svg>
  );
}

/* the heart's box, and the room the words give up for it */
const LIKE = 30;

const clock = (s: number) =>
  \`\${Math.floor(s / 60)}:\${String(Math.floor(s % 60)).padStart(2, "0")}\`;

/* ── inlined from ./motion ──────────────────────── */
/* ── elastic, as numbers a person can hold ─────────────────
   Several blocks here are the same idea in different clothes:
   something travels, stretches on the way, and overshoots
   when it lands. Their character lives in a duration and in
   one control point of a bezier — which is exactly the kind
   of thing nobody should have to name in order to tune.

   So the outside of every elastic knob is 0..100 and the
   inside is real units, and **50 is always what the component
   was already tuned to**. Turn every knob on the bench to the
   middle and nothing has changed. That is what makes these
   safe to expose: the default is not a number somebody has to
   remember, it is the middle of the slider.

   Both ends have to be shippable, which is the constraint
   that actually shapes these curves. The ranges below stop
   where the effect stops being the thing it is — a bar that
   moves in 40ms still reads as a bar snapping to a slot; one
   that moves in 20ms reads as broken. */

/* How long it takes, slower to faster, as a multiplier on
   whatever the component's own tuned duration is. 0 is a
   little over half again as slow, 100 is two and a half times
   as fast, 50 is exactly 1. */
const rate = (speed: number) => 1.6 - (speed / 100) * 1.2;

/* How hard it lands.

   In a cubic-bezier the second control point's y is the whole
   of an overshoot: at 1 the thing stops dead on its target,
   and past 1 it travels beyond and comes back. Everything
   else in the curve is the approach and stays put.

   \`tuned\` is the y this component was drawn with, so 50
   returns it unchanged and the slider is centred on the
   design rather than on some shared average. */
const overshoot = (bounce: number, tuned: number) =>
  Number((1 + (bounce / 100) * (tuned - 1) * 2).toFixed(3));

/* the same, ready to drop into a transition */
const curve = (bounce: number, tuned: number, x1 = 0.28, x2 = 0.36) =>
  \`cubic-bezier(\${x1}, \${overshoot(bounce, tuned)}, \${x2}, 1)\`;

/* ── inlined from ./spring ──────────────────────── */
/* ── one spring, for everything that settles ───────────────
   The maths was already on this bench twice, copied by hand:
   Humidity's wheel and Brightness's column both accumulate
   velocity toward a target, damp it, and snap when both the
   delta and the velocity fall under 0.02. Two copies is a
   coincidence; five would be a policy, so it comes out here
   before the elastic blocks are written against it.

   The two shipped copies are deliberately NOT refactored onto
   this. They work, they are tuned, and rewriting the innards
   of two live components to prove a point about duplication
   is how a good afternoon becomes a bad one. This is the one
   new code uses.

   Frames, not milliseconds. \`dt\` is expressed in sixtieths of
   a second and the damping is RAISED to it rather than
   multiplied by it, so a dropped frame decays the same amount
   of energy as the two frames it replaced. Multiplying is the
   version that makes a spring behave differently on a busy
   page, which is the hardest kind of bug to see.

   The loop parks itself the moment the value has settled.
   CLAUDE.md is not complimentary about the one permanent
   requestAnimationFrame already on this bench and there is no
   case for five more. */

/* 0..100 into the two numbers a spring actually has.

   50 is what Humidity and Brightness were tuned at, which is
   the rule every elastic knob on this bench follows — see
   lab/motion. Turn the panel to the middle and nothing has
   changed.

   Both ends have to be usable, which is what fixes the range:
   at 0 it is slow and heavy and still arrives, at 100 it is
   quick with a visible overshoot, and nowhere in between does
   it ring for longer than it takes to read. */
/* The pair is chosen by DAMPING RATIO and then written back
   as stiffness and decay, because the ratio is the thing a
   person is actually setting and the two numbers on their own
   do not say what they add up to.

     zeta = -ln(d) / (2 * sqrt(k))

   The first version of this ran 0.06..0.26 stiffness against
   0.93..0.74 decay, which reads as a sensible spread and is
   not one: it puts zeta between 0.15 and 0.16 across the
   WHOLE range, so every setting overshot by about sixty per
   cent and the knob only changed how fast it did it. Pull's
   return went 130px past its own resting position and lifted
   the content off the top of the card.

     0   → zeta ~0.85, heavy, arrives without a ring
     50  → zeta ~0.41, near where Humidity and Brightness sit
     100 → zeta ~0.20, lively, two visible rebounds

   Both ends shippable, which is the constraint that fixed the
   numbers rather than taste. */
const springOf = (tune: number) => ({
  /* stiffness: how hard it is pulled toward the target */
  k: 0.08 + (tune / 100) * 0.16,
  /* decay, per frame: how much of the velocity survives */
  d: 0.62 + (tune / 100) * 0.2,
});

/* Units matter. The snap threshold is absolute, so a caller
   works in pixels or in 0..100 — a spring driven over 0..1
   would be "settled" before it had visibly moved. */
function useSpring(target: number, tune = 50, instant = false) {
  const [at, setAt] = useState(target);
  const cur = useRef(target);
  const vel = useRef(0);
  const raf = useRef(0);

  useEffect(() => {
    if (instant) {
      cur.current = target;
      vel.current = 0;
      setAt(target);
      return;
    }
    const { k, d } = springOf(tune);
    let prev = 0;
    const tick = (t: number) => {
      const dt = prev ? clamp((t - prev) / 16.67, 0, 2.5) : 1;
      prev = t;
      vel.current += (target - cur.current) * k * dt;
      vel.current *= Math.pow(d, dt);
      cur.current += vel.current * dt;
      if (Math.abs(target - cur.current) < 0.02 && Math.abs(vel.current) < 0.02) {
        cur.current = target;
        vel.current = 0;
        setAt(target);
        raf.current = 0;
        return;
      }
      setAt(cur.current);
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf.current);
      raf.current = 0;
    };
    /* \`tune\` sits here beside \`target\` for the reason
       Brightness spells out: the loop closes over it, so
       without it a knob turned mid-flight would do nothing
       until something else restarted the effect. Restarting
       picks up from the refs, so it continues rather than
       snapping. */
  }, [target, tune, instant]);

  return at;
}

/* Read once, the way the wheel and the pill nav do. A
   preference, not a live input. */
const stillness = () =>
  typeof window !== "undefined" &&
  !!window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

export function Sound({
  /* how quickly the shape changes, 0..100 — 50 is the tuned
     460ms, and neither end is broken: 736 reads as deliberate
     and 184 as brisk. */
  morph = 50,
  /* the sleeve's corner on the card, 0..32, and the box's
     corner follows it — see the note above */
  corner = CORNER,
}: { morph?: number; corner?: number } = {}) {
  const skin = useRef<HTMLDivElement | null>(null);
  const [open, setOpen] = useState(false);
  const [going, setGoing] = useState(false);
  const [liked, setLiked] = useState(false);
  const [at, setAt] = useState(52);
  const still = stillness();

  const dur = BASE * rate(clamp(morph, 0, 100));

  /* the sleeve's corner at each end, and the box's from it.
     The bar's sleeve is the smaller square, so it takes the
     same fraction of its own side — a 16 on a 64 and a 10 on
     a 40 are the same corner at two sizes. */
  const cr = clamp(corner, 0, CORNER_MAX);
  const artR = [(cr * ART.s[0]) / ART.s[1], cr] as const;

  /* ── the offset FADES IN, it is not a constant ───────────
     \`outer = inner + margin\` is the right rule for a corner
     hugging what is inside it, and it was applied flat: ten
     pixels of offset at every setting, including zero. Which
     meant the bottom of the slider drew a perfectly sharp
     picture inside a card that was still visibly rounded —
     geometrically concentric and, to look at, two different
     decisions in the same object. The rule was answering a
     question nobody had asked there: at radius zero there is
     no curve to stay parallel to.

     So the offset is scaled by how far up the slider you are,
     and reaches its full ten by the default. Below that the
     two corners converge until they are both square together;
     above it the rule takes over, which is where it earns its
     keep — a mismatch at 32 pinches, a mismatch at 2 is just
     a card that did not follow.

     The default and the top of the range are untouched: at
     16 the offset is exactly 10 and at 32 it is capped there,
     so the shipping shape is the shape it always was. */
  const off = PAD * Math.min(1, cr / CORNER);
  const boxR = [artR[0] + off, artR[1] + off] as const;

  /* 0 shut, 1 open. Tweened once, read everywhere. */
  const p = useTween(open ? 1 : 0, dur, still);

  /* ── the swell, and why it is a SECOND number ────────────
     The bench had this as a spring once and it was removed,
     for the reason written at the top of this file: a value
     past its target takes everything derived from it along,
     and what is derived here is the corner. The radius dipped
     under its own end value and came back — the box arrived,
     and then its corner arrived. That is a wobble.

     So the bounce is not put back into \`p\`. \`p\` stays
     monotonic and the composition stays internally consistent
     at every frame — the sleeve, the box and the margin
     between them are always in the ratio that makes the
     corners concentric.

     What bounces is the whole object, uniformly. A scale
     takes the box, the sleeve, the corners and the type
     together, so nothing can get out of step with anything
     else: it is the same picture, briefly larger. All the
     life, none of the wobble.

     It rides its own LINEAR clock rather than \`p\`, because
     \`p\` is quart-out and near its end for most of the move —
     a swell read off it would spike in the first two frames
     and be flat for the rest. And the peak is pushed late
     (^1.5 puts it at 0.63) so the object gathers on the way
     out and releases as it lands, which is what reads as a
     bounce rather than as a pulse.

     Zero at BOTH ends by construction, so it costs the
     resting shape nothing — sin(0) and sin(π) are the same
     number.

     ── ON THE CLOSE ONLY ────────────────────────────────────
     It grew on the way out too, and that was one motion too
     many. Opening already HAS its event: the box goes from 78
     to 189 and that is the whole thing you are meant to
     watch. A scale on top of it is a second size change
     running at the same time in the same direction, and two
     of those do not add up to more life — they read as the
     card being unsure how big it is.

     Closing is the opposite problem. The card collapses into
     a bar and most of it simply stops existing, so there is
     nothing to watch except the disappearance. The dip gives
     it a gather to go with it — the object pulls in on itself
     before it lands — and because it is subtractive it is
     working WITH the shrink rather than against it.

     An object coming towards you and one folding away are not
     the same move run backwards. */
  const u = useTween(open ? 1 : 0, dur, still, FLAT);
  const swell = Math.sin(Math.PI * clamp(u, 0, 1) ** 1.5);
  const zoom = open ? 1 : 1 - 0.035 * swell;

  /* ── the clock ───────────────────────────────────────────
     Nothing moves until somebody presses play, which is the
     difference between a component and a screensaver. It is
     also why the wall can hold twenty of these: at rest this
     component has no timer at all. */
  useEffect(() => {
    if (!going) return;
    const id = window.setInterval(
      () => setAt((s) => (s >= TOTAL ? 0 : s + 1)),
      1000,
    );
    return () => window.clearInterval(id);
  }, [going]);

  /* ── outside closes it ───────────────────────────────────
     Only while it is open, and only for a press that started
     outside the box. \`pointerdown\` rather than click: a press
     that begins outside and drifts in is still somebody
     reaching past this component, and waiting for the click
     lets it land on whatever is underneath first.

     Bound on the document because the thing being dismissed
     has no idea what is around it — the wall, the canvas and
     the detail overlay all show this block and none of them
     should have to know it can be open. */
  useEffect(() => {
    if (!open) return;
    const away = (e: PointerEvent) => {
      /* ── isTrusted, or the demonstrations close it ────────
         Every card on the wall that carries a \`demo\` drives a
         scripted pointer at its own component, and those
         events bubble to the document like any other. Without
         this guard, a rehearsal anywhere on the page — this
         block's own included — read as somebody reaching past
         this player and shut it a frame after it opened.
         Measured: it climbed to 403 and then turned around on
         its own.

         The same guard Orbit's ring carries, for the same
         reason. Only a real hand dismisses this. */
      if (!e.isTrusted) return;
      const el = skin.current;
      if (el && !el.contains(e.target as Node)) setOpen(false);
    };
    /* the next tick, or the press that opened it closes it */
    const id = window.setTimeout(
      () => document.addEventListener("pointerdown", away),
      0,
    );
    return () => {
      window.clearTimeout(id);
      document.removeEventListener("pointerdown", away);
    };
  }, [open]);

  const art = {
    x: PAD,
    /* At the margin in both states, and NOT centred in the bar
       any more: the bar is not symmetric top to bottom, because
       the track has a band of its own down there. The sleeve,
       the words and the transport are one row against the top
       margin; everything below them belongs to the track. */
    y: PAD,
    s: mix(ART.s[0], ART.s[1], p),
  };

  /* Everything below is derived, never stored. A second piece
     of state describing the same transformation is a second
     thing that can be out of step with the first. */
  const h = mix(SHUT, OPEN, p);

  /* the transport: at the end of the bar, then centred under
     the art. The row's own width changes, so it is placed by
     its centre rather than by an edge. */
  /* ── the transport, at both ends ─────────────────────────
     All three buttons exist in both states now. Shut they are
     smaller and almost touching — 24, 30, 24 with a single
     pixel between — and the row is pinned to the right so the
     play button lands where a thumb goes without looking.
     Open they spread and the play grows.

     Placed by the row's CENTRE, because the row's own width
     changes: an edge would move even in the frames where the
     middle of it did not. 212 is the box less 8 of margin and
     half of the 80 the row is when shut. */
  const side = mix(24, 34, p);
  const lead = mix(30, LEAD, p);
  /* 1 was three controls touching, which reads as one object
     with three parts rather than as three things you press */
  const gap = mix(5, 14, p);
  /* the box, less its margin and half of the 88 the row is
     when shut */
  const opsX = mix(W - PAD - 44, W / 2, p);
  /* the type grows with the sleeve rather than on its own */
  /* level with the sleeve on the bar, and under everything on
     the card */
  /* 360, and it is measured rather than picked: the times sit
     under the rail and the row has to clear them. At 358 with
     the clock at its natural line height the two overlapped by
     7px — the buttons sat BESIDE the numbers rather than under
     them, which only reads as intentional if you never look at
     the left end of the row. */
  const opsY = mix(PAD + ART.s[0] / 2, OPS_Y, p);

  /* the deep half of the morph, for the things that only
     exist in the card. Held back to the last 40% so they
     arrive into a shape that has stopped growing rather than
     sliding about inside one that has not. */
  const late = clamp((p - 0.6) / 0.4, 0, 1);

  const flip = () => {
    setOpen((v) => !v);
  };

  return (
    <div className="snd" style={{ width: W, height: OPEN }}>
      <div
        className="snd-box"
        ref={skin}
        data-open={open || undefined}
        style={{
          width: W,
          height: h,
          borderRadius: mix(boxR[0], boxR[1], p),
          scale: zoom,
        }}
      >
        {/* the hinge. The sleeve is inlined rather than linked
            — see scripts/cover.sh — because the bundle is one
            file and a linked image is a dead square the moment
            it leaves this machine. */}
        <span
          className="snd-art"
          aria-hidden="true"
          style={{
            backgroundImage: \`url(\${COVER})\`,
            left: art.x,
            top: art.y,
            width: art.s,
            height: art.s,
            /* Squared, and near enough constant: the sleeve
               belongs to the same family as the box around it,
               and a disc inside a rounded rectangle is a
               different object. */
            borderRadius: mix(artR[0], artR[1], p),
          }}
        />

        <span
          className="snd-say"
          style={{
            /* beside the sleeve at BOTH ends — the gap grows
               with everything else and nothing reflows */
            left: mix(PAD + ART.s[0] + 10, PAD + ART.s[1] + 10, p),
            /* Level with the sleeve, and centred BY it: same
               top, same height, and the words centre
               themselves inside that. It was a top edge
               placed against a guess at how tall two lines
               are, which held until the type sizes changed —
               see the note in the stylesheet. */
            top: PAD,
            height: art.s,
            /* what is left between the sleeve and the row */
            /* what the smaller sleeve gives back */
            /* less the heart, which lives in the corner the
               words would otherwise run into. On the bar
               there is no heart and nothing to give up. */
            width: mix(94, W - PAD - (PAD + ART.s[1] + 10) - (LIKE + 10), p),
          }}
        >
          <span className="snd-title" style={{ fontSize: mix(13, 15.5, p) }}>
            Cabra Field
          </span>
          <span className="snd-by" style={{ fontSize: mix(11, 12, p) }}>
            Side B
          </span>
        </span>

        {/* ── the track ─────────────────────────────────────
            Only in the card, and it says so by not being
            there: opacity AND height, so it cannot leave a
            gap in the bar that nothing occupies. */}
        {/* ── the track ─────────────────────────────────────
            It is on the bar too, along the foot, edge to edge
            — a bar with no sense of how far through it is is
            missing the one thing a bar is for. Full bleed
            rather than tucked under the words: at 60px tall
            there is no room for a fourth line, and the pill's
            own corner clips the ends for free.

            The TIMES are the part that only belongs to the
            card. They fade with the deep half of the move and
            are clipped by the box until then, so they cost the
            bar no room at all. */}
        <span
          className="snd-bar"
          style={{
            /* OFF the edge on the bar too. It sat flush at the
               foot, which is a different object — a loading
               line belongs to the box's edge, and a track
               belongs to the thing playing. Inset by the same
               margin as everything else, it reads as part of
               the composition rather than as the box's own
               bottom border. */
            top: mix(SHUT - PAD - RAIL_H, RAIL_Y, p),
            /* one margin, so the track's ends never move */
            left: PAD,
            width: W - PAD * 2,
          }}
        >
          <span className="snd-rail">
            <span className="snd-run" style={{ width: \`\${(at / TOTAL) * 100}%\` }} />
          </span>
          <span className="snd-clock" style={{ opacity: late }}>
            <span>{clock(at)}</span>
            <span>−{clock(TOTAL - at)}</span>
          </span>
        </span>

        {/* ── the one thing you press to change shape ───────
            Invisible, and it is the WHOLE bar when shut — the
            track's band at the foot is part of the object, and
            a bar that only answers along the row its sleeve is
            in has a dead third nobody can see the edge of.

            Opened, it is the sleeve and the words only, so a
            player you have opened does not collapse because
            you reached for the title.

            Declared BEFORE the transport on purpose: both are
            positioned, so the later one paints on top, and the
            buttons have to win a press that lands on both. */}
        <button
          className="snd-tap"
          onClick={flip}
          aria-expanded={open}
          aria-label={open ? "Collapse the player" : "Open the player"}
          style={{
            left: mix(0, PAD, p),
            top: mix(0, PAD, p),
            width: mix(W, W - PAD * 2, p),
            /* every pixel of the bar, and the sleeve's own
               height once it is a card */
            height: mix(SHUT, ART.s[1], p),
            borderRadius: mix(boxR[0], artR[1], p),
          }}
        />

        {/* ── the heart ─────────────────────────────────────
            The card's one control that is not transport, and
            the only reason the card has a top-right corner
            worth anything: everything else here is a row.

            It belongs to the card alone. On the bar there is
            no room for a fourth control beside three that are
            already touching, and a heart is not what a pill
            is for — so it rides \`late\`, arriving after the
            box has stopped growing, and takes its hit area
            with it rather than sitting invisible over the
            words.

            After the tap, like the transport, so a press in
            the corner reaches the heart rather than closing
            the player underneath it. */}
        <button
          className="snd-like"
          data-on={liked || undefined}
          onClick={() => {
            setLiked((v) => !v);
          }}
          aria-label={liked ? "Remove from liked songs" : "Add to liked songs"}
          aria-pressed={liked}
          tabIndex={open ? 0 : -1}
          style={{
            left: W - PAD - LIKE,
            top: PAD,
            width: LIKE,
            height: LIKE,
            opacity: late,
            pointerEvents: late > 0.9 ? "auto" : "none",
          }}
        >
          <Heart size={16} strokeWidth={2} fill={liked ? "currentColor" : "none"} />
        </button>

        <span
          className="snd-ops"
          style={{ left: opsX, top: opsY, gap }}
        >
          {/* DRAWN, not filled — unlike the play. Three solid
              marks in a row of eighty pixels is a lot of ink
              for two controls you press rarely, and the
              difference in weight is what says which one is
              the button and which two are beside it. */}
          <button
            className="snd-op"
            style={{ width: side, height: side }}
            onClick={() => { setAt(0); }}
            aria-label="Restart"
          >
            <SkipBack size={mix(13, 16, p)} strokeWidth={2} />
          </button>

          <button
            className="snd-op"
            data-lead
            style={{ width: lead, height: lead }}
            onClick={() => { setGoing((v) => !v); }}
            aria-label={going ? "Pause" : "Play"}
            aria-pressed={going}
          >
            {/* ── FILLED, not drawn ─────────────────────────
                Transport marks are solid everywhere a person
                has met them, and an outlined triangle reads as
                a diagram of play rather than as play. The skip
                glyphs keep their stroke for a different
                reason: the bar beside each triangle is a line
                with no area, and dropping the stroke would
                drop the bar.

                This one is not a lucide icon at all — see
                Mark, above — because it is the only mark here
                that changes into another one. */}
            <Mark playing={going} size={mix(14, 18, p)} still={still} />
          </button>

          <button
            className="snd-op"
            style={{ width: side, height: side }}
            onClick={() => { setAt(0); }}
            aria-label="Next"
          >
            <SkipForward size={mix(13, 16, p)} strokeWidth={2} />
          </button>
        </span>

      </div>
    </div>
  );
}
`,css:`@media (prefers-reduced-motion: reduce) {
  .snd-op, .snd-art, .snd-like { transition-duration: 1ms; }
}

@media (prefers-reduced-motion: reduce) {
  .snd-like[data-on] .lucide { animation: none; }
}

/* ══ Sound board ════════════════════════════════════════════
   A canvas tool, not a component: twelve keys, numbered by
   their order in site/sound.ts, so a voice can be auditioned
   and then referred to by number. */
.snd {
  display: flex;
  flex-direction: column;
  gap: 10px;
  width: 460px;
  font-family: var(--font-ui);}

.snd-wake {
  align-self: flex-start;
  height: 30px;
  padding: 0 13px;
  border: 0;
  border-radius: 999px;
  background: var(--slab);
  color: var(--on-slab);
  font-family: inherit;
  font-size: 12.5px;
  font-weight: 500;
  cursor: pointer;}

.snd-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 8px;}

.snd-key {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  gap: 3px;
  height: 62px;
  padding: 0 12px;
  border: 0;
  border-radius: 12px;
  background: rgba(var(--ink-rgb), 0.05);
  cursor: pointer;
  transition: background 140ms ease, transform 160ms cubic-bezier(0.28, 1.3, 0.36, 1);}

.snd-key:hover { background: rgba(var(--ink-rgb), 0.1); }

.snd-key:active { transform: scale(0.96); }

/* the one that carries a position says so — drag across it */
.snd-key[data-pitched] { background: rgba(var(--ink-rgb), 0.08); cursor: ew-resize; }

.snd-key[data-pitched]:hover { background: rgba(var(--ink-rgb), 0.14); }

.snd-num {
  font-family: var(--font-num);
  font-size: 17px;
  line-height: 1;
  color: var(--ink);
  font-variant-numeric: tabular-nums;}

.snd-name {
  font-size: 11.5px;
  letter-spacing: -0.005em;
  color: var(--ink-4);}

/* ══ Sound ══════════════════════════════════════════════════
   A now-playing bar that opens into a player.

   There is almost nothing here, and that is deliberate: every
   position, size and radius in this component is written by
   the spring in Sound.tsx and arrives as an inline style. A
   transition on any of these rules would be a SECOND opinion
   about where a thing is, fighting the first one every frame.

   What is left is the material — the surfaces, the type and
   the two hover states — which never animates with the shape
   and so has nothing to fight. */

.snd {
  position: relative;
  display: grid;
  place-items: center;
  font-family: var(--font-ui);}

/* The object. It is the only thing on the card, so it is the
   quietest surface that still reads as one: the pane the rest
   of the bench uses, and a hairline. */
.snd-box {
  position: relative;
  background: var(--pane);
  -webkit-backdrop-filter: blur(2px) saturate(150%);
  backdrop-filter: blur(2px) saturate(150%);
  overflow: hidden;}

/* NO BORDER of its own. The hairline is the Stroke control's
   to give, the way it is for every other block — a spread
   shadow rather than a border, because the box has
   \`overflow: hidden\` and a border would be one more thing the
   morph has to carry through every frame. See the Stroke
   section above. */
[data-stroke="on"] .snd-box { box-shadow: 0 0 0 1px var(--pane-edge); }

/* ── the cover ──────────────────────────────────────────────
   A real sleeve, inlined by scripts/cover.sh. It was drawn in
   CSS first, on the reasoning that the morph is about the
   SQUARE rather than about what is printed on it — which is
   true of the animation and not true of the component: a
   player with a grey gradient where the artwork goes is a
   wireframe of a player.

   \`cover\`, not \`contain\`: the square is the fixed thing here
   and the picture is cropped to it, so the sleeve is never
   letterboxed at either end of the morph.

   The gradient stays underneath as the ground. It is what
   shows for the frame before a 464px image has decoded, and
   it is what the shape is if the file is ever missing. */
.snd-art {
  position: absolute;
  background-color: var(--surface-2);
  background-image:
    linear-gradient(148deg, var(--surface-3), var(--surface-2));
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;}

/* ── the words ──────────────────────────────────────────────
   One block that travels from beside the cover to under it.
   Both lines are in it, so the pair moves as a unit and the
   artist never arrives before the title. */
/* ── the words ──────────────────────────────────────────────
   Centred by the BOX, not by a number. It used to be placed
   by its top edge against a hard-coded guess at how tall two
   lines of type are — which was right until the type sizes
   changed, and then the words sat 1.8px above the middle of
   the sleeve at one end of the morph and somewhere else at
   the other.

   Now it is given the sleeve's own height and told to centre
   inside it, so the two are level at every size the morph
   passes through and nothing has to be kept in step by hand.
   Two magic numbers gone with it. */
.snd-say {
  position: absolute;
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 2px;
  min-width: 0;
  pointer-events: none;}

.snd-title {
  color: var(--ink);
  font-weight: 500;
  letter-spacing: -0.01em;
  line-height: 1.25;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;}

.snd-by {
  color: var(--ink-4);
  line-height: 1.25;
  white-space: nowrap;}

/* ── the track ──────────────────────────────────────────────
   A rail and a run, and the times at either end under it.
   Nothing here is interactive: this component is about the
   shape changing, and a scrubber you can drag is a different
   component that happens to live in the same box. */
.snd-bar {
  position: absolute;
  display: flex;
  flex-direction: column;
  gap: 8px;
  pointer-events: none;}

.snd-rail {
  display: block;
  height: 3px;
  border-radius: 999px;
  background: rgba(var(--ink-rgb), 0.12);
  overflow: hidden;}

.snd-run {
  display: block;
  height: 100%;
  border-radius: 999px;
  background: var(--ink);}

.snd-clock {
  display: flex;
  justify-content: space-between;
  /* ── the interface face, with tabular figures ─────────────
     It was the mono stack, for the reason clocks usually are:
     a proportional 1 is narrower than a 0, so a counter set in
     one shifts on its own every second — which on a track
     that reads 0:57 → 0:58 → 0:59 is a number that fidgets
     while you watch it.

     \`tabular-nums\` is the same guarantee without the second
     typeface. It asks the UI font for its fixed-width figures,
     which it has, so the digits stop moving and the component
     stops carrying a face nothing else here uses. */
  font-family: var(--font-ui);
  font-variant-numeric: tabular-nums;
  font-size: 10.5px;
  /* 1, so the row is the height of the digits and not of the
     font's own leading — nineteen pixels for a ten pixel
     number is eight of empty space the layout above has to
     find room for */
  line-height: 1;
  letter-spacing: 0.04em;
  color: var(--ink-4);}

/* ── the transport ──────────────────────────────────────────
   Placed by its CENTRE — the row's own width changes between
   the two states, so an edge would move even when the middle
   of it did not. */
.snd-ops {
  position: absolute;
  display: flex;
  align-items: center;
  translate: -50% -50%;}

.snd-op {
  flex: none;
  display: grid;
  place-items: center;
  padding: 0;
  border: 0;
  border-radius: 999px;
  background: transparent;
  color: var(--ink-3);
  cursor: pointer;
  overflow: hidden;
  transition: color 160ms ease, background 160ms ease, scale 130ms cubic-bezier(0.3, 0.9, 0.4, 1);}

.snd-op:hover { color: var(--ink); background: rgba(var(--ink-rgb), 0.07); }

/* ── the press ──────────────────────────────────────────────
   It yields before it acts. A control that only changes state
   reads as having been triggered; one that gives under the
   finger first reads as having been pushed, and the whole
   difference is about 40ms and four per cent.

   \`scale\` as its own property, not inside a transform: the
   row is placed with \`translate\` and the play button's size
   is written by the tween, so anything sharing the transform
   shorthand here would be overwritten every frame. */
.snd-op:active { scale: 0.9; }

/* the one you press most, and the only one that is filled */
.snd-op[data-lead] {
  background: var(--ink);
  color: var(--on-ink);}

.snd-op[data-lead]:hover { background: var(--ink); opacity: 0.88; }

.snd-op:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px var(--card), 0 0 0 4px rgba(var(--ink-rgb), 0.35);}

/* ── the heart ──────────────────────────────────────────────
   Built off .snd-op rather than sharing it: it is the same
   size and the same give, but it is not in the transport row
   and it is the only control here that stays on after you let
   go — so it needs a state the row has no use for.

   Ink when it is on, not red. A heart is already the shape
   that carries the meaning, so the colour has only one job
   left — to say FILLED — and the loudest ink on the block is
   what does that without introducing a hue nothing else here
   uses. It also puts the heart at the same weight as the play
   button, which is the other solid mark on the card, so the
   two read as the same kind of thing rather than as a control
   and a warning. */
.snd-like {
  position: absolute;
  display: grid;
  place-items: center;
  padding: 0;
  border: 0;
  border-radius: 999px;
  background: transparent;
  color: var(--ink-3);
  cursor: pointer;
  transition: color 160ms ease, background 160ms ease,
    scale 130ms cubic-bezier(0.3, 0.9, 0.4, 1);}

.snd-like:hover { color: var(--ink); background: rgba(var(--ink-rgb), 0.07); }

.snd-like:active { scale: 0.9; }

.snd-like[data-on] { color: var(--ink); }

.snd-like[data-on]:hover { color: var(--ink); background: rgba(var(--ink-rgb), 0.07); }

/* ── the beat ───────────────────────────────────────────────
   On the way ON only, which is why it is keyed to the state
   and not to the press: unliking something does not deserve a
   flourish, and one that plays both ways reads as a button
   animating rather than as a thing being liked.

   Overshoot is the whole effect — 1.34 and back, on a curve
   that passes its target — so it lands as a pulse rather than
   as a grow. */
.snd-like[data-on] .lucide {
  animation: snd-beat 340ms cubic-bezier(0.3, 1.4, 0.5, 1);}

.snd-like:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px var(--card), 0 0 0 4px rgba(var(--ink-rgb), 0.35);}

/* the hit area, and nothing else — see the note in Sound.tsx */
.snd-tap {
  position: absolute;
  padding: 0;
  border: 0;
  background: none;
  cursor: pointer;}

/* the cover gives too — it is the thing you press to change
   the shape, so it should answer the same way the transport
   does. Scoped to the ART, not to this: the hit area is
   invisible and scaling nothing looks like nothing. */
.snd-box:has(.snd-tap:active) .snd-art { scale: 0.96; }

.snd-art { transition: scale 130ms cubic-bezier(0.3, 0.9, 0.4, 1); }

.snd-tap:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px var(--card), 0 0 0 4px rgba(var(--ink-rgb), 0.35);}

@keyframes snd-beat {
  0% { scale: 1; }
  38% { scale: 1.34; }
  100% { scale: 1; }}`,tokens:[`--card`,`--font-num`,`--font-ui`,`--ink`,`--ink-3`,`--ink-4`,`--ink-rgb`,`--on-ink`,`--on-slab`,`--pane`,`--pane-edge`,`--slab`,`--surface-2`,`--surface-3`],deps:[`lucide-react`],stubs:[`COVER`]},"drag-ball":{tsx:`import { useLayoutEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Liquid } from "liquid-gooey";

/* ══ Dragging ball ════════════════════════════════════════
   One circle, and the only thing it does is follow your
   finger. What makes it worth a card is the TRAIL: the ball
   itself is pinned to the pointer with no lag at all, and a
   second body chases it a beat behind, so the goo between them
   stretches into a tail while you are moving and collapses
   back into a circle the moment you stop.

   Which is the same construction as the liquid toggle's
   straggler, with the drag standing in for the spring: there
   the thumb was thrown to a destination, here it is held.

   ── the rules this obeys ────────────────────────────────
   The bodies are in FLOW, both in one grid cell — an
   absolutely positioned child measures as a zero-radius box
   and the filter draws nothing. The group's fill is OPAQUE,
   because the contrast step erases anything under about 0.39
   alpha. And the layer takes the 1/k correction, because
   \`move\` measures screen pixels and every card here is drawn
   at a fraction of its size. */

const WELL = { w: 300, h: 200 };

/* ── how the grab reads ────────────────────────────────────
   A ball you can drag and a ball you have to GRAB are the
   same interaction with one thing added: the object has to
   answer the hand before it moves. Three beats, and none of
   them is the drag itself —

     hover   it swells a little, so you know it is live
     press   it PINCHES, narrower and taller, the way a soft
             thing does between two fingers
     let go  it rounds back out on a spring

   The pinch is the one doing the work, and it is a pinch
   rather than a uniform shrink on purpose. A circle that gets
   smaller reads as a button being pressed INTO a surface;
   this one is not on a surface, it is in your hand, and what
   a held ball does is narrow across the grip and bulge along
   it. Area is roughly kept — 0.16 out of the width against
   0.08 into the height — so it reads as squeezed rather than
   as resized.

   It goes on the span's transform, which the metaball filter
   honours: the library renders the child inside the filtered
   group rather than drawing a circle from its measurements,
   so the silhouette pinches with it. Verified by pushing a
   scaleX into the node and watching the painted body change
   shape.

   ALL THREE BEATS RIDE THE ONE KNOB, hover included. Grip is
   not "how hard the squeeze is", it is how much the ball
   answers a hand at all — so at 0 it does not swell either,
   and 0 is exactly the block this was before: a circle that
   follows your finger and does nothing else. A knob whose
   bottom end is the old component is the honest kind. */
const SWELL = 0.06;

/* ── inlined from ./Gooey ──────────────────────── */
/* ══ Gooey ════════════════════════════════════════════════
   What is left of the two library-surfaced components that
   used to live here: the measurement every liquid-gooey group
   on the bench needs. Liquid tabs and the Plus menu are gone;
   this is the part of them that turned out to be the reusable
   half, and Balance, the Selection list, the Humidity wheel
   and the Sleep dial all still call it.

   ── what the library actually does ──────────────────────
   The usual gooey effect runs blur + alpha-contrast over your
   real UI, which is why it is normally confined to decorative
   circles: text goes soft, images smear, and the contrast step
   eats shadows. liquid-gooey splits it in two. An SVG layer
   carries a silhouette of your elements and takes the whole
   filter; your actual DOM rides crisp on top of it, untouched.
   Same liquid, none of the tax — and it is the same discipline
   our own filter needs, since text under an alpha threshold
   loses its edges and then itself.

   ── the two patterns, which are not interchangeable ─────
   MORPH gives the library the position: pass x/y and it
   animates the element and the liquid together, so pieces that
   separate stay bridged until the goo can no longer hold them.
   The split IS the effect.

   MOVE gives the position to you: move the element however you
   like and the surface trails it as liquid rubber with a
   droplet tail. A filter has no memory of motion — a shape
   that crossed two pixels and one that crossed the whole track
   arrive identical — and this is the part that fixes that. */

/* ── the zoom correction, applied to someone else's SVG ──────
   liquid-gooey measures its items with getBoundingClientRect
   and draws them as SVG user units. Those are the same number
   only while no ancestor is scaled — and on this bench every
   component sits inside a scaled card, so the transform lands
   twice and the silhouette drifts from its element in
   proportion to both the scale and the distance from the
   origin. Measured: 0.1px at scale 1, 22px at 1.09, 124px at
   1.4.

   Everything the library computes is in screen px, so scaling
   its layer by 1/k converts the whole coordinate space back to
   layout px in one move, and the card's own transform then
   renders it correctly. Same k = rect.width / offsetWidth the
   rest of the bench uses.

   MOVE ONLY. Morph positions its items with a CSS transform on
   a real wrapper, in layout px, which scales correctly on its
   own — apply this there and you over-correct: the silhouette
   comes out 1/k the size of its button, so the blob is smaller
   than the element and every icon looks off-centre inside it.
   Measured on the plus menu: button 58px, blob 46px, and up to
   10px of offset. Without it, 58 and 58, dead on. */
function useGooScale() {
  const box = useRef<HTMLDivElement | null>(null);
  const [k, setK] = useState(1);
  useLayoutEffect(() => {
    const el = box.current;
    if (!el) return;
    const read = () => {
      const r = el.getBoundingClientRect();
      const next = (r.width / (el.offsetWidth || r.width)) || 1;
      setK((was) => (Math.abs(was - next) < 0.001 ? was : next));
    };
    read();
    const ro = new ResizeObserver(read);
    ro.observe(el);
    /* the card also rescales when the overlay opens, which is a
       transform change and not a resize */
    const t = window.setInterval(read, 500);
    return () => { ro.disconnect(); window.clearInterval(t); };
  }, []);
  return { box, k };
}

export function Ball({
  /* how much the body deforms with its own speed, 0..100 */
  stretch = 36,
  /* how quickly it recovers its shape, 0..100 */
  give = 50,
  /* the ball, px */
  size = 56,
  /* how hard it is squeezed while held, 0..100 — 0 is a rigid
     ball, which is a real setting and is what this was */
  grip = 50,
}: {
  stretch?: number;
  give?: number;
  size?: number;
  grip?: number;
} = {}) {
  const g = Math.min(1, Math.max(0, grip / 100));
  /* the library measures in screen pixels and every card on
     this bench is drawn at a fraction — see Gooey.tsx */
  const { box, k } = useGooScale();

  /* ── one note in, one note out, whichever event brings it ──
     The sounds used to hang off \`onDragStart\`/\`onDragEnd\`,
     which means a press that never moves is silent — and a
     press that never moves is exactly the case this component
     just grew a squeeze for. Pointer down is the grab.

     Both handlers are idempotent and both are wired to the
     pointer AND the drag, so whichever framer forwards first
     makes the sound and the other does nothing. That way the
     pair can never go out of balance, and it does not depend
     on knowing which events framer's drag lets through. */
  const armed = useRef(false);
  const grab = () => {
    if (armed.current) return;
    armed.current = true;
    };
  const drop = () => {
    if (!armed.current) return;
    armed.current = false;
    };

  /* room to move: half the well less half the ball, so the
     circle can touch each edge and go no further */
  const reach = { x: (WELL.w - size) / 2, y: (WELL.h - size) / 2 };

  return (
    <div
      className="drg-well"
      ref={box}
      style={{ "--k": k, width: WELL.w, height: WELL.h } as React.CSSProperties}
    >
      <Liquid
        className="drg-goo"
        /* small numbers on purpose. The ball is 56px under a
           4.5px blur — twelve to one — which is what keeps the
           silhouette a circle rather than a smudge. */
        blur={4.5}
        contrast={16}
        /* ── THE BALL IS A RAISED SURFACE, NOT INK ────────────
           \`--fill-slab\` and not \`--fill-on\`: white under a
           light Fill, the raised grey under a dark one. That is
           the --slab doctrine in CLAUDE.md and it is what makes
           the Fill control safe on a component with no ground
           of its own — the ink version was a near-black disc
           that vanished on a near-black card, which is the trap
           the liquid toggle fell into twice.

           It said \`--board\` for a long time, which was the same
           colour and so looked like the same decision. It was
           not: --board is the theme's raised grey and
           --fill-slab is THIS component's fill, and the day the
           dark fill moved off --board the ball stayed behind
           and disappeared into the card. Naming the token you
           actually mean is the difference between a value that
           happens to be right and one that stays right.

           No shadow. It carried one — on the group, so it
           followed the silhouette as it stretched — and the
           cost of taking it away is that a white ball on the
           card's own grey is about 1.06:1. The disc reads, but
           it reads as a shape rather than as an object lifted
           off anything, which is the trade. */
        fill="var(--fill-slab, var(--board))"
        filterPadding={80}
      >
        <Liquid.Item
          effect="move"
          /* ── NO TRAIL. STRETCH INSTEAD. ────────────────────
             \`trail\` is a second body running behind the first,
             and that is what it looks like: drag slowly and
             the goo necks between them into a thin thread,
             drag fast and it gives up and you have two
             circles. Both are the effect working correctly and
             neither is what a ball being thrown around should
             do.

             \`stretch\` deforms the ONE body along its own
             direction of travel — it lengthens into the move
             and rounds back out when it stops. That is the
             elasticity, and there is nothing to leave behind
             because there is nothing behind it.

             A little wobble on top so the recovery is not a
             dead ease, and springiness is what decides how
             quickly the circle comes back. */
          move={{
            springiness: give / 100,
            stretch: stretch / 100,
            wobble: 0.35,
            trail: 0,
          }}
        >
          <motion.span
            className="drg-ball"
            style={{ width: size, height: size }}
            drag
            /* Numeric, not a ref: the constraint is a distance
               from where the ball already sits, and the ball
               sits in the middle of the well by construction.
               A ref would make it a measurement, and a
               measurement on a scaled card is a rect. */
            dragConstraints={{
              left: -reach.x,
              right: reach.x,
              top: -reach.y,
              bottom: reach.y,
            }}
            /* a little give at the wall, and no throw on
               release — this is a thing you place, not a thing
               you flick */
            dragElastic={0.14}
            dragMomentum={false}
            /* ── the hand, before the move ────────────────
               \`whileTap\` is the press and it lasts as long as
               the pointer is down, drag included — so the
               pinch is held for the whole gesture and let go
               with it, which is what a grip is. Framer keeps
               these off the drag's own x and y, so nothing
               here fights the drag for the transform.

               A spring rather than an ease: a squeeze that
               arrives on a curve is a shape being animated,
               and one that arrives with a little overshoot is
               a soft thing giving. */
            whileHover={{ scaleX: 1 + SWELL * g, scaleY: 1 + SWELL * g }}
            whileTap={{ scaleX: 1 - 0.16 * g, scaleY: 1 + 0.08 * g }}
            transition={{ type: "spring", stiffness: 520, damping: 24, mass: 0.6 }}
            /* ── SILENT WHILE IT MOVES ────────────────────
               The continuous voice belongs to a value being
               SET — a slider, a dial, a stepper — where the
               sound is telling you where you have got to. This
               is a ball in an empty box: there is no scale to
               be at a point of, so a note per frame was
               reporting nothing and chattering while it did it.

               The two ends keep theirs. Taking hold of it and
               letting go are events, and they are the only two
               this component has. */
            onPointerDown={grab}
            onDragStart={grab}
            onPointerUp={drop}
            onPointerCancel={drop}
            onDragEnd={drop}
          />
        </Liquid.Item>
      </Liquid>
    </div>
  );
}
`,css:`/* ══ Dragging ball ══════════════════════════════════════════
   One circle and its tail. The well is a plain box: the ball
   is centred in it by the grid and moved from there by
   framer's drag, so the constraint numbers in the component
   are distances from the middle and nothing has to be
   measured — which matters, because every card here is drawn
   at a fraction and a measured rect would be scaled. */
.drg-well {
  position: relative;
  display: grid;
  place-items: center;}

/* undo the library's double-applied scale — see Gooey.tsx.
   \`move\` measures screen pixels, so the layer it draws into
   has to be brought back to layout ones. */
.drg-goo > svg {
  transform: scale(calc(1 / var(--k, 1)));
  transform-origin: 0 0;}

.drg-goo {
  display: grid;
  place-items: center;
  width: 100%;
  height: 100%;}

/* NO BACKGROUND. <Liquid> paints the merged silhouette behind
   it, and a fill here would lay a hard circle on top of the
   liquid edge exactly where the tail is trying to leave it. */
.drg-ball {
  grid-area: 1 / 1;
  border-radius: 999px;
  cursor: grab;
  touch-action: none;
  will-change: transform;}

.drg-ball:active { cursor: grabbing; }`,tokens:[],deps:[`framer-motion`,`liquid-gooey`],stubs:[]},seek:{tsx:`import { useEffect, useRef, useState } from "react";

/* ══ Seek ═════════════════════════════════════════════════
   A search icon that becomes a search field.

   ONE OBJECT, NOT TWO. Everything here follows from that. The
   obvious build is an icon that fades out and an input that
   fades in, and it is obvious because it is easy — but two
   things swapping is never mistaken for one thing changing,
   however well the crossfade is tuned. So there is a single
   box whose WIDTH is the state, and the icon and the field
   are both inside it the whole time.

   Which turns the interesting problems into geometry rather
   than choreography:

   · The lens never moves relative to the box. It sits at a
     fixed inset from the left edge, and at the closed width
     that inset happens to centre it — (44 - 18) / 2 is 13,
     and 13 is also the padding the open field wants. So one
     number is both "centred in a circle" and "aligned in a
     field", and the lens travelling leftward across the page
     is not an animation anybody wrote. It is the box growing
     around a mark that stayed put.

   · The box grows from its middle, so the composition stays
     centred at every frame. Growing from the left would pin
     the lens and throw the field off-centre; growing from the
     right would slide the lens across the page. Neither is
     the object transforming, and both are what you get by
     accident.

   · Height never changes and the corner is fully round at
     every width, so the SHAPE is one rule rather than a tween
     with two ends. At 44 it is a circle and at 320 a pill,
     and those are the same statement. The radius used to
     interpolate 22 → 13, which was a second thing that had
     to agree with the first; a stadium corner needs no
     agreement at all.

   The press is a real beat. A click compresses the object for
   a moment before it expands, because a thing that yields
   before it moves reads as having been pushed, and a thing
   that only moves reads as having been triggered. */

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

/* The closed object: a circle, so the width IS the height.
   Was 44, which is a header control — and this is not in a
   header, it is the whole component, sitting alone on a card
   with 96px of frame around it. At 44 the shut state read as a
   small button somebody had left in the middle of a large
   card. 60 is the size of the thing itself rather than the
   size it would be inside something else.

   The stylesheet reads this through --shut rather than
   repeating it: the skin's height and the closed width are the
   same number by definition, and two places holding it is two
   places to get it wrong. */
const SHUT = 64;
/* the lens, and its inset. See the note above — this number
   is doing two jobs and they agree by construction.

   28, measured against the rest of the bench rather than
   picked. Every round icon button here sits between 0.44 and
   0.50 of its button — .gdock-item 20/44, .bar-tool 17/38,
   .gnav-item 17/38, the nav's own 18/36 — and this button is
   64 across, so 28 puts it at 0.44, in with the others. 18
   was 0.28 and read as a small mark in a large circle.

   The STROKE is independent of this, which is the part I got
   wrong twice. The svg is an 18-unit viewBox, so a
   stroke-width of u units always draws at u/18 of the glyph's
   own size, whatever that size is — and lucide's 2-on-18 is
   the same 0.111. \`stroke-width: 2\` therefore matches the
   bench at any LENS, and resizing the icon does not disturb
   it. */
const LENS = 28;
const INSET = (SHUT - LENS) / 2;

/* the field's corner. 32 is half of its 64px height, which is
   the circle it is when shut and the pill it is when open. */
const CORNER = 32;

/* the resting field, wide screen and narrow. See the note on
   the \`width\` prop for why there are two.

   280 and not 240, which was the first answer and overshot:
   the button on a phone card is 64 x (260 / (field + 26)), so
   240 drew it at 63 against the 44 it started at — half again
   as big, which is a different component rather than a legible
   one. 280 lands at 54. The move that was actually wanted is
   the one you notice without being able to name it. */
const WIDE = 320;
const SNUG = 280;

/* ── inlined from ./spring ──────────────────────── */
/* ── one spring, for everything that settles ───────────────
   The maths was already on this bench twice, copied by hand:
   Humidity's wheel and Brightness's column both accumulate
   velocity toward a target, damp it, and snap when both the
   delta and the velocity fall under 0.02. Two copies is a
   coincidence; five would be a policy, so it comes out here
   before the elastic blocks are written against it.

   The two shipped copies are deliberately NOT refactored onto
   this. They work, they are tuned, and rewriting the innards
   of two live components to prove a point about duplication
   is how a good afternoon becomes a bad one. This is the one
   new code uses.

   Frames, not milliseconds. \`dt\` is expressed in sixtieths of
   a second and the damping is RAISED to it rather than
   multiplied by it, so a dropped frame decays the same amount
   of energy as the two frames it replaced. Multiplying is the
   version that makes a spring behave differently on a busy
   page, which is the hardest kind of bug to see.

   The loop parks itself the moment the value has settled.
   CLAUDE.md is not complimentary about the one permanent
   requestAnimationFrame already on this bench and there is no
   case for five more. */

/* 0..100 into the two numbers a spring actually has.

   50 is what Humidity and Brightness were tuned at, which is
   the rule every elastic knob on this bench follows — see
   lab/motion. Turn the panel to the middle and nothing has
   changed.

   Both ends have to be usable, which is what fixes the range:
   at 0 it is slow and heavy and still arrives, at 100 it is
   quick with a visible overshoot, and nowhere in between does
   it ring for longer than it takes to read. */
/* The pair is chosen by DAMPING RATIO and then written back
   as stiffness and decay, because the ratio is the thing a
   person is actually setting and the two numbers on their own
   do not say what they add up to.

     zeta = -ln(d) / (2 * sqrt(k))

   The first version of this ran 0.06..0.26 stiffness against
   0.93..0.74 decay, which reads as a sensible spread and is
   not one: it puts zeta between 0.15 and 0.16 across the
   WHOLE range, so every setting overshot by about sixty per
   cent and the knob only changed how fast it did it. Pull's
   return went 130px past its own resting position and lifted
   the content off the top of the card.

     0   → zeta ~0.85, heavy, arrives without a ring
     50  → zeta ~0.41, near where Humidity and Brightness sit
     100 → zeta ~0.20, lively, two visible rebounds

   Both ends shippable, which is the constraint that fixed the
   numbers rather than taste. */
const springOf = (tune: number) => ({
  /* stiffness: how hard it is pulled toward the target */
  k: 0.08 + (tune / 100) * 0.16,
  /* decay, per frame: how much of the velocity survives */
  d: 0.62 + (tune / 100) * 0.2,
});

/* Units matter. The snap threshold is absolute, so a caller
   works in pixels or in 0..100 — a spring driven over 0..1
   would be "settled" before it had visibly moved. */
function useSpring(target: number, tune = 50, instant = false) {
  const [at, setAt] = useState(target);
  const cur = useRef(target);
  const vel = useRef(0);
  const raf = useRef(0);

  useEffect(() => {
    if (instant) {
      cur.current = target;
      vel.current = 0;
      setAt(target);
      return;
    }
    const { k, d } = springOf(tune);
    let prev = 0;
    const tick = (t: number) => {
      const dt = prev ? clamp((t - prev) / 16.67, 0, 2.5) : 1;
      prev = t;
      vel.current += (target - cur.current) * k * dt;
      vel.current *= Math.pow(d, dt);
      cur.current += vel.current * dt;
      if (Math.abs(target - cur.current) < 0.02 && Math.abs(vel.current) < 0.02) {
        cur.current = target;
        vel.current = 0;
        setAt(target);
        raf.current = 0;
        return;
      }
      setAt(cur.current);
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf.current);
      raf.current = 0;
    };
    /* \`tune\` sits here beside \`target\` for the reason
       Brightness spells out: the loop closes over it, so
       without it a knob turned mid-flight would do nothing
       until something else restarted the effect. Restarting
       picks up from the refs, so it continues rather than
       snapping. */
  }, [target, tune, instant]);

  return at;
}

/* Read once, the way the wheel and the pill nav do. A
   preference, not a live input. */
const stillness = () =>
  typeof window !== "undefined" &&
  !!window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

export function Seek({
  /* how far it leans toward the cursor, 0..100 */
  give = 50,
  /* how the width settles, 0..100 */
  spring = 50,
  /* The field's resting width, px. Back to 320 from 380, and
     that is what makes the BUTTON bigger rather than what makes
     the component smaller: the wall fits a card's contents by
     their bounding box, so on this card the button's size on
     screen is 64 x (fit / frame width). Widening the field
     spends the same budget on the part of the object you are
     not looking at while it is shut.

     ── AND THE DEFAULT IS NARROWER ON A PHONE ─────────────
     Undefined here rather than 320, because the two callers
     want different things. The panel always passes a number,
     so the knob stays live across its whole range wherever you
     are. The WALL passes nothing — it renders every card with
     no options at all — so a card falls through to the number
     below, and on a narrow column that number is 240.

     The arithmetic is the note above, run on a phone: a 375px
     screen gives the card a 260px fit, so a 346 frame drew the
     shut button at 48 and a 306 frame draws it at 54. Nothing
     about the object changed; the room reserved beside it did.

     Still well inside the knob's own 240..400 range, so this
     is a setting the component was drawn for rather than a
     number invented for one screen. */
  width,
  /* the field's own corner, 0..32 */
  corner = CORNER,
}: {
  give?: number;
  spring?: number;
  width?: number;
  corner?: number;
} = {}) {
  /* ── narrow, and it can change under you ────────────────
     A phone rotates and a desktop window gets dragged narrow;
     read once at mount and the frame would be wrong for the
     rest of the session. State rather than a ref because the
     width below is rendered, so it has to re-render. */
  const [snug, setSnug] = useState(
    () => typeof window !== "undefined"
      && window.matchMedia("(max-width: 760px)").matches,
  );
  /* ── and whether the screen has a keyboard of its own ────
     A different question from \`snug\` and it needs its own
     query: \`snug\` is about how much ROOM there is, and this is
     about what opening the field costs. A narrow desktop
     window is snug and types fine; a tablet is roomy and still
     throws half its screen away to a keyboard. */
  const [touch, setTouch] = useState(
    () => typeof window !== "undefined"
      && window.matchMedia("(pointer: coarse)").matches,
  );
  useEffect(() => {
    const room = window.matchMedia("(max-width: 760px)");
    const coarse = window.matchMedia("(pointer: coarse)");
    const read = () => { setSnug(room.matches); setTouch(coarse.matches); };
    room.addEventListener("change", read);
    coarse.addEventListener("change", read);
    return () => {
      room.removeEventListener("change", read);
      coarse.removeEventListener("change", read);
    };
  }, []);
  const span = width ?? (snug ? SNUG : WIDE);

  const frame = useRef<HTMLDivElement | null>(null);
  const field = useRef<HTMLInputElement | null>(null);
  const beat = useRef(0);
  const rest = useRef(0);

  const [open, setOpen] = useState(false);
  const [press, setPress] = useState(false);
  const [value, setValue] = useState("");
  const [busy, setBusy] = useState(false);
  const [lean, setLean] = useState({ x: 0, y: 0 });
  const still = stillness();

  useEffect(() => () => {
    window.clearTimeout(beat.current);
    window.clearTimeout(rest.current);
  }, []);

  /* ── the width is the state ──────────────────────────────
     Tuned toward the top of the range by default: this is a
     control, and a control that wobbles reads as decoration.
     What the spring is for here is the tiny overshoot at the
     end — enough that the object arrives rather than stops,
     and not enough to notice as a bounce. */
  const target = open ? Math.max(SHUT, span) : SHUT;
  const w = useSpring(target, clamp(spring, 0, 100), still);

  /* how far through the transformation, 0 shut and 1 open */
  const p = clamp((w - SHUT) / Math.max(1, Math.max(SHUT, span) - SHUT), 0, 1);

  /* ── the magnet ──────────────────────────────────────────
     Measured from the FRAME, which never moves, and not from
     the object, which does. A vector read off a thing the
     vector is currently displacing is a feedback loop: it
     converges, but it converges by ringing, and the ring is
     visible as a shiver on an object this small.

     Off entirely once open. A field that drifts toward the
     pointer while you are trying to click into it is a field
     fighting you. */
  useEffect(() => {
    const el = frame.current;
    if (!el || open || still) return;
    let raf = 0;
    let at = { x: 0, y: 0 };
    const publish = () => { raf = 0; setLean(at); };
    const read = (e: PointerEvent) => {
      const b = el.getBoundingClientRect();
      /* the wall draws this at a fraction and the canvas at a
         zoom; a radius measured in screen pixels would be a
         different radius at each */
      const k = b.width / (el.offsetWidth || b.width) || 1;
      const dx = (e.clientX - (b.left + b.width / 2)) / k;
      const dy = (e.clientY - (b.top + b.height / 2)) / k;
      const d = Math.hypot(dx, dy);
      const R = 110;
      if (d > R) {
        if (at.x || at.y) { at = { x: 0, y: 0 }; if (!raf) raf = requestAnimationFrame(publish); }
        return;
      }
      /* A FEW PIXELS. The brief for this is "responsive, not
         following" and the difference is entirely in the
         ceiling: past about seven the object stops being a
         thing that acknowledges you and starts being a thing
         you are dragging around. */
      const pull = (1 - d / R) ** 1.4 * (2 + (give / 100) * 5);
      at = { x: (dx / (d || 1)) * pull, y: (dy / (d || 1)) * pull };
      if (!raf) raf = requestAnimationFrame(publish);
    };
    const gone = () => { at = { x: 0, y: 0 }; if (!raf) raf = requestAnimationFrame(publish); };
    document.addEventListener("pointermove", read, { passive: true });
    document.addEventListener("pointerleave", gone);
    return () => {
      document.removeEventListener("pointermove", read);
      document.removeEventListener("pointerleave", gone);
      cancelAnimationFrame(raf);
    };
  }, [open, give, still]);

  /* ── opening ─────────────────────────────────────────────
     Compress, then expand, then focus. The order matters and
     the gap is short: 90ms is long enough to be felt as the
     object yielding and short enough that nobody waits for
     it. Focus lands with the expansion rather than at the end
     of it, so the caret is already there when the field
     arrives — waiting for the width to settle puts a visible
     pause between the box being ready and the box being
     usable. */
  /* ── THE OBJECT OPENING, HEARD ───────────────────────────
     \`expand\` and \`collapse\` are the bench's pair for a thing
     opening and closing, and this is the block that most
     obviously does both — a circle becoming a field and back.
     They land on the press and on the release rather than on
     the width settling: the sound belongs to the decision, not
     to the animation catching up with it. */
  const start = () => {
    if (open) return;
    setPress(true);
    window.clearTimeout(beat.current);
    beat.current = window.setTimeout(() => {
      setPress(false);
      setOpen(true);
      field.current?.focus();
    }, still ? 0 : 90);
  };

  /* Away with nothing typed and it goes back. Away with
     something typed and it stays: the value IS the reason the
     field exists, and closing over it would either hide it or
     throw it away. */
  const away = () => {
    if (value.trim()) return;
    setOpen(false);
  };

  /* the lens acknowledges typing without performing it — one
     short beat per burst, not one per character */
  /* One short mark per BURST of typing, not one per key — the
     lens already works this way visually and the sound follows
     the same rule. A note per character is a typewriter, which
     is a different component. */
  const tapped = () => {
    if (!busy) setBusy(true);
    window.clearTimeout(rest.current);
    rest.current = window.setTimeout(() => setBusy(false), 340);
  };

  return (
    <div
      className="sek"
      ref={frame}
      data-open={open}
      data-press={press}
      data-busy={busy}
      data-flat={still || undefined}
      style={{
        "--sek-r": \`\${clamp(corner, 0, CORNER)}px\`,
        "--w": \`\${w.toFixed(2)}px\`,
        "--p": p.toFixed(3),
        /* the placeholder and the caret arrive in the last
           third, once there is somewhere for them to be */
        "--say": clamp((p - 0.55) / 0.45, 0, 1).toFixed(3),
        "--lx": \`\${lean.x.toFixed(2)}px\`,
        "--ly": \`\${lean.y.toFixed(2)}px\`,
        "--inset": \`\${INSET}px\`,
        "--lens": \`\${LENS}px\`,
        "--shut": \`\${SHUT}px\`,
        /* ── THE FRAME FOLLOWS THE FIELD ──────────────────
           It was a fixed 440x116, sized for the widest the
           knob goes. The wall scales a component down by its
           BOUNDING BOX, so a frame sized for the maximum makes
           every smaller setting draw smaller — growing the
           object inside a fixed frame made the button on the
           card 35px where it had been 30, when the point was
           to make it considerably bigger.

           Tight to what is actually set, and the wall's own fit
           does the rest. It still never moves during an
           interaction: this changes with a knob, not with the
           open/shut state, which is what the magnet needs. */
        "--frame": \`\${Math.max(SHUT, span) + 26}px\`,
        "--frameh": \`\${SHUT + 40}px\`,
      } as React.CSSProperties}
    >
      <div className="sek-skin">
        {/* Drawn rather than imported. The lens has to take a
            state — it thickens a hair while you type — and an
            icon you cannot address is an icon that can only
            be swapped for another one. */}
        <svg className="sek-lens" viewBox="0 0 18 18" aria-hidden="true">
          <circle cx="7.6" cy="7.6" r="5.4" />
          <path d="M11.6 11.6 L15.4 15.4" />
        </svg>

        <input
          ref={field}
          className="sek-field"
          type="text"
          value={value}
          placeholder="Search"
          aria-label="Search"
          /* ── NO SOFTWARE KEYBOARD ON A TOUCH SCREEN ──────
             This is a block on a wall, not a search anybody is
             performing: tapping it threw up the keyboard, which
             on a phone covers half the page and hides the very
             transformation the block exists to show.

             \`inputMode\` and not \`readOnly\`, and not skipping
             the focus() in start(). Both of those would fix the
             keyboard and break something: readOnly kills typing
             for a tablet with a real keyboard attached, and not
             focusing kills the only way this closes — \`away\` is
             a blur handler, so a field that never takes focus
             never gives it back and would stay open for good.

             none means "I am focusable, I have a caret, do not
             raise the on-screen one", which is exactly the
             difference being asked for. */
          inputMode={touch ? "none" : undefined}
          tabIndex={open ? 0 : -1}
          onChange={(e) => { setValue(e.target.value); tapped(); }}
          onBlur={away}
          onKeyDown={(e) => {
            if (e.key !== "Escape") return;
            e.preventDefault();
            setValue("");
            setOpen(false);
            field.current?.blur();
          }}
        />

        {/* The way in, and only while there is a way in. When
            the field is open this is the field's own job, and
            a second target sitting over it would swallow the
            click that places the caret. */}
        {!open && (
          <button className="sek-hit" aria-label="Search" onClick={start} />
        )}
      </div>
    </div>
  );
}
`,css:`/* ── flat panes ────────────────────────────────────────────
   Set data-surface="flat" on any ancestor and every glass
   surface under it becomes a solid fill with a hairline. The
   inner buttons already sit on rgba(var(--ink-rgb), 0.05)
   with no border, which is what flat wants anyway, so they
   need nothing.

   The frost is switched off at the element rather than through
   a token. A var() holding a url() filter cannot be validated
   at parse time, so the browser would treat it as invalid at
   computed-value time and drop the property outright — which
   breaks the two-declaration fallback the glass depends on. */
/* ══ stroke ═════════════════════════════════════════════════
   Whether a component draws a hairline round itself. OFF by
   default, which is the change: every glass surface carried
   one unconditionally, and a grey line round everything makes
   a wall of components look like a wall of boxes rather than
   a wall of things.

   The line is not load-bearing. A flat pane is a fill against
   a different fill and reads on its own; the ring was there
   to sharpen an edge that was already there.

   Placed ABOVE the glass rules on purpose. Glass draws its
   own lit rim, and that rim is the material rather than a
   stroke — it is what gives a pane thickness. So glass wins
   the border wherever the two meet, and Stroke governs the
   drawn line that flat surfaces would otherwise have. */
[data-stroke="on"] .lab::before,
[data-stroke="on"] .gcard::before,
[data-stroke="on"] .gpane::before,
[data-stroke="on"] .gnav::before,
[data-stroke="on"] .gdock::before,
/* the playful blocks. None of them is glass, so none has a
   lit rim for the stroke to lose to — the hairline is the
   only edge they can have, and it is the whole of what this
   control does for them. */
[data-stroke="on"] .esc-btn::before,
[data-stroke="on"] .slo-track::before,
[data-stroke="on"] .sek-skin::before {
  border-color: var(--pane-edge);}

/* ══ Seek ═══════════════════════════════════════════════════
   A search icon that becomes a search field, as one object.

   Everything below is width and radius. There is no crossfade
   between two components, no second element to keep in sync,
   and nothing that animates on a clock of its own — the box
   is sprung in JS and every other value here is derived from
   how far through that spring it is. That is the whole reason
   the transformation reads as continuous: there is only one
   number, so nothing can arrive at the wrong time relative to
   anything else. */
.sek {
  /* the frame is the composition. It never moves, which is
     what gives the magnet a stable home to measure from and
     keeps the object centred at every width. */
  position: relative;
  display: grid;
  place-items: center;
  /* ── THE FRAME IS \`--frame\`, and it was not ──────────────
     Seek.tsx computes \`--frame\` and \`--frameh\` from the width
     that is actually set — its note explains why at length:
     the wall fits a card by the BOUNDING BOX, so a frame sized
     for the widest the knob goes makes every smaller setting
     draw smaller. It has been publishing those two numbers to
     a stylesheet that ignored them and used a hard 380 x 96.

     Measured on a phone card: the frame reserved 380 for a
     field set to 320, the wall fitted 380 into 260, and the
     shut button — the only thing drawn at rest — came out at
     44px. The 36px of nothing was being paid for in the one
     part of the object you are looking at.

     With the variables wired up the knob does what its own
     comment says it does, and the frame is tight to what is
     set on every screen. */
  width: var(--frame, 380px);
  height: var(--frameh, 96px);
  font-family: var(--font-ui);}

/* ── the object ─────────────────────────────────────────────
   Width is the state. Height is fixed, so the radius can be
   derived from the width rather than animated beside it —
   at 44 the corner is 22 and the shape IS a circle, and there
   is no frame where the two disagree.

   The surface is the quietest thing that still reads as an
   object: a low-alpha ink fill and a hairline. No shadow, no
   glass, no gradient — at this size any of them would be the
   loudest thing on an otherwise empty page. */
.sek-skin {
  position: relative;
  width: var(--w);
  /* --shut, NOT a number. The component sets the closed width
     and the height from one constant precisely so they cannot
     drift, and its own comment says so: "the skin's height and
     the closed width are the same number by definition, and
     two places holding it is two places to get it wrong."
     Hard-coded here at 44 against a --shut of 64, the closed
     state was a 64x44 lozenge — a circle that is not round is
     the one shape everybody notices. */
  height: var(--shut);
  /* ── ONE SHAPE RULE ─────────────────────────────────────
     Fully round, at every width. The radius used to
     interpolate 22 → 13, which was a second thing to keep in
     agreement with the first; a stadium corner needs no
     agreement at all. At --shut wide it is a circle and at 320
     a pill, and those are the same rule rather than two ends
     of a tween. Height is fixed, so it cannot be anything
     else. */
  /* the Corner knob's, and ::before and .sek-hit inherit it */
  border-radius: var(--sek-r, 999px);
  /* ── FLAT, and glass only if asked ──────────────────────
     \`--pane\` is the bench's own material token, so this
     follows the Glass dial rather than deciding for itself:
     at 0 it resolves to a solid board and at 100 to the
     frosted pane. It was a translucent ink wash with an inset
     hairline, which is glass by every visual measure while
     answering to no control — the worst of both, since it
     could not be turned off.

     And it picks up Fill for free. Flat resolves --pane to
     --board, and Fill redeclares --board, so a dark fill
     gives a dark pill without this rule naming a colour. */
  background: var(--pane);
  -webkit-backdrop-filter:
    blur(var(--g-blur, 2px)) saturate(var(--g-sat, 150%)) brightness(var(--g-bright, 100%));
  backdrop-filter:
    blur(var(--g-blur, 2px)) saturate(var(--g-sat, 150%)) brightness(var(--g-bright, 100%));
  isolation: isolate;
  /* the magnet, and the press, on one transform — two
     transforms on one element is one of them winning */
  transform: translate(var(--lx), var(--ly)) scale(var(--sk, 1));
  transition:
    transform 260ms cubic-bezier(0.22, 0.9, 0.28, 1),
    background 220ms ease;
  /* the field is inside from the first frame; this is what
     keeps it from spilling out of a 44px circle */
  overflow: hidden;}

/* the edge, and NOTHING until Stroke asks for it. A hairline
   nobody switched on is a hairline the control cannot remove,
   which is the same bug the background had. */
.sek-skin::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border: 1px solid transparent;
  pointer-events: none;
  z-index: 2;}

/* Hover: it comes up a hair and lifts off the ground. Both
   are small enough to be felt rather than seen, which is the
   point — a hover state you notice is a hover state that has
   said too much. */
.sek:not([data-open="true"]) .sek-skin:hover {
  --sk: 1.045;
  /* the surface answers, without drawing an edge it was not
     given — brightness rather than an outline */
  --g-bright: 104%;}

/* pressed: it yields before it moves. A thing that gives
   under a click reads as having been pushed; a thing that
   only expands reads as having been triggered. */
.sek[data-press="true"] .sek-skin {
  --sk: 0.93;
  transition: transform 90ms cubic-bezier(0.4, 0, 0.6, 1);}

/* the field is a text target, and the object is a button */
.sek[data-open="true"] .sek-skin { cursor: text; }

/* ── the lens ───────────────────────────────────────────────
   Fixed to the box's left inset and never animated. At the
   shut width that inset centres it; at the open width it is
   the field's padding. The lens crossing the page is the box
   growing around a mark that stayed still. */
.sek-lens {
  position: absolute;
  left: var(--inset);
  top: 50%;
  width: var(--lens);
  height: var(--lens);
  margin-top: calc(var(--lens) / -2);
  fill: none;
  stroke: var(--ink-3);
  /* 1.5, AND THE NUMBER CANNOT BE COMPARED TO LUCIDE'S.
     Every lucide glyph is drawn on a 24-unit grid; this one is
     drawn on 18. A stroke-width of u paints at u/viewBox of
     the icon's size, so lucide's 2-on-24 is 0.0833 and a 2
     here would be 0.1111 — the same number, a third heavier.
     1.5/18 is 0.0833 exactly, which is the radial menu's
     weight and the nav's.

     The value that stood here was 1.6 (0.0889). That was very
     nearly right; it was changed to 2 on the assumption that
     the two viewBoxes matched, and they never did. */
  stroke-width: 1.5;
  stroke-linecap: round;
  pointer-events: none;
  transition: stroke 200ms ease, stroke-width 200ms ease;}

.sek-skin:hover .sek-lens { stroke: var(--ink); }

.sek[data-open="true"] .sek-lens { stroke: var(--ink-4); }

/* typing: the lens thickens a hair and darkens. One beat per
   burst, not one per keystroke — a mark that flickers at the
   rate of your typing is noise wearing the costume of
   feedback. */
/* still "a hair", and still the same proportion of the base it
   always was — 1.9 was to 1.6 as 1.8 is to 1.5 */
.sek[data-busy="true"] .sek-lens { stroke: var(--ink-2); stroke-width: 1.8; }

/* ── the field ──────────────────────────────────────────────
   Present from the first frame and revealed by --say, which
   is the last third of the width's own progress. It slides a
   few pixels as it arrives, from the left, so it reads as
   having come out of the lens rather than as having faded up
   where it stood. */
.sek-field {
  position: absolute;
  left: calc(var(--inset) + var(--lens) + 11px);
  right: 14px;
  top: 0;
  height: 100%;
  border: 0;
  background: none;
  font: inherit;
  /* 14 is the NAV's size, and the nav's field is 44px tall.
     This pill is --shut, 64, and carrying header type in it
     left the words looking like a caption inside the object
     rather than its content. 18 restores roughly the
     proportion the bar has — 0.28 of the height against the
     bar's 0.32 — on a control that is the whole component
     rather than one item in a row of them. */
  font-size: 18px;
  letter-spacing: -0.005em;
  color: var(--ink);
  outline: none;
  opacity: var(--say);
  transform: translateX(calc((1 - var(--say)) * -6px));
  /* until it is most of the way open it is not a target, and
     a caret that can be placed in a 44px circle is a caret in
     the wrong place */
  pointer-events: var(--say-hit, none);}

.sek[data-open="true"] .sek-field { --say-hit: auto; }

.sek-field::placeholder { color: var(--ink-5); }

/* the way in, while there is one */
.sek-hit {
  position: absolute;
  inset: 0;
  border: 0;
  border-radius: inherit;
  background: none;
  cursor: pointer;}

.sek-hit:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px var(--bg), 0 0 0 4px rgba(var(--ink-rgb), 0.4);}`,tokens:[`--bg`,`--font-ui`,`--g-blur`,`--g-sat`,`--ink`,`--ink-2`,`--ink-3`,`--ink-4`,`--ink-5`,`--ink-rgb`,`--pane`,`--pane-edge`],deps:[],stubs:[]},humidity:{tsx:`import { useEffect, useLayoutEffect, useRef, useState } from "react";

/* ── the wheel · a draggable instrument ring ────────────────
   60 ticks over a 300° sweep with a 60° gap at the bottom.
   The value is a spring, not a transition, so it overshoots
   and settles. Active ticks carry a slow travelling wave
   whose amplitude scales with the reading. Drag the ring. */

const N = 60;
const START = 120;   // degrees, bottom left
const SWEEP = 300;   // degrees, clockwise to bottom right
const CX = 100;
const CY = 100;
const R = 52;        // inner radius of the tick band

const rad = (d: number) => (d * Math.PI) / 180;
const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

/* ── FOUR BANDS, AND THE COLOUR LIVES IN CSS ───────────────
   It was three, and their hexes were written here: amber under
   25, blue over 80, a green between. Two things were wrong
   with that and one thing was missing.

   Wrong first: a hard hex cannot answer the theme. Every other
   signal colour on this bench is a token that swaps with the
   ramp, and these three stayed put — the green in particular
   was #16a34a, a text green, where the balance chart had
   already worked out that a THIN STROKE needs a brighter one
   to read as the same colour. These ticks are 2px.

   So this returns a NAME and the stylesheet holds the values,
   which is how the wheel gets both a light and a dark palette
   and how its green can be the chart's green without either
   file naming a number the other has to match.

   And the thing missing: red. "Critical" was amber, which is
   the colour of a warning rather than of a problem — there was
   nothing left to say when it got worse. So the bottom splits:
   under 12 is red and means it, 12 to 25 is the amber warning
   it always was.

   The labels stay even though nothing renders them. They are
   what the four numbers MEAN, and a band called "low" reads
   better at the call site than \`v < 25\`. */
function stateFor(v: number) {
  if (v < 12) return { label: "Critical", key: "crit" };
  if (v < 25) return { label: "Low", key: "low" };
  if (v > 80) return { label: "High", key: "high" };
  return { label: "Normal", key: "ok" };
}

/* ── inlined from ./Gooey ──────────────────────── */
/* ══ Gooey ════════════════════════════════════════════════
   What is left of the two library-surfaced components that
   used to live here: the measurement every liquid-gooey group
   on the bench needs. Liquid tabs and the Plus menu are gone;
   this is the part of them that turned out to be the reusable
   half, and Balance, the Selection list, the Humidity wheel
   and the Sleep dial all still call it.

   ── what the library actually does ──────────────────────
   The usual gooey effect runs blur + alpha-contrast over your
   real UI, which is why it is normally confined to decorative
   circles: text goes soft, images smear, and the contrast step
   eats shadows. liquid-gooey splits it in two. An SVG layer
   carries a silhouette of your elements and takes the whole
   filter; your actual DOM rides crisp on top of it, untouched.
   Same liquid, none of the tax — and it is the same discipline
   our own filter needs, since text under an alpha threshold
   loses its edges and then itself.

   ── the two patterns, which are not interchangeable ─────
   MORPH gives the library the position: pass x/y and it
   animates the element and the liquid together, so pieces that
   separate stay bridged until the goo can no longer hold them.
   The split IS the effect.

   MOVE gives the position to you: move the element however you
   like and the surface trails it as liquid rubber with a
   droplet tail. A filter has no memory of motion — a shape
   that crossed two pixels and one that crossed the whole track
   arrive identical — and this is the part that fixes that. */

/* ── the zoom correction, applied to someone else's SVG ──────
   liquid-gooey measures its items with getBoundingClientRect
   and draws them as SVG user units. Those are the same number
   only while no ancestor is scaled — and on this bench every
   component sits inside a scaled card, so the transform lands
   twice and the silhouette drifts from its element in
   proportion to both the scale and the distance from the
   origin. Measured: 0.1px at scale 1, 22px at 1.09, 124px at
   1.4.

   Everything the library computes is in screen px, so scaling
   its layer by 1/k converts the whole coordinate space back to
   layout px in one move, and the card's own transform then
   renders it correctly. Same k = rect.width / offsetWidth the
   rest of the bench uses.

   MOVE ONLY. Morph positions its items with a CSS transform on
   a real wrapper, in layout px, which scales correctly on its
   own — apply this there and you over-correct: the silhouette
   comes out 1/k the size of its button, so the blob is smaller
   than the element and every icon looks off-centre inside it.
   Measured on the plus menu: button 58px, blob 46px, and up to
   10px of offset. Without it, 58 and 58, dead on. */
function useGooScale() {
  const box = useRef<HTMLDivElement | null>(null);
  const [k, setK] = useState(1);
  useLayoutEffect(() => {
    const el = box.current;
    if (!el) return;
    const read = () => {
      const r = el.getBoundingClientRect();
      const next = (r.width / (el.offsetWidth || r.width)) || 1;
      setK((was) => (Math.abs(was - next) < 0.001 ? was : next));
    };
    read();
    const ro = new ResizeObserver(read);
    ro.observe(el);
    /* the card also rescales when the overlay opens, which is a
       transform change and not a resize */
    const t = window.setInterval(read, 500);
    return () => { ro.disconnect(); window.clearInterval(t); };
  }, []);
  return { box, k };
}

export default function Humidity({
  /* how finely the band is cut. Few and it reads as a scale,
     many and it reads as a surface. */
  ticks = N,
  /* how much of the circle the band covers, the rest being the
     gap at the bottom */
  sweep = SWEEP,
  /* the travelling wave the lit ticks carry. At 0 the ring is
     a static gauge; this is the one number that decides
     whether it looks alive. */
  wave: waveAmp = 2.6,
}: {
  ticks?: number;
  sweep?: number;
  wave?: number;
}) {
  const [target, setTarget] = useState(62);
  const [display, setDisplay] = useState(62);
  const [dragging, setDragging] = useState(false);
  /* the library measures in screen pixels and every card on
     this bench is drawn at a fraction — see Gooey.tsx */
  const { box, k } = useGooScale();

  const cur = useRef(62);
  const vel = useRef(0);
  const wave = useRef(0);
  const raf = useRef<number | undefined>(undefined);
  const svgRef = useRef<SVGSVGElement | null>(null);

  const reduced =
    typeof window !== "undefined" &&
    window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

  /* spring toward the target, plus a free running wave clock */
  useEffect(() => {
    let last = performance.now();
    const tick = (t: number) => {
      const dt = Math.min(34, t - last) / 16.67;
      last = t;

      if (reduced) {
        cur.current = target;
      } else {
        const k = 0.16;   // stiffness
        const d = 0.76;   // damping
        vel.current += (target - cur.current) * k * dt;
        vel.current *= Math.pow(d, dt);
        cur.current += vel.current * dt;
        if (Math.abs(target - cur.current) < 0.02 && Math.abs(vel.current) < 0.02) {
          cur.current = target;
          vel.current = 0;
        }
      }

      wave.current += dt * 0.055;
      setDisplay(cur.current);
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => { if (raf.current) cancelAnimationFrame(raf.current); };
  }, [target, reduced]);

  /* pointer angle to value */
  const fromPointer = (e: React.PointerEvent) => {
    const svg = svgRef.current;
    if (!svg) return;
    const b = svg.getBoundingClientRect();
    const x = ((e.clientX - b.left) / b.width) * 200 - CX;
    const y = ((e.clientY - b.top) / b.height) * 200 - CY;
    let deg = (Math.atan2(y, x) * 180) / Math.PI;
    if (deg < 0) deg += 360;
    let rel = deg - START;
    if (rel < 0) rel += 360;
    if (rel > sweep) rel = rel < sweep + 30 ? sweep : 0;  // snap across the gap
    const next = Math.round((rel / sweep) * 100);
    /* the reading is the pitch: the ring sounds like what it
       is showing, and dragging it round is a slide */
    if (next !== target) setTarget(next);
  };

  const st = stateFor(display);
  const f = clamp(display, 0, 100) / 100;
  const amp = reduced ? 0 : 1 + (display / 100) * waveAmp;

  const band = Array.from({ length: ticks }, (_, i) => {
    const tf = i / (ticks - 1);
    const on = tf <= f + 0.001;
    const behind = f - tf;                         // >0 when the tick trails the head
    const comet = on && behind < 0.14 ? (1 - behind / 0.14) * 8 : 0;
    const undulate = on ? Math.sin(wave.current + i * 0.5) * amp : 0;
    /* ── 23 lit against 21 unlit, and it was 26 ──────────────
       Length is the coarse signal here and OPACITY is the fine
       one — the lit ticks run 0.42 to 1 depending on how far
       behind the head they are, which is the part carrying the
       reading. At 26 the length was saying it too, loudly, and
       the ring read as a solid block with a ragged edge rather
       than as a band of marks.

       24 and not 23, and the difference is the WAVE. The lit
       ticks undulate by about 2.6 either way at the default,
       so a base of 23 put the trough at 20.4 against an unlit
       21 — some lit ticks were SHORTER than unlit ones, and a
       band whose edge dips below the ground it sits on reads
       as noise rather than as a run. 24 keeps the trough at
       21.4, just clear of it. Measured both.

       The comet came down with it: at 8 the head still stands
       out from the band by more than twice the base
       difference, which is what makes it a head. */
    const len = (on ? 24 : 21) + comet + undulate;
    const a = rad(START + tf * sweep);
    const cos = Math.cos(a);
    const sin = Math.sin(a);
    return {
      key: i,
      x1: CX + cos * R,
      y1: CY + sin * R,
      x2: CX + cos * (R + len),
      y2: CY + sin * (R + len),
      on,
      opacity: on ? 0.42 + (1 - clamp(behind, 0, 1)) * 0.58 : 1,
    };
  });

  return (
    /* ── NO PANE ────────────────────────────────────────────
       Same move the sleep dial made, and for the same reason:
       a ring of ticks is already a shape, and putting a
       frosted rectangle round it only said "this is a
       component" to a page that has already said so with a
       card.

       What the pane WAS doing, quietly, was supplying
       contrast — see the tick opacity below. */
    <div className="hum" ref={box} data-state={st.key} style={{ "--k": k } as React.CSSProperties}>
      <div className="hum-dial">
      <svg
        ref={svgRef}
        className="hwheel"
        viewBox="0 0 200 200"
        data-dragging={dragging}
        role="slider"
        tabIndex={0}
        aria-label="Humidity"
        aria-valuenow={Math.round(display)}
        aria-valuemin={0}
        aria-valuemax={100}
        onPointerDown={(e) => {
          e.stopPropagation();
          setDragging(true);
          (e.target as Element).setPointerCapture?.(e.pointerId);
          fromPointer(e);
        }}
        onPointerMove={(e) => dragging && fromPointer(e)}
        onPointerUp={() => setDragging(false)}
        onPointerCancel={() => setDragging(false)}
        onKeyDown={(e) => {
          if (e.key === "ArrowRight" || e.key === "ArrowUp") setTarget((v) => clamp(v + 2, 0, 100));
          if (e.key === "ArrowLeft" || e.key === "ArrowDown") setTarget((v) => clamp(v - 2, 0, 100));
        }}
      >
        {band.map((t) => (
          <line
            key={t.key}
            x1={t.x1} y1={t.y1} x2={t.x2} y2={t.y2}
            /* a style and not the \`stroke\` attribute: an
               attribute cannot hold a var(), and the band's
               colour is one — see stateFor and the .hum block
               in the stylesheet */
            style={{ stroke: t.on ? "var(--hum-lit)" : "currentColor" }}
            /* 0.24, not 0.13. The frosted pane used to sit a
               step lighter than the wall and an unlit tick had
               that to be dark against; straight onto the card's
               grey it measured about 1.2:1 and simply was not
               there. Same correction the sleep dial needed. */
            strokeOpacity={t.on ? t.opacity : 0.24}
            strokeWidth={2}
            strokeLinecap="round"
          />
        ))}
      </svg>

      <div className="hwheel-readout">
        <span className="hum-figure">{Math.round(display)}</span>
        <span className="hum-unit">%</span>
      </div>
      </div>

    </div>
  );
}
`,css:`/* ── humidity ──────────────────────────────────────────── */
/* ── humidity wheel ─────────────────────────────────────────
   No pane. The wheel and its pill, stacked, standing directly
   on whatever the section is made of — the same arrangement
   the sleep dial uses, and they should read as a pair. */
/* ── the wheel's four bands ─────────────────────────────────
   Humidity.tsx names the band and this holds the colour, so
   the palette can answer the theme — the hexes used to be
   written in the component and could not.

   The green is the BALANCE CHART'S green, not the site's --ok,
   and for the reason written up on .bal-plot: --ok is a text
   green, and a 2px tick is a thin stroke, which always reads
   darker and duller than a block of the same colour. Two
   blocks drawing thin lines in green should be drawing the
   same one.

   Red under 12 and amber from 12 to 25 — the band used to be
   one amber "Critical", which is the colour of a warning
   rather than of a problem, and left nothing to say when it
   got worse. Blue at the top is unchanged: high humidity is
   not an alarm, it is the other end. */
.hum {
  --hum-lit: #12b055;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0;
  font-family: var(--font-ui);
  color: var(--fill-on, var(--ink));}

.hum[data-state="crit"] { --hum-lit: #e8443a; }

.hum[data-state="low"] { --hum-lit: #d97706; }

.hum[data-state="high"] { --hum-lit: #2563eb; }

/* the same lift the chart takes on a dark page, and the warm
   pair with it: a red and an amber picked for white sit heavy
   on near-black, where the ticks have no mass to carry them */
[data-theme="dark"] .hum { --hum-lit: #3ce085; }

[data-theme="dark"] .hum[data-state="crit"] { --hum-lit: #ff6b5e; }

[data-theme="dark"] .hum[data-state="low"] { --hum-lit: #f0a02a; }

[data-theme="dark"] .hum[data-state="high"] { --hum-lit: #5b9bff; }

.hum-dial { position: relative; width: 250px; height: 250px; }

.hwheel {
  position: absolute;
  inset: 0;
  width: 250px;
  height: 250px;
  cursor: grab;
  touch-action: none;
  outline: none;}

.hwheel[data-dragging="true"] { cursor: grabbing; }

.hwheel:focus,
.hwheel:focus-visible {
  outline: none !important;
  box-shadow: none;
  -webkit-tap-highlight-color: transparent;}

.hwheel-readout {
  position: absolute;
  left: 0; right: 0;
  /* centred on the dial rather than measured from the pane's
     top, which is what 152px was */
  top: 50%;
  translate: 0 -50%;
  display: flex; align-items: baseline; justify-content: center; gap: 2px;
  pointer-events: none;}

/* Inter, not DM Mono — tabular figures give the stable advance
   the mono face was there for, and this number counts as you
   drag. Same swap the sleep dial made. */
.hum-figure {
  font-family: var(--font-ui);
  font-size: 34px;
  font-weight: 500;
  /* -0.045, not -0.03. At 34px the figures are large enough to
     carry tighter tracking than body copy wants, and the unit
     is set at the same size now — so the pair reads as one
     word rather than as a number with a symbol after it. The
     unit takes the same value for exactly that reason. */
  letter-spacing: -0.045em;
  line-height: 1;
  font-variant-numeric: tabular-nums;}

/* ── the unit is part of the number ────────────────────────
   14px at 35% opacity beside a 34px figure was a footnote to
   it: a caption explaining what the digits meant, in a
   component where the digits and the ring are the only two
   things there. At the figure's own size and full ink the two
   read as ONE reading — "62%" — which is what it is. The
   margin goes with it; at matching sizes the pair needs no
   more air than the readout's own 2px gap. */
.hum-unit {
  font-family: var(--font-ui);
  font-size: 34px;
  font-weight: 500;
  letter-spacing: -0.045em;
  line-height: 1;}`,tokens:[`--fill-on`,`--font-ui`,`--ink`],deps:[],stubs:[]}};export{e as BLOCKS};